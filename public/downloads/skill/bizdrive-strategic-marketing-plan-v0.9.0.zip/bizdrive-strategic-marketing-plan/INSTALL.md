# Installation Guide

Package name: `bizdrive-strategic-marketing-plan`

## Automated Installer

Run from the extracted package root:

```text
python scripts/install_skill.py --runtime <runtime> --scope <scope>
```

Runtimes: `codex`, `claude`, `hermes`, `generic`

Scopes:

- `user` — available across the user's workspaces
- `project` — checked into or copied into one project

Use `--dry-run` to inspect the target and `--force` to replace an existing copy.

## Codex

Official documentation: https://developers.openai.com/codex/skills

Codex reads project skills from `.agents/skills/` and user skills from
`$HOME/.agents/skills/`.

### User install

```text
python scripts/install_skill.py --runtime codex --scope user
```

Target:

```text
$HOME/.agents/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

### Project install

```text
python scripts/install_skill.py --runtime codex --scope project --project-dir <project>
```

Target:

```text
<project>/.agents/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

Invoke explicitly with `$bizdrive-strategic-marketing-plan` or ask for an
evidence-led Strategic + Marketing Plan in natural language.

## Claude Code

Official documentation: https://code.claude.com/docs/en/skills

Claude Code reads personal skills from `~/.claude/skills/` and project skills
from `.claude/skills/`.

### User install

```text
python scripts/install_skill.py --runtime claude --scope user
```

Target:

```text
~/.claude/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

### Project install

```text
python scripts/install_skill.py --runtime claude --scope project --project-dir <project>
```

Target:

```text
<project>/.claude/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

Invoke with `/bizdrive-strategic-marketing-plan` or natural language. If a new
top-level skills directory is not detected in an existing session, restart
Claude Code.

## Hermes Agent

Hermes profiles use independent homes. The installer resolves user scope from
`$HERMES_HOME` when set; otherwise it uses `~/.hermes`. Use `--hermes-home`
for an explicit target. This prevents installing into the default profile when
another profile is active.

### User/profile install

```text
python scripts/install_skill.py --runtime hermes --scope user
```

Target:

```text
$HERMES_HOME/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

If `$HERMES_HOME` is unset, the target is
`~/.hermes/skills/bizdrive-strategic-marketing-plan/SKILL.md`.

### Project install

```text
python scripts/install_skill.py --runtime hermes --scope project --project-dir <project>
```

Target:

```text
<project>/.agents/skills/bizdrive-strategic-marketing-plan/SKILL.md
```

The installer reads the active profile's `skills.external_dirs` with
`hermes config get --json`, appends the absolute `<project>/.agents/skills`
directory without removing existing entries, and atomically replaces only the
`skills.external_dirs` YAML block. It then verifies both the JSON round-trip and
`hermes skills list`. It honors `HERMES_HOME` or `--hermes-home`; if config
update, installation or discovery fails, it restores the exact previous config
bytes and target. Symlinked install-path segments are rejected. The `hermes` CLI
must be available for Hermes installation.

Equivalent manual configuration:

```yaml
skills:
  external_dirs:
    - /absolute/path/to/project/.agents/skills
```

Start a new Hermes session so the skill index reloads.

## Generic Agent Skills Runtime

For a runtime implementing the open Agent Skills format, install the entire
folder—not only `SKILL.md`—into its documented skills directory. If it follows
the common `.agents/skills/` project convention:

```text
python scripts/install_skill.py --runtime generic --scope project --project-dir <project>
```

If the runtime has no automatic skill loader, attach `SKILL.md` to the agent's
instructions and preserve relative access to `references/`, `templates/` and
`scripts/`.

## Verify an Installation

1. Confirm the target contains `SKILL.md`, `references/`, `templates/` and `scripts/`.
2. Ask the runtime to list skills or invoke the skill explicitly.
3. Run a smoke initializer in a disposable workspace:

```text
python scripts/init_plan.py --product "Smoke Test" --monthly-budget 100000 \
  --duration 3 --strategic-entity brand --strategic-horizon "1 year" \
  --base-dir <temporary-directory> --slug smoke-test
```

4. Confirm `meta.json` reports skill `bizdrive-strategic-marketing-plan`, version
   `0.9.0`, total budget `300000`, and includes `strategic_plan.md` in the
   handoff contract.

## Update or Remove

- Update: rerun installer with `--force` after validating the new package.
- Remove: delete only the installed `bizdrive-strategic-marketing-plan` folder
  from the runtime's skills directory.
- Do not delete a shared parent `.agents/skills/` or `.claude/skills/` directory.
