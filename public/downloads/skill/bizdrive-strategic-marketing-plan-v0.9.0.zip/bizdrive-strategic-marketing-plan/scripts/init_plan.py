#!/usr/bin/env python3
"""Initialize a portable strategic-marketing-plan project safely."""
from __future__ import annotations

import argparse
import json
import os
import re
import tempfile
from datetime import datetime
from pathlib import Path

EXPECTED_MARKDOWN = [
    "00_brief.md",
    "step1_market_analysis.md",
    "step2_competitor_analysis.md",
    "step3_swot_analysis.md",
    "step4_customer_persona.md",
    "step5_positioning_key_message.md",
    "step6_online_strategy.md",
    "step7_offline_strategy.md",
    "step8_content_plan.md",
    "step8b_30_clip_scripts.md",
    "step9_budget_allocation.md",
    "step10_kpis_measurement.md",
    "step11_execution_timeline.md",
    "step12_executive_report.md",
]

STRATEGIC_HANDOFF = [
    "README_FIRST.md",
    "category_landscape.md",
    "competitor_universe.csv",
    "competitor_matrix.csv",
    "strategy_choice.md",
    "strategic_plan.md",
    "assumptions_register.csv",
    "decision_register.json",
]

INITIAL_OUTPUTS = (
    "meta.json",
    "evidence_ledger.json",
    "decision_register.json",
    "assumptions_register.csv",
    "competitor_universe.csv",
    "00_brief.md",
)
SAFE_SLUG = re.compile(r"^[a-z0-9\u0e00-\u0e7f]+(?:-[a-z0-9\u0e00-\u0e7f]+)*$")


def slugify(text: str) -> str:
    value = text.lower().strip()
    value = re.sub(r"[^a-z0-9\u0e00-\u0e7f\s_-]", "", value)
    value = re.sub(r"[\s_-]+", "-", value).strip("-")
    return value or "product"


def atomic_write_text(directory: Path, filename: str, text: str) -> None:
    target = directory / filename
    if directory.is_symlink():
        raise SystemExit(f"refusing symlinked project directory: {directory}")
    if target.is_symlink():
        raise SystemExit(f"refusing symlinked output: {target}")
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=directory,
            prefix=f".{filename}.", suffix=".tmp", delete=False,
        ) as temporary:
            temporary.write(text)
            temporary.flush()
            os.fsync(temporary.fileno())
            temporary_name = temporary.name
        os.replace(temporary_name, target)
    finally:
        if temporary_name:
            Path(temporary_name).unlink(missing_ok=True)


def reject_symlink_path(path: Path, label: str) -> None:
    expanded = path.expanduser()
    absolute = expanded if expanded.is_absolute() else Path.cwd() / expanded
    if absolute.is_symlink():
        raise SystemExit(f"refusing symlinked {label}: {absolute}")


def channel_mix(monthly_budget: int) -> dict[str, int]:
    if monthly_budget <= 100_000:
        return {"online": 80, "offline": 5, "kol": 10, "reserve": 5}
    if monthly_budget <= 500_000:
        return {"online": 70, "offline": 8, "kol": 17, "reserve": 5}
    if monthly_budget <= 1_000_000:
        return {"online": 60, "offline": 12, "kol": 23, "reserve": 5}
    if monthly_budget <= 5_000_000:
        return {"online": 55, "offline": 18, "kol": 22, "reserve": 5}
    return {"online": 50, "offline": 22, "kol": 23, "reserve": 5}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--product", required=True)
    parser.add_argument("--monthly-budget", required=True, type=int)
    parser.add_argument("--duration", required=True, type=int)
    parser.add_argument("--price", type=float)
    parser.add_argument("--strategic-entity", default="brand")
    parser.add_argument("--strategic-horizon", default="not owner-specified")
    parser.add_argument(
        "--base-dir",
        default=str(Path.cwd() / "marketing-plans"),
    )
    parser.add_argument("--slug")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    if args.monthly_budget <= 0:
        raise SystemExit("monthly budget must be greater than zero")
    if not 1 <= args.duration <= 60:
        raise SystemExit("duration must be between 1 and 60 months")
    if args.price is not None and args.price <= 0:
        raise SystemExit("price must be greater than zero")

    slug = args.slug or slugify(args.product)
    if not SAFE_SLUG.fullmatch(slug) or Path(slug).name != slug or slug in {".", ".."}:
        raise SystemExit("slug must be a single safe path component in canonical kebab-case")
    base_input = Path(args.base_dir).expanduser()
    reject_symlink_path(base_input, "base directory")
    base = base_input.resolve()
    project = base / slug
    if project.is_symlink():
        raise SystemExit(f"refusing symlinked project directory: {project}")
    resolved_project = project.resolve(strict=False)
    if resolved_project.parent != base:
        raise SystemExit(f"project path escapes base directory: {resolved_project}")
    if project.exists() and not project.is_dir():
        raise SystemExit(f"project path is not a directory: {project}")
    if project.exists() and any(project.iterdir()) and not args.force:
        raise SystemExit(f"refusing to overwrite non-empty project: {project}")
    project.mkdir(parents=True, exist_ok=True)
    reject_symlink_path(base_input, "base directory")
    if project.is_symlink() or project.resolve() != resolved_project:
        raise SystemExit(f"refusing symlinked project directory: {project}")
    for filename in INITIAL_OUTPUTS:
        if (project / filename).is_symlink():
            raise SystemExit(f"refusing symlinked output: {project / filename}")

    total = args.monthly_budget * args.duration
    mix = channel_mix(args.monthly_budget)
    meta = {
        "product_name": args.product,
        "slug": slug,
        "monthly_budget_thb": args.monthly_budget,
        "duration_months": args.duration,
        "total_budget_thb": total,
        "product_price_thb": args.price,
        "strategic_entity": args.strategic_entity,
        "strategic_horizon": args.strategic_horizon,
        "strategic_plan_status": "provisional until owner-approved inputs and decisions are recorded",
        "channel_mix_pct_initial_heuristic": mix,
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "worker": "active AI agent runtime",
        "lead_model_policy": ["strongest available reasoning model"],
        "skill": "bizdrive-strategic-marketing-plan",
        "skill_version": "0.9.0",
        "expected_markdown": EXPECTED_MARKDOWN,
        "strategic_handoff": STRATEGIC_HANDOFF,
        "upstream_source": "https://bizdrive-skill.com/skill/marketing-plan",
        "assumptions": [
            "Initial channel mix is a planning heuristic pending category research.",
            "No campaign, spend, publishing, or outreach is approved by this plan run.",
        ],
    }
    atomic_write_text(project, "meta.json", json.dumps(meta, ensure_ascii=False, indent=2))
    atomic_write_text(project, "evidence_ledger.json", "[]\n")
    atomic_write_text(project, "decision_register.json", "[]\n")
    atomic_write_text(
        project, "assumptions_register.csv",
        "id,type,statement,status,owner,decision_impact,evidence_or_test,review_date\n",
    )
    atomic_write_text(
        project, "competitor_universe.csv",
        "brand,product_sku,competitor_type,geography,price_tier,primary_need,"
        "channel_presence,discovery_source,evidence_grade,included_in_deep_dive,"
        "inclusion_or_exclusion_reason,observed_at\n",
    )

    brief = f"""# Marketing Plan Brief — {args.product}

| รายการ | ค่า |
|---|---:|
| สินค้า/บริการ | {args.product} |
| งบการตลาดต่อเดือน | {args.monthly_budget:,} บาท |
| ระยะเวลา | {args.duration} เดือน |
| งบรวม | {total:,} บาท |
| ราคาสินค้า | {f'{args.price:,.2f} บาท' if args.price else 'ยังไม่ระบุ — ห้ามคำนวณรายได้แบบฟันธง'} |
| Strategic entity | {args.strategic_entity} |
| Strategic horizon | {args.strategic_horizon} |
| Strategic Plan status | Provisional until owner-approved inputs and decisions are recorded |
| Worker | Active AI agent runtime |
| Lead model policy | Strongest available reasoning model |

## ขอบเขต

จัดทำ category landscape, material competitor universe, strategic choice cascade,
Strategic Plan ระดับ {args.strategic_entity} แบบ provisional จนกว่า owner จะอนุมัติ
inputs/choices, แผนการตลาด 12 ขั้น, Best/Base/Worst scenarios และสคริปต์ 30 คลิป โดยแยก
**ข้อเท็จจริงที่มีแหล่งอ้างอิง**, **ข้อมูลจากเจ้าของ**, **ข้อมูลสังเกต/คำนวณ**,
**strategic inference**, **สมมติฐาน** และ **สิ่งที่ยังไม่ทราบ** ออกจากกัน

## Approval boundary

เอกสารนี้เป็นแผนเท่านั้น ยังไม่อนุมัติการยิงโฆษณา เผยแพร่ ติดต่อบุคคลภายนอก
ซื้อบริการ อัปโหลด หรือ deploy ใด ๆ
"""
    atomic_write_text(project, "00_brief.md", brief)
    print(json.dumps({"status": "ok", "project_dir": str(project), "total_budget_thb": total, "files_created": ["meta.json", "evidence_ledger.json", "decision_register.json", "assumptions_register.csv", "competitor_universe.csv", "00_brief.md"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
