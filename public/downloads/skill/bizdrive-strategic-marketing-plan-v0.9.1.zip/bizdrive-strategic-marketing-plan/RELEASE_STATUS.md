# Release Status

## Current status

**0.9.1 STUDENT BETA — APPROVED FOR DISTRIBUTION**

## Rights and license

- Rights holder: Prachaya Piyasirisilp / BizDrive
- Owner authorization: adaptation and student distribution confirmed 2026-08-28
- Web publication target authorized 2026-08-28: BizDrive Marketing Plan Lab (`/skill`) only
- Content, templates, references and examples: CC BY-NC 4.0
- Python scripts and tests: MIT
- Full terms: `LICENSE.md`
- Rights declaration: `references/provenance.md`

## Required release gates

A distributed ZIP must be produced only by `scripts/build_release.py`, which
requires:

- portable Agent Skills frontmatter schema
- matching approved license identifier and bundled terms
- owner-authorized provenance record
- no personal machine path, host identity, private key or record-level Voice URL
- exact reviewed 57-file payload; no additional or hidden distribution entry
- no raw/private directory, credential assignment or direct Customer Voice statement in the package
- strict shareable worked-example validation
- Python compile checks
- a single internal manifest with no duplicate archive members

The `.sha256` sidecar generated beside the ZIP is the authoritative release
checksum.

## External action boundary

This status approves packaging and distribution under the stated license. It
does not authorize uploading to a particular repository, course platform,
marketplace or public website; each publication target remains a separate owner
scope decision.
