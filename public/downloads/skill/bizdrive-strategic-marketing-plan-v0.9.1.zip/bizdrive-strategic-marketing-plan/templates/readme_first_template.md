# README FIRST — {{product_name}}

> Status: {{research_or_plan_status}}
> Geography / evidence date: {{geography}} / {{retrieval_date}}
> Owner-approved inputs: {{owner_inputs}}
> External-action status: no launch, spend, publish or outreach approval unless explicitly recorded below.

## Read this in five minutes

1. **Category boundary:** {{category_boundary}}
2. **Landscape:** {{landscape_summary}}
3. **Material competitor universe:** {{universe_count}} records; {{deep_dive_count}} in deep dive
4. **Primary strategic choice:** {{primary_choice}}
5. **Strategic Plan:** {{planning_entity}} / {{strategic_horizon}} / {{strategic_plan_status}}
6. **Secondary experiment:** {{secondary_choice}}
7. **No-go zones:** {{no_go_summary}}
8. **Biggest unknowns:** {{critical_unknowns}}
9. **Next decision gate:** {{next_gate}}

## Artifact map

| Start here | Purpose |
|---|---|
| `category_landscape.md` | category definition, forces, segments, trends, channels and regulation |
| `competitor_universe.csv` | longlist, classes, evidence and shortlist reasons |
| `competitor_matrix.csv` | exact-SKU deep dive |
| `strategy_choice.md` | compared options and selected category/brand choice cascade |
| `strategic_plan.md` | multi-horizon ambition, portfolio choices, capabilities, operating model, resources, initiatives and governance |
| `assumptions_register.csv` | owner facts, assumptions and unknowns |
| `decision_register.json` | decisions, status, evidence and owner boundary |
| `step1…step12` | full marketing-plan workflow |
| `evidence_ledger.json` | claim-level provenance |

## What is verified vs provisional

{{evidence_boundary_summary}}

## How to reuse this work

- Refresh dated prices, claims, channels, regulations and market figures before reuse.
- Keep the declared category boundary or explicitly revise the universe.
- Do not promote scenarios, personas, analytical scores or Winning Zones into market facts.
- Use public-safe Customer Voice outputs for sharing; raw excerpts and record-level links stay in private research storage.

## Owner decision boundary

{{owner_decision_boundary}}
