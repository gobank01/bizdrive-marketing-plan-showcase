# Executive Report — {{product_name}}

> Geography / evidence date: {{geography}} / {{retrieval_date}}
> Owner-approved inputs: {{owner_inputs}}
> Budget envelope: {{budget_summary}}
> Status: planning/research only unless an owner approval is recorded

## 1. Executive summary

Summarize in one page:

- declared category boundary and material landscape
- competitor universe count, deep-dive count and coverage gaps
- highest-priority need states and evidence limitations
- primary strategic choice, secondary experiment and no-go choices
- critical right-to-win/economics/compliance unknowns
- recommended next decision gate—not automatic launch

## 2. Evidence and uncertainty boundary

| Type | What is known | Decision use | Limitation / refresh trigger |
|---|---|---|---|
| Owner facts | {{}} | {{}} | {{}} |
| Verified facts | {{}} | {{}} | {{}} |
| Market observations | {{}} | {{}} | {{}} |
| Calculations | {{}} | {{}} | {{}} |
| Strategic inference | {{}} | {{}} | {{}} |
| Assumptions / unknowns | {{}} | {{}} | {{}} |

## 3. Category and competitor intelligence

- Category/JTBD boundary: {{}}
- Price-pack and channel architecture: {{}}
- Regulation/category economics: {{}}
- Material universe: {{universe_count}}
- Frozen exact-SKU deep dive: {{deep_dive_count}}
- Direct/indirect/substitute/emerging/adjacent coverage: {{}}
- Saturation result and remaining blind spots: {{}}

## 4. Strategic options and decision

| Option | Demand | Whitespace | Right-to-win | Economics | Feasibility | Compliance | Defensibility | Evidence | Decision |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| {{option_a}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| {{option_b}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| {{option_c}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

### Choice cascade

- Winning aspiration: {{}}
- Where to Play: {{}}
- How to Win: {{}}
- Capabilities required: {{}}
- Management systems: {{}}
- No-go choices: {{}}
- Status: provisional / owner-committed

## 5. Strategy-to-plan traceability

| Strategic choice | Product/offer | Audience/message | Channel/path | Budget/resource | KPI chain | Gate |
|---|---|---|---|---:|---|---|
| {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

Summarize Steps 1–12 only after showing this bridge. Remove any workstream that does not support a choice or label it exploratory.

## 6. Economics, budget and scenarios

Show:

- total and monthly budget arithmetic
- channel role and strategic rationale for every material line
- reserve release rule
- price, COGS, gross-to-net, fees, returns and capacity status
- allowable CAC / break-even only when contribution inputs exist
- Best/Base/Worst formulas with cited or clearly labeled assumptions

A scenario is not a forecast. If load-bearing inputs are absent, show formula/range and `unknown` rather than fake precision.

## 7. Measurement and decision system

| Layer | Metric | Formula/source | Baseline | Threshold | Cadence | Owner | Decision |
|---|---|---|---|---|---|---|---|
| Business | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| Customer | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| Funnel | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| Capability/risk | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

## 8. Learning agenda and 30/60/90 proposal

For each phase list priority unknown, cheapest valid test, owner, deadline, pass/fail threshold and one of: no-go, iterate/pilot, request separate scale approval.

Do not use generic “launch”, “sign KOL” or “scale” actions unless product truth, economics, compliance, supply and owner approval gates are already satisfied.

## 9. Risks, no-go and reversal triggers

| Risk / no-go | Early signal | Mitigation | Stop/reversal trigger | Owner |
|---|---|---|---|---|
| {{}} | {{}} | {{}} | {{}} | {{}} |

## 10. Owner decision boundary

State exactly what evidence supports now, what remains provisional, what decision is requested, and which external actions require separate approval. Never mark spend, publishing, outreach, purchase, deployment or campaign launch approved unless the owner explicitly approved that boundary.
