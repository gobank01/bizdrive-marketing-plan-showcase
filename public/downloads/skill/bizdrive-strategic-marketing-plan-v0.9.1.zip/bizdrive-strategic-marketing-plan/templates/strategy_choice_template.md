# Strategy Choice — {{product_name}}

## Strategic question

{{question_with_time_horizon_and_constraints}}

## Evidence and uncertainty boundary

| Type | Inputs |
|---|---|
| Owner facts | {{owner_facts}} |
| Verified facts | {{verified_facts}} |
| Observations/calculations | {{observations}} |
| Assumptions | {{assumptions}} |
| Critical unknowns | {{unknowns}} |

## Category and competitor coverage

- Boundary: {{category_boundary}}
- Universe: {{universe_count}} material records
- Deep dive: {{deep_dive_count}} records
- Coverage gaps: {{coverage_gaps}}
- Saturation rule/result: {{saturation_result}}

## Strategic options

| Option | Demand | Whitespace | Right-to-win | Economics | Feasibility | Compliance | Defensibility | Evidence | Decision |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| {{option_a}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| {{option_b}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |
| {{option_c}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

Scores require rationale. Unknown right-to-win, economics or compliance keeps an option provisional regardless of total.

## Choice cascade

### Winning aspiration
{{winning_aspiration}}

### Where to play
{{where_to_play}}

### How to win
{{how_to_win}}

### Capabilities required
{{capabilities}}

### Management systems
{{management_systems}}

### No-go choices
{{no_go_choices}}

## Strategy-to-plan traceability

| Strategic choice | Product/offer | Audience/message | Channel/path | Budget | KPI | Gate |
|---|---|---|---|---:|---|---|
| {{choice}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

## Learning agenda

| Priority unknown | Hypothesis | Evidence/test | Owner | Deadline | Pass/fail | Next decision |
|---|---|---|---|---|---|---|
| {{unknown}} | {{}} | {{}} | {{}} | {{}} | {{}} | {{}} |

## Decision

- Primary choice: {{primary_choice}}
- Secondary experiment: {{secondary_experiment}}
- No-go: {{no_go}}
- Status: {{provisional_or_committed}}
- Separate owner approval required for: {{external_actions}}
