# Clip Script Template

ใช้ template นี้เขียนสคริปต์ทุก 1 คลิป (ใน Step 8) ให้ครบทุกส่วน

---

## คลิปที่ {{clip_number}} — {{title}}

| รายการ | ค่า |
|--------|------|
| Phase | {{Awareness / Consideration / Conversion}} |
| สัปดาห์ | {{week_number}} |
| ความยาว | {{30s / 45s / 60s / 90s}} |
| Platform หลัก | {{TikTok / IG Reels / YouTube Shorts / FB / YT Long}} |
| Persona เป้าหมาย | {{Primary / Secondary / Tertiary}} |
| Key Message | {{อ้างอิงจาก Step 5}} |

---

### Hook (0-3 วินาทีแรก)

> "{{ประโยคแรกที่จะ pull viewer}}"

ใช้ pattern: คำถาม / ตัวเลข / pattern interrupt / คำเตือน / เทียบของคุ้นเคย

---

### Script Body (พูดได้จริง พร้อม timecode)

**0:03 — 0:10**
{{ขยาย hook อธิบายปัญหา/บริบท}}

**0:10 — 0:25**
{{เนื้อหาหลัก ส่วน 1}}

**0:25 — 0:45**
{{เนื้อหาหลัก ส่วน 2 — ใส่ proof/ตัวเลข/ตัวอย่าง}}

**0:45 — 0:55**
{{สรุป + เปลี่ยนผ่านไปที่ CTA}}

---

### CTA (Call to Action)

> "{{คำสั่งกระตุ้น เช่น คลิกลิงก์ใต้คลิป / ทักแชทเลย / ลงทะเบียนทดลองขับ}}"

ใส่ urgency ถ้า phase 3: "เฉพาะ X วันนี้เท่านั้น"

---

### Caption สำหรับลงโพสต์

```
{{ประโยคแรก hook ดึงดูด}}

{{2-3 ประโยค expand}}

{{CTA + ลิงก์}}
```

---

### Hashtags (10-15 ตัว)

`#แบรนด์ #สินค้า #หมวด #ปัญหา #ทางแก้ #เทรนด์ #ไลฟ์สไตล์ #pain_point #benefit #cta`

ใส่: 3 hashtag แบรนด์ + 5 hashtag กว้าง + 5 hashtag เฉพาะกลุ่ม

---

### Production Note

| รายการ | รายละเอียด |
|--------|------------|
| Camera | {{angle / movement / shot list}} |
| B-roll | {{footage ที่ต้องเตรียม}} |
| Music Mood | {{upbeat / cinematic / chill / dramatic}} |
| Text/Caption บนจอ | {{key text overlays}} |
| Pattern Interrupt | {{ทุก 5-7 วิ ใช้ technique อะไร}} |
| ตำแหน่ง logo | {{มุม / เวลา}} |
| ฉาก/Location | {{indoor/outdoor/studio}} |

---

### KPI เป้าหมาย

| Metric | Target (Base Case) |
|--------|---------------------|
| View | {{number}} |
| 3-sec Hook Retention | {{>50%}} |
| Engagement Rate | {{number}}% |
| Save | {{number}} |
| Share | {{number}} |
| Comment | {{number}} |
| Click to Landing | {{number}} |

---

### Distribution Plan

| Platform | Aspect | Caption ปรับ | Posting Time |
|----------|--------|---------------|---------------|
| TikTok | 9:16 | สั้น มี hook แรง | 19:00-21:00 |
| IG Reels | 9:16 | hashtags เน้น | 18:00-20:00 |
| YT Shorts | 9:16 | title SEO | 12:00-14:00 |
| FB | 1:1 หรือ 9:16 | ยาวกว่า + CTA ชัด | 19:00-22:00 |
