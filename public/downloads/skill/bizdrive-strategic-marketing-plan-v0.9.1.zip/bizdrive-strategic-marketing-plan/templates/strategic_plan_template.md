# Strategic Plan — {{planning_entity}}

> Plan status: {{provisional_or_owner_approved}}
> Entity / geography: {{entity_scope}} / {{geography}}
> Strategic horizon / evidence date: {{strategic_horizon}} / {{retrieval_date}}
> Owner-approved ambition and constraints: {{owner_inputs}}
> External-action status: no spend, publication, hiring, partner contact or launch approval unless recorded in the decision register.

## 1. Strategic Horizon / ขอบเขตเวลา

{{entity_boundary_horizon_and_status}}

## 2. Diagnosis / การวินิจฉัย

| Finding | Type | Evidence / assumption ID | Strategic implication |
|---|---|---|---|
| {{finding}} | {{verified_observed_calculated_inferred_assumed_unknown}} | {{id}} | {{implication}} |

### Critical uncertainties

{{ranked_uncertainties}}

## 3. Ambition / เป้าประสงค์

{{measurable_owner_level_ambition_with_horizon_or_provisional_label}}

## 4. Portfolio Choices / ทางเลือกพอร์ต

| Arena / offer | Invest, maintain, test, partner or exit | Why | Evidence / unknown | No-go / condition |
|---|---|---|---|---|
| {{arena}} | {{choice}} | {{rationale}} | {{id}} | {{condition}} |

## 5. Where to Play / สนามที่เลือก

- Geography: {{geography_choice}}
- Need state / segment: {{need_state_choice}}
- Occasion: {{occasion_choice}}
- Offer / SKU / price-pack: {{offer_choice}}
- Route to market: {{channel_choice}}
- Explicit exclusions: {{where_not_to_play}}

## 6. How to Win / วิธีชนะ

{{differentiated_value_proof_economic_logic_channel_advantage_and_tradeoff}}

## 7. Capabilities / ความสามารถที่ต้องมี

| Capability | Current → target maturity | Gap | Build / buy / partner | Owner | Resource envelope | Dependency / evidence gate |
|---|---|---|---|---|---:|---|
| {{capability}} | {{maturity}} | {{gap}} | {{choice}} | {{owner}} | {{resource}} | {{gate}} |

## 8. Operating Model / ระบบปฏิบัติการ

| Decision / process | Recommends | Decides | Executes | Cadence | Dashboard / escalation |
|---|---|---|---|---|---|
| {{decision}} | {{role}} | {{role}} | {{role}} | {{cadence}} | {{system}} |

## 9. Resource Allocation / การจัดสรรทรัพยากร

| Strategic priority | People / capability | Capital / marketing envelope | Reserve / reallocation rule | What is not funded |
|---|---|---:|---|---|
| {{priority}} | {{people}} | {{resource}} | {{rule}} | {{exclusion}} |

## 10. Strategic Initiatives / ชุดความริเริ่ม

| Initiative | Objective / choice | Owner | Horizon | Dependencies | Resource | Leading indicator | Lagging outcome | Evidence gate / stop rule | Status |
|---|---|---|---|---|---:|---|---|---|---|
| {{initiative}} | {{trace}} | {{owner}} | {{horizon}} | {{dependencies}} | {{resource}} | {{leading}} | {{lagging}} | {{gate}} | {{status}} |

## 11. Strategic Scorecard / ตัวชี้วัด

| Layer | Metric | Baseline | Target / status | Source / assumption ID | Owner | Cadence | Guardrail |
|---|---|---:|---:|---|---|---|---|
| Capability | {{metric}} | {{baseline}} | {{target_or_unknown}} | {{id}} | {{owner}} | {{cadence}} | {{guardrail}} |
| Customer / market | {{metric}} | {{baseline}} | {{target_or_unknown}} | {{id}} | {{owner}} | {{cadence}} | {{guardrail}} |
| Operating / channel | {{metric}} | {{baseline}} | {{target_or_unknown}} | {{id}} | {{owner}} | {{cadence}} | {{guardrail}} |
| Financial | {{metric}} | {{baseline}} | {{target_or_unknown}} | {{id}} | {{owner}} | {{cadence}} | {{guardrail}} |

## 12. Roadmap / แผนระยะเวลา

### 0–90 days — truth, evidence and control

{{near_term_work}}

### 3–12 months — repeatable proposition and economics

{{mid_term_work}}

### 12–36 months / owner horizon — portfolio and capability choices

{{long_term_work_or_not_yet_authorized}}

## 13. Scenarios, Risks and Assumptions / ฉากทัศน์และความเสี่ยง

| Scenario / risk | Signpost | Strategic response | Assumption IDs | Reversal trigger |
|---|---|---|---|---|
| {{scenario}} | {{signpost}} | {{response}} | {{ids}} | {{trigger}} |

## 14. Governance and Decision Gates / ธรรมาภิบาล

| Gate | Evidence required | Recommends | Decides | Deadline | Pass / fail threshold | Next action |
|---|---|---|---|---|---|---|
| {{gate}} | {{evidence}} | {{role}} | {{owner}} | {{date}} | {{threshold}} | no-go / revise-pilot / request approval |

## 15. Marketing Plan Handoff / การส่งต่อสู่แผนการตลาด

| Strategic objective | Choice | Offer / audience | Channel role | Budget line | KPI | Initiative / owner |
|---|---|---|---|---:|---|---|
| {{objective}} | {{choice}} | {{offer_audience}} | {{channel}} | {{budget}} | {{kpi}} | {{initiative_owner}} |

## Explicit no-go choices

{{no_go_choices}}

## Owner decisions required

{{owner_decisions}}
