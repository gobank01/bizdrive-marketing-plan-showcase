# BizDrive Strategic + Marketing Plan — License

Copyright © 2026 Prachaya Piyasirisilp / BizDrive.

This package uses file-scoped licensing.

## Content and educational artifacts — CC BY-NC 4.0

The following are licensed under the **Creative Commons Attribution-NonCommercial 4.0 International** license (`CC-BY-NC-4.0`):

- `SKILL.md`
- `README.md`, `INSTALL.md`, `CHANGELOG.md`, and `RELEASE_STATUS.md`
- `references/`
- `templates/`
- `examples/`

You may share and adapt this content for non-commercial purposes if you provide
appropriate attribution, link to the license, and indicate changes. You may not
use the content for commercial purposes.

Attribution: **Prachaya Piyasirisilp / BizDrive — BizDrive Strategic +
Marketing Plan Student Edition**

License deed: https://creativecommons.org/licenses/by-nc/4.0/

Legal code: https://creativecommons.org/licenses/by-nc/4.0/legalcode

## Software — MIT License

The Python files under `scripts/` and `tests/` are licensed under the MIT
License:

MIT License

Copyright (c) 2026 Prachaya Piyasirisilp / BizDrive

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Third-party sources and marks

The worked example cites public sources. Third-party website content, product
names, trademarks and logos remain the property of their respective owners and
are not relicensed by this package. The example contains analytical summaries,
privacy-reduced records and source citations; it does not grant rights to
republish third-party source content beyond applicable law.
