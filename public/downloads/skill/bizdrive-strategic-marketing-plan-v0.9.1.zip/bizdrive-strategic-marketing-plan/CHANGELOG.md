# Changelog

## 0.9.1 — 2026-09-02

Student distribution fixes.

### Changed

- `SKILL.md` description now carries Thai and English trigger phrases so Claude
  Code and other runtimes activate the skill from natural student wording
- documented a one-line Claude Code install (`curl` + `unzip` into
  `~/.claude/skills`) that needs no Python step

## 0.9.0 — 2026-08-28

Student beta for portable Agent Skills runtimes.

### Added

- runtime-agnostic Agent Skills `SKILL.md`
- Codex, Claude Code, Hermes and generic installer
- category boundary and material competitor universe workflow
- Evidence Gate and Customer Voice privacy gate
- explicit Strategy Choice framework
- brand/organization Strategic Plan framework and template
- README-first, assumptions register and decision register handoff
- cross-platform stdlib initializer, budget allocator and validator
- distribution validator, deterministic ZIP builder and package tests
- privacy-reduced premium-toothpaste worked example

### Security hardening

- initializer requires a canonical single-component slug, enforces base-directory containment and rejects a symlinked selected base, project or output path
- budget allocator rejects symlinked project/output paths and writes its fixed output by same-directory atomic replacement
- release inventory pins the exact reviewed 57-file payload and rejects any extra directory/file, symlink, hidden/sensitive path, unsupported format, binary/non-UTF-8 payload, credential assignment or direct customer statement
- validator and deterministic builder share one distribution policy to prevent scan/package drift

### License and rights

- content/examples: CC BY-NC 4.0
- scripts/tests: MIT
- upstream adaptation/student distribution authorized by the BizDrive rights holder
