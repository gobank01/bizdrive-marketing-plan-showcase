# README FIRST — Premium Toothpaste Thailand Trial

> Status: completed research/Marketing Plan plus **provisional brand Strategic Plan**
> Geography / evidence date: Thailand / 2026-08-28
> Owner-approved inputs: price 350 THB; marketing envelope 1,000,000 THB/month for 3 months; ten-brand trial
> External-action status: no product commitment, launch, spend, publication, hiring, outreach or partner approval

## Read this in five minutes

1. **Category boundary:** daily toothpaste alternatives relevant to a 350 THB Thailand premium trial; direct premium, indirect mass/therapeutic and herbal substitutes
2. **Landscape:** selective-premium opportunity is plausible but premium TAM/SAM, product truth, economics and supply remain unknown
3. **Material competitor universe:** 10 records in the original frozen trial; all 10 are in the deep dive
4. **Coverage warning:** no separately documented emerging/adjacent saturation sweep; do not call the universe exhaustive
5. **Primary strategic choice:** Premium daily ritual × proof transparency — provisional
6. **Strategic Plan:** trial brand / working 12-month horizon plus conditional 12–36 month option view / provisional, not enterprise strategy
7. **Secondary experiment:** Gentle-brightening experience without overclaim
8. **No-go zones:** unsupported health/efficacy/clinical/natural claims, price war, fake proof, forced spend and national scale before gates
9. **Biggest unknowns:** formula/pack/proof/Thai wording, COGS-to-net, WTP, capacity/SLA, repeat and enterprise owner choices
10. **Next decision gate:** owner confirms Strategic Plan entity/horizon and resources Product Evidence Pack, economics/supply and primary research preparation

## Strategic answer

The current evidence supports **pre-launch truth, evidence, economics and operating-readiness work**, not a scale launch. The brand should test whether a premium sensorial ritual plus inspectable proof can earn preference, WTP and repeat at positive contribution. If any load-bearing gate fails, no-go or revise is a valid result.

## Artifact map

| Start here | Purpose |
|---|---|
| `category_landscape.md` | category boundary, archetypes, needs, channels, regulation, economics and coverage limits |
| `competitor_universe.csv` | original ten-brand material set, classes and inclusion rationale |
| `competitor_matrix.csv` | exact-SKU price, claim, channel and whitespace deep dive |
| `strategy_choice.md` | compared options and selected Where to Play / How to Win cascade |
| `strategic_plan.md` | ambition, portfolio choices, capabilities, operating model, resources, initiatives, scorecard, roadmap and governance |
| `assumptions_register.csv` | owner facts, observations, assumptions, unknowns, owners and review gates |
| `decision_register.json` | active decisions, status, evidence, owner boundaries and reversal triggers |
| `step1…step12` | complete 12-step Marketing Plan and execution proposal |
| `evidence_ledger.json` | 41 claim/source records with retrieval dates and grades |
| `customer_voice.json` | 100 privacy-reduced/pseudonymized analytical records; not fully anonymous or representative |
| `voice_analysis.json` | coded themes, denominators and concentration limitations |
| `positioning_map.csv` / `positioning_maps.svg` | three analytical-rubric maps, trial target and Winning Zones |
| `budget_allocation.json` | exact 3,000,000 THB planning allocation and scenarios |
| External `research_private/` workspace | conceptual restricted raw-research location outside this package; never include in shareable/public bundles |

## Evidence and uncertainty boundary

### Owner facts

- price: 350 THB
- budget envelope: 1,000,000 THB/month × 3 months = 3,000,000 THB
- geography: Thailand

### Verified/current evidence

Thai FDA/OCPB rules and dated competitor sources are recorded in `evidence_ledger.json`. Price and competitor fields remain observations at 2026-08-28, not permanent market facts.

### Calculations and scenarios

Budget sums are exact. CPC/CVR/revenue/ROAS scenarios are explicit planning assumptions, not forecasts. Commercial break-even is unknown without COGS-to-net and target contribution.

### Strategic inference

Ritual × proof transparency is a hypothesis produced by category, competitor and directional Voice analysis. It is not measured brand perception or proof of right-to-win.

### Material limitations

- no audited Thailand premium toothpaste TAM/SAM/share
- public Voice is concentrated: 66/100 records concern Colgate Optic White
- final product, evidence, compliance, economics, capacity and distribution are unknown
- original ten-brand trial predates v0.3 emerging/adjacent saturation documentation
- enterprise portfolio, capabilities, capital and governance are not supplied

## How to reuse this work

1. Read `category_landscape.md`, `competitor_universe.csv`, `strategy_choice.md` and `strategic_plan.md` before tactics.
2. Refresh dated prices, claims, channels, rules and competitor classes.
3. Supply the planning entity, strategic horizon, owner ambition, portfolio, capabilities, economics and decision rights.
4. Update assumptions/decisions rather than overwriting unknowns with confident prose.
5. Use privacy-reduced Voice for sharing; raw research stays restricted.
6. Re-run the bundled validator and all publication/privacy QA before a handoff or website.

## Owner decision boundary

This pack proposes research, capability-building and pilot gates. It does not approve product formulation, claims, hiring, contracts, partner contact, sampling, media spend, publication, upload, deployment or launch. Each new external boundary requires explicit scoped owner approval.
