# Category Landscape — Premium Toothpaste Thailand Trial

> Geography: Thailand
> Evidence date: 2026-08-28
> Status: directional category intelligence for a planning trial; not an audited market census
> Trial target: new premium toothpaste concept at 350 THB; final pack, formula, claims and economics unknown

## 1. Declared category boundary

This landscape covers daily toothpaste alternatives relevant to a Thailand premium trial, including:

- direct premium ritual, lifestyle, technology and specialist toothpaste
- mass-premium whitening and therapeutic alternatives that can substitute for the trial
- herbal/natural daily-care substitutes
- official, retail, marketplace and public-demand signals available at the evidence date

The exact-SKU deep dive is frozen at ten brands. Price means a dated observed pack price, not a permanent market price. Cross-market official pages are used only where the Thai exact-variant page was unavailable and are labeled accordingly.

Out of scope: toothbrushes, professional whitening procedures, mouthwash, sellers without a stable product identity, a global census of every SKU, and unsupported estimates of competitor spend or market share.

## 2. Market context and evidence limit

Two Thai trade-press sources put the total toothpaste context directionally near 10.2 billion THB in 2024 and about 12 billion THB in 2026. Their public pages do not disclose an auditable retail-measurement method, and neither establishes a premium-toothpaste SAM. Therefore:

- no precise premium TAM/SAM/SOM is claimed
- no market-share target is derived from those figures
- current price-pack and channel censuses should be refreshed before a real investment decision

Sources and retrieval dates are in `evidence_ledger.json` and Step 1.

## 3. Category architecture

| Competitive archetype | Representative deep-dive brands | Core need/proposition | Strategic implication |
|---|---|---|---|
| Thai premium freshness/ritual | DENTISTE' | freshness and daily/night ritual | premium storytelling is already established; proof scope matters |
| Imported lifestyle premium | Marvis | design, flavor and heritage | distinctive sensorial codes can command price but are imitable |
| Imported technology/specialist | APAGARD, CURAPROX Enzycal | mineral, formulation or specialist proof | specificity and traceability raise the evidence bar |
| K-beauty whitening specialty | VUSSEN | beauty and numbered intensity | whitening intensity is crowded and claim-sensitive |
| Therapeutic/mass-premium substitute | Sensodyne | sensitivity trust extended to whitening | strong authority and access are difficult for a new brand to copy |
| Mass-premium whitening | Colgate Optic White, Oral-B/Crest 3D White | accessible whitening and technology | broad availability and lower price anchor the choice set |
| Thai accessible beauty alternative | Sparkle | beauty/whitening at accessible price | local relevance increases value pressure at 350 THB |
| Herbal/natural substitute | Twin Lotus | herbal familiarity and flavor | natural language can create differentiation and evidence risk |

## 4. Price-pack landscape

The observed ten-brand pack prices span 135–612 THB at the evidence date. The trial price of 350 THB sits above mass/mass-premium anchors and around the lower edge of imported/specialist choices. This is only a bridge opportunity if the final pack, product experience, proof, availability and contribution margin support it.

Required refresh before reuse:

1. exact pack and variant match
2. seller/channel and promotion status
3. observed date
4. unit-price normalization
5. Thai availability and official variant status

## 5. Customer need landscape

The public Customer Voice corpus has 100 privacy-reduced records and is directional, not representative. Coded themes include trust/proof 74%, whitening expectations 63%, price/value 46%, adverse-experience language 33%, sensitivity 27%, packaging 21% and taste 18%. Theme rates are multi-label and not population rates.

Material sampling bias:

- 66/100 records concern Colgate Optic White
- 60/100 come from one public review source
- no retained records for DENTISTE' or Sparkle and only two for VUSSEN
- verified-purchase status is not available for the full corpus

Use the corpus to form hypotheses and tests, not to estimate demand or brand incidence.

## 6. Channel landscape

Relevant roles inside this trial are:

- social/creator: discovery, language and creative learning
- search/owned proof page: high-intent education and evidence inspection
- marketplace/D2C: product-page and conversion learning
- LINE/CRM: opt-in, service and repeat learning after a base exists
- retail/clinic/sampling: sensorial feedback, trust and tracked trial
- PR/events/trade materials: controlled explanation and partner readiness

No channel allocation is a launch authorization. Clinic presence is not endorsement. National OOH and national retail scale are outside the current evidence level.

## 7. Regulation and claim landscape

Thai toothpaste is governed under current cosmetic, labeling, ingredient and advertising rules. The evidence pack includes Thai FDA and OCPB sources. Product-specific work must verify formula, notification, Thai label, fluoride rule where applicable, exact claim wording, test method, offer conditions, creators/testimonials and correction/complaint processes.

No-go without exact support and approval: disease treatment/prevention, guaranteed or instant whitening, unsupported sensitivity/antibacterial/natural/fluoride/clinical/dentist/certification/safety language, fake before-after, fake reviews or hidden promotion conditions.

## 8. Category economics

Owner facts are price 350 THB and a three-month marketing envelope of 3,000,000 THB. Unknowns include COGS, gross margin, VAT, fees, fulfillment, discounts, samples, returns, inventory financing, MOQ, capacity and service level. Therefore:

- commercial break-even and allowable CAC are unknown
- Best/Base/Worst tables are planning arithmetic, not forecasts
- unused budget need not be spent
- scale cannot be recommended from revenue or platform ROAS alone

## 9. Material competitor universe and coverage

`competitor_universe.csv` records the frozen ten-brand trial set and classifies direct, indirect and substitute alternatives. `competitor_matrix.csv` provides the exact-SKU deep dive.

Coverage limitation: this original trial selected ten material brands before the v0.3 discovery-saturation rule existed. It did not run a separately documented three-lane sweep for emerging and adjacent entrants. The ten-brand set is therefore a strong analytical set, not a claim of an exhaustive Thailand universe. Before a real Strategic Plan is committed, run the v0.3 universe discovery lanes and record additions/exclusions.

## 10. Strategic implications

1. Do not enter an intensity race around whitening or unsupported clinical authority.
2. Test **Premium daily ritual × proof transparency** as the primary provisional territory.
3. Treat gentle-brightening comfort as a secondary experiment until product-specific evidence exists.
4. Build product truth, evidence governance, economics, supply readiness and tracked learning before scale.
5. Keep the right to say no-go; the landscape does not yet prove brand right-to-win.

## 11. Refresh triggers

Refresh this landscape when any of the following changes: evidence is older than the decision tolerance, final formula/pack arrives, price or channel scope changes, a material new competitor class appears, Thai rules change, primary research contradicts the public corpus, or economics/supply constraints change.
