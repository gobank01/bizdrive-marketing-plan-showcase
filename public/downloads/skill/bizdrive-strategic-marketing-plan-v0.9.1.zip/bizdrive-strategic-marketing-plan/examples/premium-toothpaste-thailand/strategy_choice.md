# Strategy Choice — Premium Toothpaste Thailand Trial

> Status: provisional category/brand choice; not product, spend or launch approval
> Geography / evidence date: Thailand / 2026-08-28
> Decision horizon: validate a repeatable brand proposition and economics over 12 months

## Strategic question

Where should a new 350 THB premium toothpaste concept play, and how could it win responsibly in Thailand, given the current category evidence, ten-brand competitive set, 3,000,000 THB three-month learning envelope, unknown product proof/economics and Thai compliance constraints?

## Evidence and uncertainty boundary

| Type | Inputs |
|---|---|
| Owner facts | price 350 THB; budget 1,000,000 THB/month for 3 months; Thailand; ten-brand trial |
| Verified/current evidence | Thai FDA/OCPB rules and dated official/retail competitor observations in `evidence_ledger.json` |
| Observations | ten-brand price/claim/channel matrix; 100-record privacy-reduced Voice corpus |
| Calculations | total budget 3,000,000 THB; allocation arithmetic; scenario formulas |
| Strategic inference | ritual × proof transparency may offer a testable bridge between lifestyle premium and proof-led care |
| Assumptions/unknowns | final formula, pack, product experience, proof, registration, COGS/margin, capacity, WTP and brand capabilities |

The public Voice sample is directional and brand-concentrated; analytical scores are not measured market perception.

## Category and competitor boundary

The frozen deep-dive set contains DENTISTE', Marvis, APAGARD, CURAPROX Enzycal, VUSSEN, Sensodyne, Colgate Optic White, Oral-B/Crest 3D White, Sparkle and Twin Lotus. It spans direct premium, indirect mass/therapeutic and herbal substitutes. The original trial did not run the v0.3 documented saturation sweep for emerging/adjacent entrants; do not call this a fully exhaustive Thailand universe.

## Strategic options

Scores are 1–5 directional rubrics. `Unknown` blocks a committed choice; no total score is used to hide missing economics/right-to-win.

| Option | Demand | Whitespace | Right-to-win | Economics | Channel feasibility | Compliance safety | Defensibility | Evidence | Decision |
|---|---:|---:|---|---|---:|---:|---:|---:|---|
| A. Premium daily ritual × proof transparency | 4 | 3 | Unknown | Unknown | 4 | 4 | 3 | 3 | **Primary provisional** |
| B. Gentle-brightening comfort | 4–5 | 2 | Unknown | Unknown | 4 | 2 | 2 | 2 | **Secondary experiment only** |
| C. Intense freshness/night ritual | 3 | 2 | Unknown | Unknown | 4 | 3 | 2 | 2 | creative angle, not core strategy |
| D. Herbal/natural therapeutic | 3 | 2 | Unknown | Unknown | 3 | 2 | 2 | 2 | no-go until exact formula/proof |
| E. Dentist/clinical superiority | 4 | 1–2 | Unknown | Unknown | 3 | 1 | 3 | 1 | no-go without product-specific dossier |

## Primary choice

**Premium daily ritual × proof transparency** is the primary provisional choice. It combines a sensorial routine people may want to repeat with a system that makes product truth, evidence scope, unknowns and corrections inspectable.

This is a hypothesis, not a committed positioning. It must pass product truth, blind preference, willingness-to-pay, unit economics, capacity and Thai claim gates.

## Secondary experiment

**Gentle-brightening experience without overclaim** may be tested at concept and sensorial level. No whitening/sensitivity efficacy wording is permitted until exact formula, method, result, label and compliance review support it.

## Choice cascade

### Winning aspiration

Within 12 months, establish whether a responsible premium toothpaste proposition can earn repeat preference and positive contribution in a bounded Thailand pilot, while maintaining zero unsupported-claim incidents. This aspiration remains provisional until owner approves targets and unit economics.

### Where to Play

- Thailand, starting with digitally measurable and selected offline pilot cells
- need state: people willing to pay more for a daily oral-care ritual plus inspectable product truth
- offer: one controlled premium daily-toothpaste SKU/pack before portfolio expansion
- price-pack: trial retail price 350 THB, subject to pack and WTP validation
- route to market: owned proof page, social/creator learning, marketplace/D2C conversion lab and measured retail/clinic/sampling pilots
- excluded: national scale, broad OOH, price-war retail expansion and unsupported therapeutic/clinical arenas

### How to Win

Deliver a sensorial experience worth repeating and a proof-transparency system that ties every meaningful statement to product version, evidence, approved wording and limitations. Compete on trustworthy premium experience rather than the strongest whitening or borrowed clinical authority.

### Capabilities

Required capabilities: product/version truth, evidence and Thai compliance, sensorial research, supply/QC/lot traceability, premium design/content, creator/asset governance, tracked channel pilots, CRM/service/adverse escalation, unit economics and finance reconciliation.

### Management systems

- product evidence pack and claim matrix
- asset register with owner/approver/version/expiry
- UTM/QR/order/CRM source of truth
- daily safety/delivery alerts, twice-weekly creative review, weekly decision review and monthly finance reconciliation
- gates for truth, economics, proposition, pilot contribution/repeat and owner scale decision
- stop rules for claim mismatch, adverse pattern, negative conservative contribution, stock/SLA failure and unreplicated winners

### No-go choices

No unsupported disease, whitening, sensitivity, antibacterial, natural, fluoride, clinical, dentist, certification or safety claims; no fake reviews/before-after/scarcity; no forced month-end spend; no clinic-as-endorsement; no national scale before proof, economics, capacity and replication.

## Strategy-to-plan bridge

| Strategic choice | Offer/audience implication | Channel role | Resource implication | KPI / gate |
|---|---|---|---|---|
| Ritual worth repeating | one controlled sensorial premium SKU; need-state cohorts | blind test, sampling, creator diaries | research/product readiness before scale | preference, D7/D30 experience, complaint guardrail |
| Proof transparency | proof page, evidence-linked message house | owned/search/marketplace/creator governance | product/regulatory/data capability | evidence completeness, claim incident zero |
| Selective measurable access | digital lab plus bounded retail/clinic cells | cohort/UTM/QR/order reconciliation | no national distribution commitment | tracked sample→purchase→repeat, fill rate |
| Economics before scale | pack/WTP/contribution validation | conversion tests only inside allowable CAC | reserve held until gate | contribution/order, conservative CAC, repeat |

Every major Marketing Plan budget line must map to this table or be labeled exploratory.

## Learning agenda

| Priority unknown | Cheapest valid evidence | Owner | Pass/fail use |
|---|---|---|---|
| Product truth and permitted claims | exact formula/pack/label/test dossier and qualified Thai review | Product/Regulatory | stop all efficacy assets if incomplete |
| Sensorial right-to-win | owner-approved blind preference protocol with product-version control | Product/Research | keep, revise or no-go territory |
| WTP at 350 THB | concept/pack and bounded real-choice test | Research/Finance | revise pack/value or no-go |
| Contribution and allowable CAC | COGS-to-net model with conservative fees/returns | Finance/Ops | set CAC or stop paid conversion |
| Supply/service readiness | MOQ/capacity/fill-rate/SLA and complaint drill | Ops/Service | allow bounded pilot or stop |
| Repeatability | replicated creative/cohort result plus D7/D30/repeat signal | Marketing/Analytics | no-go, pilot 2 or request scale approval |
| Universe coverage | v0.3 emerging/adjacent discovery sweep | Research | refresh strategy if a material class is missing |

## Decision gates

1. G0 product truth/compliance readiness
2. G1 contribution, capacity and service readiness
3. G2 blind preference/WTP territory decision
4. G3 bounded pilot contribution/repeat decision
5. G4 owner no-go, revise/pilot 2, or separate scale approval

No gate authorizes external action unless owner approval is separately recorded in `decision_register.json`.
