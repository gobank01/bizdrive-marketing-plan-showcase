# Strategic Plan — Premium Toothpaste Trial Brand, Thailand

> Plan status: **Provisional brand Strategic Plan** — not owner-approved organization strategy
> Entity / geography: trial brand / Thailand
> Strategic horizon / evidence date: working 12-month horizon with a conditional 12–36 month option view / 2026-08-28
> Owner-approved inputs: trial concept, retail price 350 THB, marketing envelope 1,000,000 THB/month for 3 months
> External-action status: no spend, publication, hiring, partner contact, product commitment or launch approval

## 1. Strategic Horizon / ขอบเขตเวลา

This plan translates the frozen category/competitor evidence and `strategy_choice.md` into a provisional brand operating system. It covers one Thailand premium toothpaste trial brand and one controlled SKU before any portfolio expansion.

The 12-month horizon is assumption **A-004**, not an owner commitment. The 12–36 month section is an option view only. Organization portfolio, capital, talent, capability maturity and decision rights are not supplied (**U-007**), so this must not be presented as BizDrive's enterprise strategy.

## 2. Diagnosis / การวินิจฉัย

| Finding | Type | Evidence / assumption ID | Strategic implication |
|---|---|---|---|
| Trial price is 350 THB and proposed marketing envelope totals 3,000,000 THB | owner fact / calculation | F-001, F-002, C-001 | value, pack and economics must justify a selective-premium position |
| Ten-brand set spans direct premium, specialist, mass-premium and herbal substitutes | dated observation | O-001; `competitor_matrix.csv` | avoid competing only on price, whitening intensity or borrowed clinical authority |
| Public Voice codes emphasize proof/trust, whitening and value, with material brand/source concentration | directional observation | O-002, A-003; `voice_analysis.json` | test hypotheses; do not treat theme rates as market incidence |
| Primary territory is ritual × proof transparency | strategic inference | D-001; `strategy_choice.md` | product experience and proof governance must develop together |
| Formula, pack, claims and product-specific evidence are unknown | unknown | U-001, U-003 | no product or efficacy commitment before G0 |
| COGS-to-net, allowable CAC and commercial break-even are unknown | unknown | U-002 | paid conversion and scale remain conditional |
| Capacity, MOQ, fill rate and service readiness are unknown | unknown | U-004 | no distribution/media scale before G1 |
| Premium market size and emerging/adjacent coverage are incomplete | unknown / coverage gap | U-005, U-006 | no market-share ambition; refresh the universe before commitment |
| Enterprise portfolio, capabilities and governance are unknown | unknown | U-007 | keep plan at provisional brand level |

### Critical uncertainties

Highest decision impact: product truth/compliance, unit economics, supply/service readiness, blind preference, WTP at 350 THB, repeat behavior and enterprise owner choices.

## 3. Ambition / เป้าประสงค์

**Provisional ambition:** within the working 12-month horizon, determine whether one responsibly governed premium toothpaste proposition can earn repeat preference and positive contribution in bounded Thailand pilots, while maintaining zero unsupported-claim incidents and preserving the right to no-go.

No revenue, market-share or ROAS commitment is set because baseline, margin and owner targets are missing. Success is a valid owner decision supported by product truth, customer evidence, economics, operating readiness and replicated learning.

## 4. Portfolio Choices / ทางเลือกพอร์ต

| Arena / offer | Invest, maintain, test, partner or exit | Why | Evidence / unknown | No-go / condition |
|---|---|---|---|---|
| One controlled premium daily-toothpaste SKU | **Test** | isolates product, proof and repeat learning | D-001; U-001–U-004 | no SKU expansion before repeatable economics |
| Proof-transparency system | **Invest in capability proposal** | necessary for the selected strategy and claim safety | D-001, D-003 | owner must approve capability resources |
| Gentle-brightening comfort territory | **Experiment** | demand signal exists but evidence/compliance risk is high | D-002; U-003 | no efficacy wording before dossier/review |
| National retail/OOH scale | **Defer** | proof, economics, stock and replication absent | U-002, U-004 | separate scale decision required |
| Therapeutic/clinical or herbal portfolio | **No-go for this trial** | no product truth/right-to-win | D-003 | reopen only with exact product-specific evidence |
| Additional categories/geographies | **Outside scope** | no enterprise portfolio brief | U-007 | owner Strategic Plan boundary required |

## 5. Where to Play / สนามที่เลือก

- Geography: Thailand, initially in bounded measurable cells
- Need state: buyers willing to pay for a repeatable oral-care ritual plus inspectable product truth
- Occasion: daily routine; beauty/comfort as controlled secondary hypotheses
- Offer / SKU / price-pack: one exact controlled SKU; 350 THB subject to pack and WTP validation
- Route to market: owned evidence layer, social/creator learning, marketplace/D2C lab, selected retail/clinic/sampling pilots
- Explicit exclusions: national scale, broad OOH, price war, unsupported medical/clinical/natural authority and multi-SKU expansion

## 6. How to Win / วิธีชนะ

Create a premium sensorial routine worth repeating and a proof-transparency system that connects every material statement to an exact product version, evidence, approved wording, limitations and correction path. The economic logic is not yet proven: the brand may win only if WTP, contribution, supply and repeat behavior pass gates. The competitive trade-off is refusing the strongest-sounding unsupported claims and blanket discounting.

## 7. Capabilities / ความสามารถที่ต้องมี

| Capability | Current → target maturity | Gap | Build / buy / partner | Owner | Resource envelope | Dependency / evidence gate |
|---|---|---|---|---|---:|---|
| Product/version truth | unknown → controlled dossier | formula, pack, lot and claim truth absent | build with manufacturer; qualified review | Product | unknown | G0 exact product record |
| Evidence/compliance | unknown → evidence-to-asset governance | test/label/wording/expiry absent | build + qualified Thai partner | Product/Regulatory | unknown | G0 approved claim matrix |
| Sensorial and WTP research | hypothesis → valid protocol/data | no primary product test | build research; partner if needed | Research | proposed, unapproved | G2 protocol and thresholds |
| Supply/QC/service | unknown → pilot-ready | MOQ/capacity/SLA/complaint gaps | build with supplier/ops | Ops/Service | unknown | G1 fill-rate and escalation drill |
| Brand/content system | 30 proposed scripts → governed assets | no final identity/product proof | build after G0 | Marketing | inside proposed envelope only | asset register and owner publish approval |
| Channel learning | proposed → measurable cells | no baseline or source-of-truth | build/partner selectively | Marketing/Analytics | proposed, unapproved | UTM/QR/order reconciliation |
| Finance/economics | price/budget only → COGS-to-net model | margin/fees/returns missing | build internally | Finance | unknown | G1 allowable CAC |
| Governance/talent | unknown → named decision rights | enterprise roles not supplied | owner design | Owner | unknown | U-007 decision |

## 8. Operating Model / ระบบปฏิบัติการ

| Decision / process | Recommends | Decides | Executes | Cadence | Dashboard / escalation |
|---|---|---|---|---|---|
| Product truth and claim readiness | Product/Regulatory | Owner or delegated accountable executive | Product + qualified reviewer | per version / before asset | evidence pack; immediate stop on mismatch |
| Strategic territory | Strategy/Research | Owner | Product/Marketing after approval | G2 and quarterly | decision register; reverse on weak preference/WTP |
| Pilot resource release | Marketing/Finance | Owner | channel owners | weekly gate | spend, contribution, stock, claim and replication |
| Creative/content | Marketing + Product/Regulatory | designated approver | content/channel team | twice weekly | asset register; pause overclaim |
| Economics/scale | Finance/Analytics/Ops | Owner | cross-functional team | monthly / G3–G4 | reconciled contribution, repeat, inventory, complaint |
| Adverse/complaint event | Service/Product | accountable product owner | Service/Ops | real time | preserve lot/version; escalate and stop cohort |

Enterprise RACI remains provisional until U-007 is resolved.

## 9. Resource Allocation / การจัดสรรทรัพยากร

| Strategic priority | People / capability | Capital / marketing envelope | Reserve / reallocation rule | What is not funded |
|---|---|---:|---|---|
| Product truth and compliance | Product, regulatory, manufacturer | unknown; owner decision required | prerequisite before campaign release | unsupported efficacy assets |
| Primary research and proposition learning | Research, Product, Analytics | proposed inside future approved test envelope | stop/revise if protocol or thresholds fail | representative-market claims from convenience sample |
| Measurable channel pilots | Marketing, Analytics, Ops | proposed 3,000,000 THB plan; **not spend-approved** | 150,000 THB reserve only after gates | forced spend, national OOH/retail scale |
| Economics and supply readiness | Finance, Ops, Service | unknown capability cost | prerequisite before conversion scale | scale with negative/unknown contribution |
| Proof/content operating system | Product, Regulatory, Marketing | unknown capability cost | assets expire when product/evidence changes | unversioned claims or creator content |

## 10. Strategic Initiatives / ชุดความริเริ่ม

| Initiative | Objective / choice | Owner | Horizon | Dependencies | Resource | Leading indicator | Lagging outcome | Evidence gate / stop rule | Status |
|---|---|---|---|---|---:|---|---|---|---|
| I1 Product Evidence Pack | enable proof transparency | Product | 0–90d | exact formula/pack/test/label | unknown | dossier completeness | zero claim mismatch | G0; stop assets if incomplete | proposed |
| I2 Sensorial + WTP validation | validate ritual/right-to-win | Research/Product | 0–90d | exact product and protocol | unapproved | sample/protocol quality | preference and WTP decision | G2; no-go/revise if weak | proposed |
| I3 COGS-to-net and supply readiness | prove economic/operating feasibility | Finance/Ops | 0–90d | supplier and channel terms | unknown | model/data completeness | positive conservative contribution and SLA | G1; stop paid conversion | proposed |
| I4 Proof/content system | operationalize How to Win | Product/Reg/Marketing | 0–6m | I1 | unapproved | % assets version-linked | claim incident zero; trust learning | stop unapproved content | proposed |
| I5 Bounded all-channel learning pilot | test repeatable proposition | Marketing/Analytics/Ops | 3–12m | I1–I4 and owner approval | max proposed envelope 3m THB | tracking/replication/readiness | contribution, repeat, complaint closure | G3; no national scale | not authorized |
| I6 Universe refresh | close emerging/adjacent gap | Research | 0–90d | v0.3 discovery lanes | internal research | saturation log complete | strategy refreshed/no material omission | reopen choice if new class | proposed |
| I7 Governance and owner decision system | establish operating model | Owner/cross-functional | 0–90d | U-007 | unknown | named rights/cadence | timely no-go/pilot/scale decisions | G4 owner approval | proposed |

## 11. Strategic Scorecard / ตัวชี้วัด

| Layer | Metric | Baseline | Target / status | Source / assumption ID | Owner | Cadence | Guardrail |
|---|---|---:|---:|---|---|---|---|
| Capability | product/evidence readiness | unknown | G0 complete before assets | U-001, U-003 | Product/Reg | per version | no unsupported claim |
| Capability | economics/supply readiness | unknown | G1 complete before conversion | U-002, U-004 | Finance/Ops | weekly until ready | no scale with unknown contribution/SLA |
| Customer/market | blind preference and WTP | none | owner threshold required | A-002, U-001 | Research | G2 | valid protocol, no market-share inference |
| Operating/channel | replicated winning cohort/creative | none | ≥2 replications is a planning gate | D-004 | Analytics/Marketing | weekly | tracking and product-version match |
| Financial | contribution/order and allowable CAC | unknown | positive under conservative inputs; exact threshold owner-set | U-002 | Finance | monthly | platform ROAS is insufficient |
| Customer/market | D7/D30 experience and repeat | none | owner threshold required | D-001 | Product/CRM | cohort | complaint/adverse stop rule |
| Risk/compliance | claim incident | none | zero | D-003 | Product/Reg | real time | immediate pause/correction |

## 12. Roadmap / แผนระยะเวลา

### 0–90 days — truth, evidence and control

Complete I1, I2 protocol, I3, I6 and I7; define exact SKU, dossier, economics, supply, decision rights, tracking and owner thresholds. Produce no public efficacy asset and release no spend without approval.

### 3–12 months — repeatable proposition and economics

If G0–G2 pass and owner separately approves, run bounded I4–I5 cells. Require product-version control, replicated proposition learning, conservative contribution, service readiness and repeat signal. Finish with G4: no-go, revise/pilot 2 or request limited scale approval.

### 12–36 months / owner horizon — portfolio and capability choices

Option view only: decide whether to institutionalize the proof system, expand SKU/need-state/geography/channel portfolio, build or partner for specialized capabilities and allocate growth capital. No option is recommended until the owner supplies enterprise portfolio, capability, economics and governance context.

## 13. Scenarios, Risks and Assumptions / ฉากทัศน์และความเสี่ยง

| Scenario / risk | Signpost | Strategic response | Assumption IDs | Reversal trigger |
|---|---|---|---|---|
| Product/claim gate fails | formula/test/label mismatch | no-go or reformulate/re-scope | U-001, U-003 | G0 incomplete |
| Ritual is liked but price fails | preference positive; WTP below 350 | revise pack/value/economics, do not discount blindly | F-001, U-002 | owner threshold fails |
| Economics fail despite demand | negative conservative contribution | no-go/rework COGS/channel/offer | U-002 | contribution remains negative |
| Supply/service cannot support pilot | capacity/fill rate/complaint process weak | hold media and partner expansion | U-004 | G1 fails |
| New competitor class changes whitespace | v0.3 sweep finds material omission | reopen strategic options/maps | U-006 | choice materially changes |
| Enterprise priorities conflict | portfolio/capital/capability owner says no | stop or reposition as isolated experiment | U-007, A-004 | owner rejects entity/horizon/resource case |
| Pilot passes | replicated preference, economics, repeat and guardrails | request separate limited-scale decision | D-001, D-004 | no automatic scale |

Marketing Best/Base/Worst arithmetic remains separate from these strategic scenarios.

## 14. Governance and Decision Gates / ธรรมาภิบาล

| Gate | Evidence required | Recommends | Decides | Deadline | Pass / fail threshold | Next action |
|---|---|---|---|---|---|---|
| G0 Product truth | exact product, formula, notification, label, claim/test matrix | Product/Reg | Owner/delegate | before any asset | complete and approved | no-go / revise / proceed to G1–G2 |
| G1 Economics/operations | COGS-to-net, allowable CAC, MOQ/capacity/SLA, complaint drill | Finance/Ops | Owner | before paid conversion | conservative feasibility | no-go / revise / bounded pilot request |
| G2 Territory | valid blind preference, WTP and proof-readiness | Research/Strategy | Owner | before positioning commitment | owner-defined threshold | select primary/secondary/no-go |
| G3 Pilot | tracking, replication, contribution, repeat, complaints, stock | cross-functional | Owner | end of bounded pilot | owner-defined threshold and guardrails | no-go / pilot 2 / scale request |
| G4 Strategic review | enterprise portfolio/capability/resource fit | leadership team | Owner | end of horizon review | owner decision | stop / institutionalize / expand |

## 15. Marketing Plan Handoff / การส่งต่อสู่แผนการตลาด

| Strategic objective | Choice | Offer / audience | Channel role | Budget line | KPI | Initiative / owner |
|---|---|---|---|---:|---|---|
| Validate ritual/right-to-win | Primary D-001 | one controlled SKU; Ritual & Proof cohort | blind test, creator/social/sampling learning | proposed research/test resources | preference, WTP, D7/D30 | I2 / Research-Product |
| Operationalize proof transparency | Primary D-001 | proof-linked message house | owned/search/PDP/creator governance | proposed capability + content lines | readiness, evidence-page behavior, claim incident | I1/I4 / Product-Reg-Marketing |
| Validate selective access | D-004 | bounded measurable cells | marketplace/D2C + selected retail/clinic | proposed online/offline envelope | tracked sample→purchase→repeat, fill rate | I5 / Marketing-Ops |
| Prove economics before scale | no-go guardrail | exact pack/offer | conversion only inside allowable CAC | reserve held | contribution/order, conservative CAC | I3/I5 / Finance-Analytics |

## Explicit no-go choices

No enterprise-strategy claim; no multi-SKU/geography expansion; no national scale; no forced spending; no unsupported health/efficacy/clinical/natural/certification claims; no price war; no fake proof or endorsement; no orphan marketing tactic without a strategic objective or exploratory label.

## Owner decisions required

1. Confirm planning entity and strategic horizon.
2. Supply enterprise portfolio, capabilities, economics, operating model and decision rights.
3. Decide whether to resource Product Evidence Pack, primary research and economics/supply readiness.
4. Define G2/G3 thresholds and accountable owners.
5. Approve or reject each external pilot/spend/publication/partner boundary separately.
6. At G4 choose no-go, revise/pilot 2, institutionalize the capability, or request a bounded scale plan.
