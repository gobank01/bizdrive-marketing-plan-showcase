# Strategy Choice Framework

Use this after category and competitor evidence is frozen. A marketing plan is not a strategy until it makes explicit choices and exclusions.

## 1. Strategic question

Write one decision question with a time horizon and constraint, for example:

> Where should this product play, and how can it win profitably in Thailand during the next 12 months, given the current evidence, capabilities, budget and compliance limits?

Separate owner facts, verified facts, observations, calculations, assumptions and unknowns.

## 2. Category boundary and competitor universe

Define the universe before choosing a shortlist:

- geography and retrieval date
- category/job-to-be-done boundary
- product/SKU and pack rule
- price/channel boundary
- direct competitors
- indirect competitors
- substitutes
- emerging entrants
- adjacent benchmarks

`competitor_universe.csv` must include: brand, product/SKU, competitor_type, geography, price_tier, primary_need, channel_presence, discovery_source, evidence_grade, included_in_deep_dive, inclusion_or_exclusion_reason, observed_at.

“All competitors” means all material competitors inside the declared boundary—not every seller or product on Earth. Stop discovery only when the requested count/coverage is met and three consecutive discovery lanes add no material competitor class. Record uncovered areas.

## 3. Strategic options

Create at least three mutually distinct options. Score each 1–5 with rationale and evidence/unknown markers:

1. customer demand/need priority
2. competitive whitespace
3. brand right-to-win
4. unit economics
5. channel/operational feasibility
6. compliance safety
7. defensibility
8. evidence strength

Do not hide a missing load-bearing input inside a total score. Any unknown in right-to-win, economics or compliance keeps the choice provisional.

## 4. Choice cascade

For the selected option state:

- **Winning aspiration:** measurable owner-level outcome and time horizon
- **Where to play:** geography, segment/need state, occasion, category/SKU, price-pack tier and channels
- **How to win:** differentiated value, proof mechanism and competitive trade-off
- **Capabilities required:** product, evidence, supply, channel, content, analytics, finance, service and compliance
- **Management systems:** owners, cadence, dashboards, decision rights, stop/scale rules and learning loops
- **No-go choices:** segments, claims, channels, price tactics or capability bets explicitly excluded

## 5. Strategy-to-plan bridge

Translate each choice into:

- product/offer implication
- target audience and message
- channel role and path to purchase
- resource allocation
- capability build
- KPI leading/lagging chain
- experiment and decision gate
- risk/mitigation

Every major budget line and campaign workstream must map back to one strategic choice. If it does not, remove it or label it exploratory.

## 6. Learning agenda and gates

Create a ranked list of unknowns by decision impact × uncertainty. For every critical unknown define: hypothesis, evidence needed, cheapest valid test, owner, deadline, pass/fail threshold and next decision.

Use three outcomes at every gate: no-go, iterate/pilot, or request separate scale approval. A scenario is not a strategy and a plan is not launch approval.

## 7. Strategic Plan handoff

`strategy_choice.md` answers which category/brand direction to select and why.
It does not replace a brand/organization Strategic Plan. After choosing, read
`references/strategic_plan_framework.md` and build `strategic_plan.md` with the
planning entity/horizon, ambition, portfolio choices, capabilities, operating
model, resources, initiatives, scorecard, roadmap, scenarios and governance.
If enterprise inputs are absent, label it a provisional brand Strategic Plan.

## Verification

A valid strategy proves:

- the universe boundary and selection logic are explicit
- at least three distinct options were compared
- one primary choice, one secondary experiment and no-go zones exist
- Where to Play and How to Win are specific enough to exclude alternatives
- required capabilities and management systems are named
- economics/compliance unknowns remain provisional
- every major plan element traces back to the chosen strategy
