# Strategic Handoff Web Blueprint

Optional only when the owner separately requests a website. The site is a public/shareable surface: generate from privacy-reduced artifacts, never raw research. Deploy is a new approval boundary.

## Recommended stack

- Next.js App Router + TypeScript
- static/prerendered category routes when possible
- system/local font stack; no runtime third-party font dependency by default
- reusable plan registry so new categories add a route without copying the shell
- downloadable Markdown/CSV/JSON/DOCX only after public-artifact privacy validation

## Information architecture

Order pages/sections by decision flow, not file number:

1. **Orientation / README FIRST** — status, owner inputs, primary choice, unknowns, next gate
2. **Category Landscape** — boundary, segments, forces, price-pack, channels, regulation, economics
3. **Competitor Universe** — direct/indirect/substitute/emerging/adjacent, selection logic, coverage gaps
4. **Deep Dive & Maps** — exact SKU, claims, price, channel, Voice, positioning maps
5. **Strategy Choice** — options, Where to Play, How to Win, capabilities, systems, no-go
6. **Marketing Plan** — Steps 1–12, content, budget, scenarios, KPI and timeline
7. **Evidence & Assumptions** — ledger, assumptions, decisions, limitations and refresh dates
8. **Downloads** — public-safe artifact bundle

The route may be English if Unicode routing is unstable; visible content can remain Thai. Add canonical metadata, sitemap and robots from a centralized production origin.

## Data contract

Load from:

- `README_FIRST.md`
- `category_landscape.md`
- `competitor_universe.csv`
- `competitor_matrix.csv`
- `strategy_choice.md`
- `assumptions_register.csv`
- `decision_register.json`
- 14 step Markdown files
- evidence/budget/Voice JSON
- positioning coordinates and validated visuals

Preserve all meaningful fields through tables, disclosures and downloads. Label verified facts, owner facts, observations, calculations, strategic inference, assumptions and unknowns distinctly.

## Required visuals

Use purposeful, original data/editorial visuals—not decorative stock:

- category architecture
- price-pack ladder
- competitor class/universe map
- exact-SKU comparison
- Customer Voice themes and sample concentration
- at least three positioning maps
- strategic-option scorecard
- choice cascade
- capability/system map
- budget allocation
- funnel/path to purchase
- decision timeline/gates

Every visual needs alt text and must not imply measured market truth when based on an analytical rubric.

## Public privacy gate

Before build/deploy:

- no verbatim Customer Voice excerpts
- no authors, profiles, review/comment IDs or deep links
- URLs generalized to product/video/resource level
- no raw private directory copied into content/public/downloads
- scan Markdown, JSON, CSV, SVG and DOCX internals
- describe the corpus as privacy-reduced/pseudonymized, not fully anonymous

## Production QA

Verify with real browser/HTTP output:

- root and canonical plan route 200; unknown/malformed routes 404
- sitemap, robots, favicon, visuals and every download 200
- desktop/mobile document width equals viewport; wide tables scroll internally
- all images decode; no broken links, failed responses or console errors
- canonical and Open Graph URLs use the production origin
- no unexpected third-party runtime request
- public Customer Voice count matches source-safe output and privacy fields are absent
- production deployment reports READY and Git remote SHA matches intended source
