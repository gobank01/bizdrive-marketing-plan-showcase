# 12-Step Workflow Reference

คู่มือเขียนแต่ละ Step ของแผนการตลาด — อ่านก่อนเริ่ม Step 1 ทุกครั้ง

---

## Step 1 — Market Analysis

ใช้ parallel research workers เมื่อ runtime รองรับ เพื่อทำ Wide Research **5 มิติ**
แล้วให้ lead model ตรวจ provenance และรวมผล:

1. **โครงสร้าง/ขนาดตลาดที่ตรวจสอบได้** — TAM/SAM/SOM และ growth ใช้ได้เฉพาะ
   เมื่อ source เปิดเผย scope/method ที่เข้ากับ boundary; มิฉะนั้นให้ระบุ unknown
2. **เทรนด์ผู้บริโภค** (Macro trend, micro trend) อ้างอิงข้อมูล 12-24 เดือนล่าสุด
3. **โครงสร้างราคา** ในตลาด (low/mid/premium tier)
4. **ช่องทางจัดจำหน่ายหลัก** (online vs offline market share)
5. **กฎหมาย/มาตรการรัฐ** ที่กระทบ (อย., สรรพากร, ภาษี ฯลฯ)

ถ้าไม่พบ market size/share ที่เปิดเผยวิธีวิจัยหรือเข้ากับ boundary ให้ระบุ
`ไม่พบข้อมูลสาธารณะที่ตรวจสอบได้` และใช้ category architecture / price-pack /
channel census แทน ห้ามสร้าง TAM/SAM/SOM หรือ growth rate เพื่อเติมช่องว่าง

**หัวข้อย่อยในไฟล์ `step1_market_analysis.md`:**
- บทสรุปผู้บริหาร (3 บรรทัด)
- 1.1 ขนาดตลาดและอัตราเติบโต
- 1.2 เทรนด์ผู้บริโภค `{current_year}`
- 1.3 โครงสร้างราคาและ segmentation
- 1.4 ช่องทางจัดจำหน่าย
- 1.5 กฎระเบียบและมาตรการรัฐที่เกี่ยวข้อง
- 1.6 โอกาสและข้อจำกัดสำหรับสินค้านี้
- References (ระบุแหล่งทุกตัวเลข)

---

## Step 2 — Category & Competitor Intelligence

เริ่มจาก **competitor universe** ไม่ใช่สุ่ม shortlist 4 ราย:

1. กำหนด geography, category/JTBD, SKU/pack, price/channel และ time boundary
2. ค้น direct, indirect, substitute, emerging และ adjacent competitors
3. บันทึกทุก material record ใน `competitor_universe.csv` พร้อม discovery source,
   inclusion/exclusion rationale และ evidence grade
4. รายงาน saturation result และ coverage gaps; ห้ามอ้างว่า “ครบทั้งหมด” นอก boundary
5. Freeze deep-dive set 10–20 ราย (หรือตาม scope เจ้าของ) ให้ครอบคลุม class สำคัญ

วิเคราะห์ exact SKU ใน `competitor_matrix.csv`:

| มิติ | รายละเอียด |
|------|------------|
| Product truth | variant, pack, formula/technology, claim scope |
| Price-pack | observed price, seller/channel/date, unit price |
| Positioning | need state, promise, proof mechanism, brand codes |
| Route to market | D2C, marketplace, retail, specialist, social/content |
| Demand/Voice | coded needs, triggers, objections, source bias |
| Economics signal | promotion, pack architecture, known channel friction |
| Strength/weakness | evidence-backed analyst assessment |
| Whitespace | gap plus evidence, feasibility and imitation risk |

**Outputs:** material universe + fixed exact-SKU matrix + price/claim/channel maps +
selection logic + coverage limitations + Gap Analysis. Marketing-spend estimates
ต้องมี retrievable source/method; หากไม่มีให้ใช้ `ไม่พบข้อมูลสาธารณะ` ไม่เดาตัวเลข

---

## Step 3 — SWOT + TOWS

### SWOT Matrix
- **S**trengths (ภายใน) 5 ข้อ จากข้อมูลสินค้า + Step 2
- **W**eaknesses (ภายใน) 5 ข้อ จากการเทียบกับคู่แข่ง
- **O**pportunities (ภายนอก) 5 ข้อ จาก Step 1
- **T**hreats (ภายนอก) 5 ข้อ จาก Step 1

### TOWS Strategy (4 ช่อง)
- **SO Strategy** — ใช้จุดแข็งคว้าโอกาส (Aggressive)
- **WO Strategy** — ใช้โอกาสแก้จุดอ่อน (Turnaround)
- **ST Strategy** — ใช้จุดแข็งหลีกเลี่ยงภัย (Defensive)
- **WT Strategy** — ลด weakness หลีกเลี่ยง threat (Survival)

แต่ละช่องเขียน **กลยุทธ์ที่ทำได้จริง 2-3 ข้อ** ห้ามเขียนนามธรรม

---

## Step 4 — Customer Persona

สร้าง **3 Persona** เรียงตามขนาดและความสำคัญ:
- **Primary** (60% ของ marketing focus)
- **Secondary** (30%)
- **Tertiary** (10%)

แต่ละ Persona ระบุ:
1. ชื่อสมมติ + รูปประกอบ + อายุ + อาชีพ + รายได้
2. Demographics + Geographic
3. Psychographics (lifestyle, values)
4. **Pain Points** 3-5 ข้อ
5. **Jobs-to-be-done** (Functional, Emotional, Social)
6. **Buying Triggers** อะไรทำให้ตัดสินใจซื้อ
7. **Buying Objections** อะไรทำให้ลังเล
8. **Media Consumption** เสพ content จากไหน เวลาไหน
9. **Key Message** ที่ตรงกับ persona นี้

ถ้าไม่แน่ใจ persona ให้ใช้ Wide Research หาข้อมูลพฤติกรรมกลุ่มเป้าหมายในไทย

---

## Step 5 — Strategic Choice + Positioning

อ่าน `references/strategy_choice_framework.md` และเปรียบเทียบอย่างน้อย 3
strategic options ก่อนเขียน tagline ให้คะแนนพร้อม rationale ใน demand,
whitespace, right-to-win, economics, feasibility, compliance, defensibility
และ evidence strength; unknown ใน economics/right-to-win/compliance ทำให้ตัวเลือก
ยัง provisional

### Choice Cascade

- Winning aspiration — outcome + time horizon
- Where to Play — geography, need state, occasion, SKU/pack/price, channel
- How to Win — differentiated value + proof + competitive trade-off
- Capabilities — product/evidence/supply/channel/content/data/finance/service
- Management systems — owner, cadence, dashboard, decision rights, stop/scale rule
- No-go choices — สิ่งที่ตั้งใจไม่ทำ

เลือก Primary Choice 1, Secondary Experiment 1 และ No-go zones ชัดเจน

### Brand Positioning Statement
> สำหรับ **[Primary need state]** ที่ **[ปัญหาหลัก]**, **[ชื่อแบรนด์]** คือ
> **[category]** ที่ **[unique benefit]** เพราะ **[reason to believe]** — ต่างจาก
> **[competitive alternative]** ตรงที่ **[differentiator]**

### Message House
- Tagline หลัก (ภาษาไทย ≤7 คำ + ภาษาอังกฤษ optional)
- Key Message 3 ข้อ
- Sub-message ต่อ Persona/need state
- Proof Points พร้อม evidence ID, scope, limitation และ approval status

**Output:** `strategy_choice.md` + positioning/message ใน Step 5 โดยทุก workstream
และงบหลักใน Step 6–11 ต้อง trace กลับสู่ strategic choice

---

## Step 6 — Online Marketing Strategy

### Sales Funnel (5 Stage)
1. **Awareness** — ช่องทาง + KPI (Reach, Impression)
2. **Interest** — ช่องทาง + KPI (CTR, Engagement)
3. **Consideration** — ช่องทาง + KPI (View 75%, Visit landing)
4. **Conversion** — ช่องทาง + KPI (Lead, Test drive, ยอดขาย)
5. **Loyalty** — ช่องทาง + KPI (Repeat, Referral)

### Channel Plan (อย่างน้อย 5 ช่องทาง)
ทุกช่องทางระบุ: เป้าหมาย, content type, posting frequency, ad budget, KPI

ตัวอย่างช่องทาง:
- Meta Ads (FB + IG)
- TikTok Ads
- Google Search + YouTube
- LINE OA + LINE Ads
- SEO + Owned blog
- Affiliate / Influencer

### Funnel Goal Sheet
ใส่ตัวเลขเฉพาะ stage ที่มี baseline/source/formula หรือ owner-approved
assumption. Stage ที่ขาด input ให้ระบุ `unknown`, evidence ที่ต้องหา และ
decision gate; ห้ามเติมตัวเลขเพื่อให้ตารางดูครบ

---

## Step 7 — Offline Marketing Strategy

### O2O Integration
- **PR & Media** — แผนงานกับสื่อหลัก/นิตยสาร (อย่างน้อย 5 หัว)
- **Event Marketing** — แผน activation 2-3 จุด/เดือน (mall, expo, dealer)
- **Partnership** — brand ไหนช่วย cross-promote ได้
- **OOH** — ถ้างบเกิน 1M/เดือน เพิ่ม billboard, BTS/MRT
- **Trade Marketing** — incentive ให้ดีลเลอร์/พนักงานขาย

### O2O Tracking
ใช้ QR code, UTM, dedicated landing page ต่อ event เพื่อตรวจ ROI

---

## Step 8 — Content Plan + 30 คลิป

อ่าน `references/30_clips_framework.md` ประกอบทุกครั้ง

### Content Plan (12 สัปดาห์)
ตารางรายสัปดาห์: สัปดาห์ที่, Phase, หัวข้อหลัก, Format, Channel, Pillar

### Content Pillars (4 แกน)
1. **Educational** (40%) — สอน ให้ความรู้
2. **Inspirational** (25%) — สร้างแรงบันดาลใจ
3. **Promotional** (20%) — ขาย โปรโมชัน
4. **Engagement** (15%) — Q&A, รีวิวลูกค้า, behind the scene

### 30 คลิปสคริปต์
- Phase 1 Awareness: 10 คลิป (สัปดาห์ 1-4)
- Phase 2 Consideration: 10 คลิป (สัปดาห์ 5-8)
- Phase 3 Conversion: 10 คลิป (สัปดาห์ 9-12)

ใช้ `templates/clip_script_template.md` แต่ละคลิปต้องมี: Hook 3 วิ, Script body พร้อม timecode, CTA, Caption, Hashtags, Production note

---

## Step 9 — Budget Allocation (3 Cases)

อ่าน `references/case_simulation.md` ก่อนทำเสมอ

### รัน
```text
python scripts/budget_allocator.py --monthly-budget 1000000 --duration 3
```

Script จะ output JSON ที่มี:
- งบรวม + งบ/เดือน
- Channel mix (% และตัวเลข)
- สถานะว่า allocator ไม่สร้าง performance scenario หากยังไม่มี sourced หรือ
  owner-approved inputs

### หัวข้อในไฟล์ `step9_budget_allocation.md`
- 9.1 ภาพรวมงบ (`monthly × duration`)
- 9.2 Channel Mix (ตาราง online/offline/influencer)
- 9.3 Best Case รายละเอียดต่อ channel
- 9.4 Base Case รายละเอียดต่อ channel
- 9.5 Worst Case รายละเอียดต่อ channel
- 9.6 Reserve Fund (เก็บ 5-10% ไว้ flex)

---

## Step 10 — KPIs & Measurement (3 Cases)

KPI ทุกระดับ funnel ต้องมี Best/Base/Worst **conditions** แต่ตัวเลขมีได้เฉพาะ
เมื่อ trace กลับไปยัง source, owner input, formula หรือ labeled assumption ได้
หากไม่มี ให้คง `unknown` พร้อม cheapest valid evidence ห้ามใช้ internal table
เป็น industry average

### Tier 1 — Business KPI
- ยอดขาย (units)
- Revenue (THB)
- ROAS / ROI
- CAC (Customer Acquisition Cost)

### Tier 2 — Marketing KPI
- Reach + Impression
- Engagement Rate
- CTR / CPC / CPM
- Lead จำนวน + Cost per Lead
- Conversion Rate

### Tier 3 — Content KPI
- Video View Through Rate
- Save / Share / Comment
- Hook Retention Rate (3-second view)

### Reporting Cadence
- Daily: Spend, CPC, CTR
- Weekly: Lead, conversion
- Monthly: Revenue, ROAS, retention

---

## Step 11 — Execution Timeline

### Gantt-style Table (12 สัปดาห์)
แสดง: สัปดาห์ × งานที่ต้องทำ × ผู้รับผิดชอบ × สถานะ

### Phase Breakdown
- **Pre-launch (W-2 ถึง W0):** เตรียมความพร้อม, brief KOL, setup tracking
- **Launch (W1-W4):** Phase 1 Awareness
- **Scale (W5-W8):** Phase 2 Consideration
- **Convert (W9-W12):** Phase 3 Conversion + close sale

### Milestones สำคัญ
ระบุ 5-7 milestones (เช่น launch event, review checkpoint, mid-campaign optimization)

---

## Step 12 — Executive Report + Strategic Handoff

อ่าน `templates/executive_report_template.md`,
`templates/readme_first_template.md`, `templates/strategy_choice_template.md`,
`references/strategic_plan_framework.md` และ
`templates/strategic_plan_template.md`

ต้องมี:
- Cover (สินค้า, geography, evidence date, งบ, ระยะเวลา, approval status)
- Executive Summary 1 หน้า: landscape, universe/deep-dive coverage, primary choice
- Verified facts / observations / calculations / assumptions / unknowns แยกกัน
- Strategic options + Choice Cascade + no-go choices
- Strategic Plan: entity/horizon/status, diagnosis, ambition, portfolio choices,
  capabilities, operating model, resources, initiatives, scorecard, roadmap,
  scenarios, governance and Marketing Plan handoff
- ตัวเลข 3 Cases เฉพาะเมื่อมีสูตรและ input; ไม่บังคับ precision ปลอม
- Strategy-to-plan traceability: choice → offer → audience → channel → budget → KPI
- สรุปแต่ละ Step
- Learning agenda และ decision gates
- Action Plan 30/60/90 วันแบบ proposed พร้อม owner
- Risk, mitigation, reversal trigger และ owner-approval boundary

สร้าง `README_FIRST.md`, `strategy_choice.md`, `strategic_plan.md`,
`assumptions_register.csv` และ `decision_register.json` สำหรับให้คนใหม่เริ่ม
อ่านได้โดยไม่ต้องไล่ 14 ไฟล์ก่อน

**ความยาว Executive Report:** 6–10 หน้า A4; `README_FIRST.md` ต้องอ่านจบใน 5 นาที
