# Strategic Plan Framework

Use this after `strategy_choice.md` and before finalizing the marketing plan. A strategic plan converts selected choices into a multi-horizon brand or organization system; it is not a longer campaign calendar.

## Scope gate

Declare:

- planning entity: organization, business unit, brand, category or product
- geography and portfolio boundary
- strategic horizon and evidence date
- owner-approved ambition and constraints
- current portfolio, capabilities, economics and operating model

If organization-level inputs are missing, produce a **provisional brand strategic plan** and list the missing portfolio, capability, financial and governance decisions. Never invent enterprise strategy from a product brief.

## Required strategic plan architecture

### 1. Strategic Horizon / ขอบเขตเวลา

State entity, boundary, horizon, baseline date, plan status and owner-approval boundary.

### 2. Diagnosis / การวินิจฉัย

Synthesize category landscape, competitor universe, customer needs, economics, regulation, internal strengths/capability gaps and material uncertainties. Link every load-bearing statement to evidence or an assumption ID.

### 3. Ambition / เป้าประสงค์

Define a measurable owner-level outcome and time horizon. Separate ambition from forecast. State what success means economically, for customers, for position and for organizational capability.

### 4. Portfolio Choices / ทางเลือกพอร์ต

Choose what categories, offers, price-pack tiers, channels, geographies and customer problems to invest in, maintain, test, partner for or exit. For a single-product brief, mark portfolio conclusions provisional until the broader portfolio is supplied.

### 5. Where to Play / สนามที่เลือก

Specify geography, need state/segment, occasion, offer/SKU, price tier, route to market and time horizon. Name excluded arenas.

### 6. How to Win / วิธีชนะ

State differentiated value, proof mechanism, business model/economic logic, channel advantage and competitive trade-off. Link to the selected option in `strategy_choice.md`.

### 7. Capabilities / ความสามารถที่ต้องมี

For each required capability record current maturity, target maturity, gap, build/buy/partner choice, owner, cost/resource envelope, dependency and evidence gate. Cover product, proof/compliance, supply, brand/content, channel, data/analytics, finance, service and talent.

### 8. Operating Model / ระบบปฏิบัติการ

Define decision rights, accountable owners, meeting cadence, dashboards, cross-functional interfaces, escalation path and stop/scale rules. Distinguish owner decisions from recommendations.

### 9. Resource Allocation / การจัดสรรทรัพยากร

Allocate people, capital, capability-building funds and marketing envelopes to strategic priorities. Do not force all budget to spend. State reserve/reallocation rules and what will not be funded.

### 10. Strategic Initiatives / ชุดความริเริ่ม

Maintain a portfolio table with initiative, strategic objective, owner, horizon, dependencies, resource envelope, leading indicator, lagging outcome, evidence gate, stop rule and status. Marketing campaigns are initiatives under the strategy, not the strategy itself.

### 11. Strategic Scorecard / ตัวชี้วัด

Use a causal chain:

- capability/readiness indicators
- customer/market learning indicators
- channel/operating indicators
- financial/economic outcomes
- risk/compliance guardrails

Every target must be owner-approved, evidenced or explicitly labeled as a planning assumption.

### 12. Roadmap / แผนระยะเวลา

Separate:

- 0–90 days: close truth/evidence/control gaps
- 3–12 months: validate repeatable proposition and economics
- 12–36 months (or owner horizon): capability, portfolio and scale choices

### 13. Scenarios, Risks and Assumptions / ฉากทัศน์และความเสี่ยง

Show external scenarios, signposts, strategic response, assumptions IDs, reversal triggers and contingency choices. Do not confuse marketing Best/Base/Worst arithmetic with enterprise scenarios.

### 14. Governance and Decision Gates / ธรรมาภิบาล

Record who recommends, decides, executes and audits. Each gate must have evidence required, deadline, pass/fail threshold and one of: no-go, revise/pilot, or request separate approval.

### 15. Marketing Plan Handoff / การส่งต่อสู่แผนการตลาด

Trace strategic objective → strategic choice → audience/offer → channel role → budget line → KPI → initiative → owner. Remove orphan tactics or label them exploratory.

## Verification

A valid Strategic Plan:

- declares entity, boundary, horizon and approval status
- uses evidence and assumption IDs in the diagnosis
- makes portfolio/Where-to-Play/How-to-Win exclusions
- identifies required capabilities and build/buy/partner choices
- defines an operating model, resource allocation and governance
- contains initiatives, scorecard, multi-horizon roadmap and scenarios
- traces the marketing plan to strategic objectives
- labels organization-level conclusions provisional when enterprise inputs are absent
- contains no fabricated financial, capability, market-share or owner commitments
