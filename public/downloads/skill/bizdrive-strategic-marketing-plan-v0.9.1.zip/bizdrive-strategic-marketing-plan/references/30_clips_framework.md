# 30 Clips Framework Reference

โครง 30 คลิปสคริปต์มาตรฐาน — แบ่ง 3 Phase × 10 คลิป สำหรับ Step 8

## โครง 3 Phase

### Phase 1 — Awareness (สัปดาห์ 1-4) — 10 คลิป

เป้าหมาย: สร้างการรับรู้ ให้คนเห็นแบรนด์เป็นครั้งแรก

| # | Type | ความยาว | จุดสำคัญ |
|---|------|---------|----------|
| 1 | Hero Brand Launch | 60s | tagline + USP หลัก, อารมณ์แรงที่สุด |
| 2 | Pain Point ที่ลูกค้าเจอ | 30s Reels | hook 3 วิแรก ทำให้คน relate |
| 3 | Why now (ทำไมต้องตอนนี้) | 45s | ใส่บริบทตลาด/เทรนด์ปัจจุบัน |
| 4 | First Look รีวิวสินค้า | 90s | walkaround ภายใน-ภายนอก |
| 5 | Feature ที่เด่นที่สุด อธิบายลึก | 60s | educational, ใช้ animation/graphic |
| 6 | How-to ใช้งานเบื้องต้น | 50s | tutorial format |
| 7 | Product Walkaround มุมต่างๆ | 45s | b-roll สวยๆ ดนตรีดี |
| 8 | Comparison vs คู่แข่ง | 60s | side-by-side ด้วยข้อมูลจริง |
| 9 | Q&A คำถามที่คนสงสัยมากสุด | 60s | quick-fire 5-7 คำถาม |
| 10 | Day in the life | 60s | lifestyle ใช้สินค้าจริง |

### Phase 2 — Consideration (สัปดาห์ 5-8) — 10 คลิป

เป้าหมาย: ลงรายละเอียดทำให้ลูกค้าตัดสินใจง่ายขึ้น

| # | Type | ความยาว | จุดสำคัญ |
|---|------|---------|----------|
| 11 | Cost Comparison/Saving Calc | 60s | ตัวเลขชัดเจน เทียบราคา total cost |
| 12 | Deep-dive Spec ที่สำคัญที่สุด | 90s | technical แต่เข้าใจง่าย |
| 13 | UX/Design รายละเอียด | 60s | close-up shot |
| 14 | Use case 1 (Persona Primary) | 60s | story-based |
| 15 | Use case 2 (Edge case จริง) | 50s | สถานการณ์ extreme |
| 16 | Use case 3 (ครอบครัว/กลุ่ม) | 60s | multiple personas |
| 17 | Behind the Scene การผลิต/QC | 60s | สร้างความน่าเชื่อถือ |
| 18 | Customer ROI/Saving Story | 60s | testimonial เน้นตัวเลข |
| 19 | First 30 Days Review จริง | 90s | long-form authenticity |
| 20 | Safety/Quality Certificate | 50s | certificate ทุกใบ + แสดงการทดสอบ |

### Phase 3 — Conversion (สัปดาห์ 9-12) — 10 คลิป

เป้าหมาย: ปิดการขาย สร้าง urgency

| # | Type | ความยาว | จุดสำคัญ |
|---|------|---------|----------|
| 21 | Why ราคานี้คุ้มที่สุด | 60s | breakdown value |
| 22 | Financing/Promotion ที่คุ้มสุด | 50s | คำนวณยอดผ่อน |
| 23 | Trade-in/Bundle Offer | 50s | savings stack |
| 24 | Warranty + After-sale | 60s | long-term value |
| 25 | Limited-time Promotion | 30s Reels | urgency, countdown |
| 26 | How to Test Drive/ลองสินค้า | 45s | ลด friction การตัดสินใจ |
| 27 | Onboarding หลังซื้อ | 60s | ให้เห็นภาพชัดหลังซื้อ |
| 28 | FAQ ก่อนตัดสินใจ 10 ข้อ | 90s | ทำลาย objection ทุกตัว |
| 29 | Limited Edition/First batch | 30s Reels | scarcity, FOMO |
| 30 | Final CTA + Storytelling Close | 60s | อารมณ์ปิด + CTA แรง |

## Output Template สำหรับสคริปต์ 1 คลิป

ใช้ `templates/clip_script_template.md` ทุกครั้ง — ทุกคลิปต้องมีครบ 7 ส่วน:

1. **Title** + clip number + phase + duration + platform
2. **Hook** (0-3 วิแรก, word-for-word)
3. **Script Body** (พูดได้จริง ใส่ timecode)
4. **CTA** (ปิดคลิป)
5. **Caption** (สำหรับลงโพสต์)
6. **Hashtags** (10-15 ตัว)
7. **Production Note** (กล้อง, b-roll, music, pattern interrupt)
8. **KPI เป้าหมาย** (Reach/View/Save target)

## Method ทำให้เร็ว

ใช้ parallel workers เมื่อ runtime รองรับ แบ่งสคริปต์เป็น batch ที่อิสระ แล้วให้
lead model ตรวจความซ้ำ ความสอดคล้อง หลักฐาน/privacy gate และรวมเป็น 30 scripts:
```
target_count: 30
inputs: [clip topic 1, clip topic 2, ..., clip topic 30]
output_schema: title, hook, script_body, cta, caption, hashtags, production_note, kpi
```

แต่ละ subtask รับ:
- `product_name`
- `persona`
- `phase`
- `clip_topic`
- `key_message` (จาก Step 5)
- `competitor_gap` (จาก Step 2)

แล้วเขียนสคริปต์เต็ม 1 คลิปกลับมา

## Hook Pattern ที่ใช้ได้ผล

- **คำถามตรงใจ** ("คุณเคย...ไหม?")
- **ตัวเลขแรง** ("ประหยัดได้ 60,000 บาท/ปี")
- **Pattern interrupt** ("หยุด! อย่าเพิ่งซื้อ X ถ้ายังไม่ดูคลิปนี้")
- **คำเตือน** ("3 ข้อที่ดีลเลอร์ไม่บอกคุณ")
- **เทียบของคุ้นเคย** ("ค่าน้ำมัน 1 ปี = X")

## Channel Mapping

| คลิปประเภท | TikTok | IG Reels | YouTube Shorts | YouTube Long | FB |
|-------------|--------|----------|----------------|---------------|----|
| Hook ≤30s | ✅ | ✅ | ✅ | ❌ | ✅ |
| 45-60s | ✅ | ✅ | ✅ | partial | ✅ |
| 90s | partial | ❌ | ❌ | ✅ | ✅ |

ทุกคลิปลง 3-4 ช่องทาง (cross-post) แต่ปรับ aspect ratio + caption ให้เหมาะแต่ละ platform
