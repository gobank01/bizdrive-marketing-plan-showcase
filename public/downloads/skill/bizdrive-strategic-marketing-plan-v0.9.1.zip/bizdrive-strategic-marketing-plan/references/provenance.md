# Provenance and Rights

rights_status: owner-authorized
authorization_date: 2026-08-28
rights_holder: Prachaya Piyasirisilp / BizDrive
authorized_scope: adaptation and student distribution

- Original BizDrive page: https://bizdrive-skill.com/skill/marketing-plan
- Original download endpoint: https://bizdrive-skill.com/api/download/marketing-plan
- Source inspected: 2026-08-28
- Original page described a free Marketing Plan skill intended for Manus AI
- The inspected page/archive did not itself contain an explicit redistribution license

## Owner authorization

On 2026-08-28, Prachaya Piyasirisilp stated that he owns or controls the
upstream BizDrive Marketing Plan skill and authorized its adaptation and
student distribution. This declaration is the rights basis for the student
edition; the package does not claim that the inspected upstream ZIP already
contained redistribution terms.

## Student edition

This package is a rewritten, runtime-agnostic BizDrive student edition. It
retains the educational 12-step Marketing Plan concept and adds:

- explicit category/JTBD and competitor-universe boundaries
- evidence provenance and uncertainty classes
- Customer Voice privacy/publication controls
- Strategy Choice and a separate Strategic Plan operating system
- assumptions/decision registers and README-first handoff
- cross-platform stdlib scripts, installation adapters and validation
- a privacy-reduced worked example

No Manus runtime, proprietary model weights, credentials or third-party service
is bundled. Distribution terms are defined in `LICENSE.md`.
