# Scenario Planning Reference

Use this for Best / Base / Worst work in Steps 9 and 10. It contains **no
industry-average media benchmarks**. Numbers must come from owner inputs,
retrievable category evidence or a labeled pilot assumption.

## Core rule

A scenario is a conditional model, not a forecast. Do not fill a table merely
because the template has a cell. If a load-bearing input is unknown, write
`unknown`, identify the cheapest valid evidence and keep the related business
commitment provisional.

## Input registry

Before calculating, record each input with:

| Field | Required record |
|---|---|
| Metric | CPC, CPM, CVR, repeat rate, price, contribution, capacity, etc. |
| Value/range | exact value or `unknown` |
| Type | owner fact / verified fact / observation / calculation / assumption |
| Scope | geography, category, channel, audience, SKU/offer and period |
| Source | URL, owner record or pilot report |
| Observed/retrieved date | date |
| Confidence | high / medium / low |
| Decision use | what changes if the input is wrong |
| Review trigger | when to refresh or replace it |

Do not call a cross-category or undated number an industry average.

## Source hierarchy

1. reconciled first-party order, finance, inventory and CRM data
2. valid category/channel pilot with exact offer and cohort
3. current official platform or audited category source with methodology
4. dated comparable observation with explicit limitations
5. owner-approved planning assumption
6. unknown

Lower levels never become verified facts through repetition.

## Symbolic funnel model

Use only applicable stages and preserve units:

```text
impressions = spend / CPM × 1,000
clicks = impressions × CTR
orders = clicks × click_to_order_CVR
revenue = orders × net_revenue_per_order
contribution = revenue - COGS - channel_fees - fulfillment - returns - variable_service_cost - marketing_spend
allowable_CAC = net_revenue_per_order - all_non_marketing_variable_cost - target_contribution
```

For lead businesses, replace orders with qualified leads and add explicit
lead-to-sale conversion and sales-cycle assumptions. Never mix lead and order
funnels silently.

## Constructing the three cases

### Base

Use the most defensible current input set. If there is no valid baseline, Base
is an explicit hypothesis or qualitative condition—not an industry average.

### Best

Change only identified drivers with a written mechanism, such as stronger
creative response, higher qualified conversion, lower return rate or improved
repeat. Do not apply a universal uplift percentage.

### Worst

Model downside mechanisms that could reverse the decision: claim delay, weak
WTP, higher acquisition cost, negative contribution, supply failure, complaint
pattern or low repeat. Include stop rules and cash exposure.

## When numeric inputs are missing

Use a decision table instead of fake precision:

| Case | Conditions | Signposts | Financial field | Decision |
|---|---|---|---|---|
| Best | named favorable conditions | observable leading signals | unknown until inputs exist | bounded next test |
| Base | most defensible current conditions | baseline signals | unknown until inputs exist | continue learning |
| Worst | named downside conditions | stop/reversal signals | exposure ceiling if known | pause, revise or no-go |

Add an evidence-acquisition row for every unknown input.

## Budget allocator status

`scripts/budget_allocator.py` guarantees exact arithmetic. Its channel mix is
an **illustrative starting heuristic based only on budget size and product-type
label**. It is not a benchmark, recommendation or authorization. Replace it
with a strategy-linked allocation when category evidence, channel feasibility,
unit economics, capability constraints or owner choices support a different
mix.

The allocator must not generate performance multipliers, probability weights
or forecast outputs.

## Probability-weighted values

Use scenario probabilities only when the owner or a documented model supplies
them. Record the rationale and confirm weights sum to 100%. Without a defensible
probability model, show separate cases and do not report an expected value.

## Required disclosure

Every scenario output must state:

- source/type/date for each numeric input
- formulas and units
- fields that remain unknown
- whether revenue is gross or net
- whether costs include COGS, fees, fulfillment, returns and overhead
- downside cash exposure and stop rule
- that the scenario is not a forecast or execution approval

## Verification

- no uncited media or influencer benchmark appears
- no input is labeled an industry average without current retrievable methodology
- every number traces to a source, owner input, calculation or labeled assumption
- missing economics do not produce allowable CAC or commercial break-even
- Best/Base/Worst differ through named mechanisms, not universal multipliers
- budget arithmetic is exact
- decision and reversal gates remain visible
