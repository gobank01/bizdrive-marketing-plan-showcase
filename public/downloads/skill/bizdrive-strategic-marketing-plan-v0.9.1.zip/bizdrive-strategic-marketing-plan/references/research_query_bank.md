# Research Query Bank

ใช้ `{current_year}`, `{previous_year}`, `{geography}`, `{category}`, `{job}`, `{brand}` และ `{sku}` จาก brief ห้าม hard-code ปีใน reusable plan

## Lane 0 — Category boundary

- "{category} category definition {geography}"
- "{job} alternatives substitutes {geography}"
- "{category} product types price tiers channels {geography}"
- "{category} regulation classification {geography} official"

Completion: category/JTBD, geography, SKU/pack, price/channel and time boundary written before competitor selection.

## Lane 1 — Landscape and economics

- "{category} market structure {geography} {current_year}"
- "{category} market size {geography} {current_year} methodology"
- "{category} segments price pack architecture {geography}"
- "{category} route to market retail ecommerce specialist {geography}"
- "{category} gross margin distributor retailer fee benchmark"
- "{category} manufacturing MOQ capacity supply chain {geography}"
- "{category} consumer trend {geography} {previous_year} {current_year}"
- "{category} regulation advertising claims label {geography} official"

Do not compute CAGR from incomparable points or derive SAM/SOM as arbitrary TAM percentages.

## Lane 2 — Competitor universe discovery

Run separate queries for every class and source surface:

### Direct
- "{category} brands {geography} price"
- "best selling {category} {geography} {current_year}"
- site:major-retailer-domain "{category}"

### Indirect / substitutes
- "alternatives to {category} for {job} {geography}"
- "{job} products services substitute {geography}"
- "instead of {category} {job}"

### Emerging / adjacent
- "new launch {category} {geography} {previous_year} {current_year}"
- "startup emerging brand {category} {geography}"
- "premium innovation {category} global benchmark"

### Structured surfaces
- official brand product sitemap
- retailer category page and exact product JSON-LD
- marketplace official-store category
- regulator notification/product registry where public
- trade-show/exhibitor or distributor catalog

Append each material record to `competitor_universe.csv` immediately. Stop only when scope is met and three consecutive lanes add no material competitor class. Record uncovered channels/classes.

## Lane 3 — Exact SKU deep dive

For each frozen `{brand}` / `{sku}`:

- official exact SKU variant pack ingredients technology claims
- `{sku} price {geography}` + exact seller/channel/date
- `{sku} official store marketplace {geography}`
- `{brand} positioning tagline campaign {previous_year} {current_year}`
- `{sku} review complaint taste packaging value`
- `{brand} distribution retailer pharmacy clinic {geography}`
- `{brand} Meta Ad Library` / public campaign library

Never pair price, pack or claim from adjacent variants. Marketing-spend estimates require a visible method/source; otherwise mark unknown.

## Lane 4 — Customer need and Voice

Research behavior/need states before demographic personas:

- "why people buy {category} {geography}"
- "{category} unmet need objection complaint {geography}"
- "{job} buying trigger switching behavior"
- "{category} review taste feel packaging value repeat"
- "{category} search intent questions {geography}"
- "{category} channel path to purchase {geography}"

Code product, date, language, source type, need, trigger, objection, theme and sentiment. State brand/source concentration. Public/shareable records must remove verbatim excerpts, authors, profiles and record-level links; generalized product/video URLs are allowed. Raw research, if retained, stays private and segregated.

## Lane 5 — Right-to-win and strategy evidence

- product formula/specification/test/QC/registration dossier
- COGS, gross-to-net, fees, returns, MOQ, capacity and SLA
- willingness-to-pay and blind preference protocol
- channel access, owner capabilities and partner constraints
- trademark/claim/compliance review

These inputs usually come from the owner or qualified providers, not web search. Unknown right-to-win/economics/compliance keeps strategy provisional.

## Source hierarchy

1. official law/regulator/statistics/product page
2. exact official store or major retailer SKU
3. audited research with disclosed methodology
4. platform/ad-library/structured public surface
5. trade press with date and named methodology/source
6. public review/comment for qualitative coding only
7. aggregator/seller copy as observation, never official claim

Validate title, date, geography, exact SKU, canonical URL and substantive body. Paywalled snippets, search headings and HTTP 200 alone are not evidence.

## Freshness rule

Use current and previous year dynamically. Flag dated facts by volatility:

- price, promotion, stock, ads: refresh at delivery
- claims, product page, channel: refresh within 90 days
- market/regulation: use latest available and record publication/retrieval dates
- evergreen framework: label methodology and original date
