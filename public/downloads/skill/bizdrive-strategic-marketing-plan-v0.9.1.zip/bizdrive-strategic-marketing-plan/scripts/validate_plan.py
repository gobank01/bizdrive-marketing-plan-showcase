#!/usr/bin/env python3
"""Validate a bizdrive-strategic-marketing-plan v0.9 artifact."""
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

EXPECTED = [
    "00_brief.md", "step1_market_analysis.md", "step2_competitor_analysis.md",
    "step3_swot_analysis.md", "step4_customer_persona.md",
    "step5_positioning_key_message.md", "step6_online_strategy.md",
    "step7_offline_strategy.md", "step8_content_plan.md",
    "step8b_30_clip_scripts.md", "step9_budget_allocation.md",
    "step10_kpis_measurement.md", "step11_execution_timeline.md",
    "step12_executive_report.md",
]
HANDOFF = [
    "README_FIRST.md", "category_landscape.md", "competitor_universe.csv",
    "competitor_matrix.csv", "strategy_choice.md", "strategic_plan.md",
    "assumptions_register.csv", "decision_register.json",
]
PLACEHOLDER = re.compile(r"\{\{.*?\}\}|\b(?:TBD|TODO|PLACEHOLDER)\b|<insert[^>]*>", re.I | re.S)
DEEP_LINK = re.compile(r"#review-|[?&](?:lc|comment_id|review_id)=", re.I)
VOICE_RAW_MARKERS = {
    "exact Customer Voice example heading": re.compile(r"Voice examples\s*\(exact", re.I),
    "exact Customer Voice excerpt section": re.compile(r"Exact excerpts?\s*\(", re.I),
    "raw excerpt location claim": re.compile(r"(?:full short excerpts?|source-level exact text).*customer_voice\.json", re.I),
    "shareable Voice contract exposes excerpt": re.compile(r"source URL/date/excerpt/themes", re.I),
    "shareable content requests exact excerpt": re.compile(r"(?:Customer words|source type[^\n]{0,80}).{0,80}exact excerpt", re.I),
    "private Voice field in structured artifact": re.compile(
        r"[\"'](?:quote|excerpt|author|author_name|username|profile|profile_url|comment_id|review_id|email|phone)[\"']\s*:",
        re.I,
    ),
}
PRIVATE_DIR_NAMES = {"research_private", "raw", "private"}
VOICE_PRIVATE_FIELDS = {
    "quote", "excerpt", "author", "author_name", "username", "profile",
    "profile_url", "comment_id", "review_id", "source_record_id", "email",
    "email_address", "phone", "phone_number", "user_id", "handle",
}
EMAIL = re.compile(r"(?i)(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?![\w.-])")
VOICE_SECTION = re.compile(
    r"(?i)customer\s+voice|coded\s+voice|voice\s+examples?|customer\s+language|customer\s+words|"
    r"review\s+examples?|review\s+excerpts?|เสียงลูกค้า|คำพูดลูกค้า"
)
QUOTED_SPEECH = re.compile(r"(?:[\"“‘][^\"”’\n]{8,}[\"”’])")
FIRST_PERSON_STATEMENT = re.compile(
    r"(?i)(?:^|\s)(?:I|I'm|I've|I'd|my|me|we|our|ฉัน|ผม|หนู|เรา)(?:\b|(?=[^\w]))"
)
CUSTOMER_SPEAKER_PREFIX = re.compile(
    r"(?i)^\s*(?:[-*]\s*)?(?:customer|reviewer|commenter|ลูกค้า|ผู้รีวิว)\s*[:\-–—]"
)
DIRECT_VOICE_LABEL = re.compile(
    r"(?i)(?:customer\s+voice|customer\s+statement|customer\s+words|review\s+quote|"
    r"เสียงลูกค้า|คำพูดลูกค้า)\s*[:\-–—]\s*(?:[\"“‘]|I\b|ฉัน\b|ผม\b|หนู\b|เรา\b)"
)
REPORTED_CUSTOMER_SPEECH = re.compile(
    r"(?i)(?:customer|reviewer|commenter|ลูกค้า|ผู้รีวิว).{0,80}"
    r"(?:said|says|wrote|commented|stated|บอก|กล่าว|เขียน|พูด).{0,30}[\"“‘]"
)
UNSUPPORTED_WEIGHTED_VALUE = re.compile(
    r"(?i)(?:probability[-\s]?weighted(?:\s+(?:revenue|sales|profit|value|expected\s+value))?|"
    r"weighted\s+(?:revenue|sales|profit|value)|"
    r"\b\d{1,3}\s*/\s*\d{1,3}\s*/\s*\d{1,3}\b[^\n]{0,80}weighted\s+(?:revenue|sales|profit|value))"
    r"[^\n]{0,180}(?:is|=|:)\s*\*{0,2}\s*\d"
)
UNIVERSAL_MULTIPLIER_KEY = re.compile(
    r'(?i)["\'](?:(?:scenario_)?performance_multipliers|universal_multipliers)["\']\s*:'
)
UNIVERSAL_MULTIPLIER_STATEMENT = re.compile(
    r"(?i)(?:universal|default|standard|fixed).{0,80}"
    r"(?:performance|scenario|cost|conversion|revenue).{0,80}multipliers?"
)
MULTIPLIER_NEGATION = re.compile(r"(?i)\b(?:no|not|without|never|must\s+not|do\s+not)\b")
UNIVERSE_COLUMNS = {
    "brand", "product_sku", "competitor_type", "geography", "price_tier",
    "primary_need", "channel_presence", "discovery_source", "evidence_grade",
    "included_in_deep_dive", "inclusion_or_exclusion_reason", "observed_at",
}
COMPETITOR_TYPES = {"direct", "indirect", "substitute", "emerging", "adjacent"}
MATRIX_COLUMN_GROUPS = {
    "brand": {"brand"},
    "product": {"product", "product_sku", "product_variant"},
    "price_source": {"price_source", "price_source_url"},
    "retrieved_at": {"retrieved_at", "observed_at"},
    "verified_claims": {"verified_claims", "claims"},
    "channels": {"channels", "channel_presence"},
    "evidence_note": {"evidence_note", "evidence_grade", "evidence_quality"},
}


def load_json(path: Path, errors: list[str]):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid JSON {path.name}: {exc}")
        return None


def read_csv(path: Path, errors: list[str]) -> tuple[list[dict], list[str]]:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            return list(reader), list(reader.fieldnames or [])
    except Exception as exc:
        errors.append(f"invalid CSV {path.name}: {exc}")
        return [], []


def validate_markdown(project: Path, errors: list[str]) -> None:
    for name in EXPECTED:
        path = project / name
        if not path.is_file():
            errors.append(f"missing {name}")
            continue
        text = path.read_text(encoding="utf-8")
        if len(text.strip()) < 100:
            errors.append(f"too short {name}")
        if PLACEHOLDER.search(text):
            errors.append(f"placeholder remains in {name}")

    clips = project / "step8b_30_clip_scripts.md"
    if clips.is_file():
        numbers = [int(x) for x in re.findall(
            r"^##\s+(?:คลิปที่|Clip)\s+(\d+)\b", clips.read_text(encoding="utf-8"), re.M | re.I
        )]
        if sorted(numbers) != list(range(1, 31)):
            errors.append(f"clip numbering must be exactly 1..30; got {numbers}")


def validate_budget(project: Path, errors: list[str]) -> None:
    meta_path = project / "meta.json"
    if not meta_path.is_file():
        errors.append("missing meta.json")
    else:
        meta = load_json(meta_path, errors) or {}
        expected_total = meta.get("monthly_budget_thb", 0) * meta.get("duration_months", 0)
        if meta.get("total_budget_thb") != expected_total:
            errors.append("meta total budget arithmetic mismatch")

    budget_path = project / "budget_allocation.json"
    if not budget_path.is_file():
        errors.append("missing budget_allocation.json")
        return
    budget = load_json(budget_path, errors) or {}
    allocation = budget.get("allocation_thb", {})
    for key, value in allocation.items():
        if key == "online_sub":
            continue
        if not isinstance(value, int) or value < 0:
            errors.append(f"budget allocation {key} must be a non-negative integer")
    for key, value in allocation.get("online_sub", {}).items():
        if not isinstance(value, int) or value < 0:
            errors.append(f"online sub-allocation {key} must be a non-negative integer")
    total_allocated = sum(allocation.get(k, 0) for k in ("online", "offline", "kol", "reserve"))
    total_budget = budget.get("summary", {}).get("total_budget_thb")
    if total_allocated != total_budget:
        errors.append(f"budget allocation mismatch: {total_allocated} != {total_budget}")
    if sum(allocation.get("online_sub", {}).values()) != allocation.get("online"):
        errors.append("online sub-allocation mismatch")


def validate_evidence(project: Path, errors: list[str]) -> list[dict]:
    path = project / "evidence_ledger.json"
    if not path.is_file():
        errors.append("missing evidence_ledger.json")
        return []
    ledger = load_json(path, errors)
    if not isinstance(ledger, list):
        errors.append("evidence ledger must be a JSON list")
        return []
    for step in (1, 2, 4):
        urls = {item.get("url") for item in ledger if item.get("step") == step and str(item.get("url", "")).startswith("http")}
        if len(urls) < 5:
            errors.append(f"step {step} has only {len(urls)} unique evidence URLs; need >=5")
    for idx, item in enumerate(ledger):
        missing = [key for key in ("step", "url", "title", "claim", "retrieved_at", "grade") if not item.get(key)]
        if missing:
            errors.append(f"evidence item {idx} missing {missing}")
        try:
            parts = urlsplit(str(item.get("url", "")))
            if parts.scheme not in {"http", "https"} or not parts.netloc:
                errors.append(f"evidence item {idx} has invalid HTTP(S) URL")
        except ValueError:
            errors.append(f"evidence item {idx} has invalid URL")
    return ledger


def validate_competitors(project: Path, minimum: int, strategic: bool, errors: list[str]):
    matrix = project / "competitor_matrix.csv"
    deep_count = 0
    if minimum or strategic:
        if not matrix.is_file():
            errors.append("missing competitor_matrix.csv")
        else:
            rows, fields = read_csv(matrix, errors)
            field_set = set(fields)
            missing_semantics = sorted(
                semantic for semantic, aliases in MATRIX_COLUMN_GROUPS.items()
                if not (aliases & field_set)
            )
            if missing_semantics:
                errors.append(f"competitor_matrix.csv missing semantic columns {missing_semantics}")
            brands = {(row.get("brand") or row.get("แบรนด์") or "").strip().casefold() for row in rows}
            brands.discard("")
            deep_count = len(brands)
            if minimum and deep_count < minimum:
                errors.append(f"competitor count {deep_count} < {minimum}")

    universe_count = 0
    if strategic:
        path = project / "competitor_universe.csv"
        if not path.is_file():
            errors.append("missing competitor_universe.csv")
        else:
            rows, fields = read_csv(path, errors)
            missing_columns = sorted(UNIVERSE_COLUMNS - set(fields))
            if missing_columns:
                errors.append(f"competitor_universe.csv missing columns {missing_columns}")
            universe_count = len(rows)
            classes = set()
            included = 0
            for idx, row in enumerate(rows):
                kind = row.get("competitor_type", "").strip().casefold()
                if kind not in COMPETITOR_TYPES:
                    errors.append(f"universe item {idx} invalid competitor_type {kind!r}")
                else:
                    classes.add(kind)
                for key in ("brand", "discovery_source", "inclusion_or_exclusion_reason", "observed_at"):
                    if not row.get(key, "").strip():
                        errors.append(f"universe item {idx} missing {key}")
                if row.get("included_in_deep_dive", "").strip().casefold() in {"1", "true", "yes", "y"}:
                    included += 1
            if rows and "direct" not in classes:
                errors.append("competitor universe has no direct class")
            if rows and len(classes) < 2:
                errors.append("competitor universe needs direct plus at least one non-direct class")
            if deep_count and included != deep_count:
                errors.append(f"universe included count {included} != deep-dive count {deep_count}")
            if universe_count < deep_count:
                errors.append("competitor universe is smaller than deep-dive set")
    return deep_count, universe_count


def validate_voice(project: Path, required: bool, errors: list[str]) -> int:
    path = project / "customer_voice.json"
    if not required:
        return 0
    if not path.is_file():
        errors.append("missing customer_voice.json")
        return 0
    payload = load_json(path, errors)
    records = payload.get("records") if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        errors.append("customer_voice.json must be a list or {records: [...]} object")
        return 0
    if isinstance(payload, dict):
        note = str(payload.get("privacy_note", ""))
        if "not fully anonymous" not in note.lower():
            errors.append("customer voice wrapper needs a not-fully-anonymous privacy note")
    seen = set()
    seen_record_keys = set()
    for idx, voice in enumerate(records):
        private = sorted(VOICE_PRIVATE_FIELDS & set(voice))
        if private:
            errors.append(f"customer voice item {idx} exposes private fields {private}")
        missing = [key for key in ("source_url", "brand", "retrieved_at", "themes") if not voice.get(key)]
        if missing:
            errors.append(f"customer voice item {idx} missing {missing}")
        url = str(voice.get("source_url", ""))
        if DEEP_LINK.search(url):
            errors.append(f"customer voice item {idx} has a record-level URL")
        try:
            parts = urlsplit(url)
            if parts.scheme not in {"http", "https"} or not parts.netloc:
                errors.append(f"customer voice item {idx} source_url must be an HTTP(S) URL with a host")
            if parts.fragment:
                errors.append(f"customer voice item {idx} URL retains fragment")
            forbidden = {key.casefold() for key, _ in parse_qsl(parts.query)} & {"lc", "comment_id", "review_id"}
            if forbidden:
                errors.append(f"customer voice item {idx} URL has forbidden query keys")
        except ValueError:
            errors.append(f"customer voice item {idx} invalid URL")
        record_key = str(voice.get("record_key", "")).strip()
        if record_key:
            normalized_key = record_key.casefold()
            if normalized_key in seen_record_keys:
                errors.append(f"duplicate customer voice record_key at item {idx}")
            seen_record_keys.add(normalized_key)
            fingerprint = ("record_key", normalized_key)
        else:
            fingerprint = (
                url, str(voice.get("brand", "")).casefold(), str(voice.get("product", "")).casefold(),
                str(voice.get("review_date", "")), tuple(sorted(map(str, voice.get("themes", [])))),
            )
        if fingerprint in seen:
            errors.append(f"duplicate customer voice item {idx}")
        seen.add(fingerprint)
    if not records:
        errors.append("customer_voice.json has no records")
    return len(records)


def validate_handoff(project: Path, errors: list[str]) -> None:
    for name in HANDOFF:
        path = project / name
        if not path.is_file():
            errors.append(f"missing strategic handoff {name}")
        elif path.suffix == ".md":
            text = path.read_text(encoding="utf-8")
            if len(text.strip()) < 200:
                errors.append(f"too short strategic handoff {name}")
            if PLACEHOLDER.search(text):
                errors.append(f"placeholder remains in {name}")

    strategy = project / "strategy_choice.md"
    if strategy.is_file():
        text = strategy.read_text(encoding="utf-8")
        required_terms = [
            "Where to Play", "How to Win", "capabilities", "management systems",
            "no-go", "primary", "secondary", "learning agenda",
        ]
        for term in required_terms:
            if term.casefold() not in text.casefold():
                errors.append(f"strategy_choice.md missing {term}")
        option_rows = re.findall(r"(?mi)^\|\s*(?:option\s+)?[A-Z][.)]\s+[^|]+\|", text)
        if len(option_rows) < 3:
            errors.append(f"strategy_choice.md needs at least 3 distinct option rows; got {len(option_rows)}")

    strategic_plan = project / "strategic_plan.md"
    if strategic_plan.is_file():
        text = strategic_plan.read_text(encoding="utf-8")
        required_terms = [
            "Plan status", "Strategic Horizon", "Diagnosis", "Ambition",
            "Portfolio Choices", "Where to Play", "How to Win", "Capabilities",
            "Operating Model", "Resource Allocation", "Strategic Initiatives",
            "Strategic Scorecard", "Roadmap", "Scenarios, Risks and Assumptions",
            "Governance and Decision Gates", "Marketing Plan Handoff",
            "Explicit no-go choices", "Owner decisions required",
        ]
        for term in required_terms:
            if term.casefold() not in text.casefold():
                errors.append(f"strategic_plan.md missing {term}")

    assumptions = project / "assumptions_register.csv"
    if assumptions.is_file():
        rows, fields = read_csv(assumptions, errors)
        required = {"id", "type", "statement", "status", "owner", "decision_impact", "evidence_or_test", "review_date"}
        if required - set(fields):
            errors.append(f"assumptions_register.csv missing columns {sorted(required - set(fields))}")
        if not rows:
            errors.append("assumptions_register.csv has no records")

    decisions = project / "decision_register.json"
    if decisions.is_file():
        rows = load_json(decisions, errors)
        if not isinstance(rows, list) or not rows:
            errors.append("decision_register.json must be a non-empty list")
        else:
            for idx, row in enumerate(rows):
                missing = [key for key in ("id", "decision", "status", "evidence", "owner_boundary", "review_date", "reversal_trigger") if not row.get(key)]
                if missing:
                    errors.append(f"decision item {idx} missing {missing}")


def validate_public_privacy(project: Path, publication_mode: str, errors: list[str]) -> None:
    reported_private_dirs: set[Path] = set()
    for path in sorted(project.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {".md", ".json", ".csv", ".svg"}:
            continue
        rel = path.relative_to(project)
        private_indexes = [
            index for index, part in enumerate(rel.parts[:-1])
            if part.casefold() in PRIVATE_DIR_NAMES
        ]
        if private_indexes:
            private_rel = Path(*rel.parts[: private_indexes[0] + 1])
            if publication_mode == "shareable" and private_rel not in reported_private_dirs:
                errors.append(f"private/raw directory exists inside shareable project: {private_rel}")
                reported_private_dirs.add(private_rel)
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if DEEP_LINK.search(text):
            errors.append(f"record-level URL identifier remains in shareable artifact {rel}")
        if EMAIL.search(text):
            errors.append(f"email address remains in shareable artifact {rel}")
        if path.suffix.lower() == ".csv":
            rows, fields = read_csv(path, errors)
            private_headers = sorted({field.strip().casefold() for field in fields} & VOICE_PRIVATE_FIELDS)
            if private_headers:
                errors.append(f"private/identifier CSV columns remain in shareable artifact {rel}: {private_headers}")
            if any(EMAIL.search(str(value)) for row in rows for value in row.values() if value is not None):
                errors.append(f"email value remains in shareable CSV artifact {rel}")
        if path.suffix.lower() == ".md":
            if DIRECT_VOICE_LABEL.search(text) or REPORTED_CUSTOMER_SPEECH.search(text):
                errors.append(f"direct Customer Voice speech remains in shareable Markdown {rel}")
            in_voice_section = False
            for line in text.splitlines():
                if line.lstrip().startswith("#"):
                    in_voice_section = bool(VOICE_SECTION.search(line))
                    continue
                if in_voice_section and (
                    QUOTED_SPEECH.search(line)
                    or FIRST_PERSON_STATEMENT.search(line)
                    or CUSTOMER_SPEAKER_PREFIX.search(line)
                ):
                    errors.append(f"direct or quoted speech remains in Customer Voice section of {rel}")
                    break
        for label, pattern in VOICE_RAW_MARKERS.items():
            if pattern.search(text):
                errors.append(f"{label} remains in shareable artifact {rel}")


def validate_scenario_policy(project: Path, errors: list[str]) -> None:
    for path in sorted(project.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {".md", ".json"}:
            continue
        rel = path.relative_to(project)
        if any(part.casefold() in PRIVATE_DIR_NAMES for part in rel.parts[:-1]):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if UNSUPPORTED_WEIGHTED_VALUE.search(text):
            errors.append(f"unsupported probability-weighted value remains in {rel}")
        if UNIVERSAL_MULTIPLIER_KEY.search(text):
            errors.append(f"universal scenario performance multiplier key remains in {rel}")
        for line in text.splitlines():
            if UNIVERSAL_MULTIPLIER_STATEMENT.search(line) and not MULTIPLIER_NEGATION.search(line):
                errors.append(f"universal/default scenario multiplier statement remains in {rel}")
                break


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_dir")
    parser.add_argument("--min-competitors", type=int, default=0)
    parser.add_argument("--require-customer-voice", action="store_true")
    parser.add_argument("--strategic-handoff", action="store_true")
    parser.add_argument("--publication-mode", choices=["private-workspace", "shareable"], default="private-workspace")
    args = parser.parse_args()
    project = Path(args.project_dir).expanduser().resolve()
    errors: list[str] = []
    warnings: list[str] = []

    validate_markdown(project, errors)
    validate_budget(project, errors)
    ledger = validate_evidence(project, errors)
    deep_count, universe_count = validate_competitors(project, args.min_competitors, args.strategic_handoff, errors)
    voice_count = validate_voice(project, args.require_customer_voice, errors)
    if args.strategic_handoff:
        validate_handoff(project, errors)
    validate_public_privacy(project, args.publication_mode, errors)
    validate_scenario_policy(project, errors)

    report = {
        "status": "pass" if not errors else "fail",
        "project_dir": str(project),
        "markdown_files": sum((project / name).is_file() for name in EXPECTED),
        "expected_markdown_files": len(EXPECTED),
        "strategic_handoff": args.strategic_handoff,
        "publication_mode": args.publication_mode,
        "strategic_plan_file": (project / "strategic_plan.md").is_file(),
        "evidence_items": len(ledger),
        "competitor_universe_count": universe_count,
        "competitor_deep_dive_count": deep_count,
        "customer_voice_count": voice_count,
        "errors": errors,
        "warnings": warnings,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
