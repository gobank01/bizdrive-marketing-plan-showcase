#!/usr/bin/env python3
"""Install the portable skill into a supported agent runtime."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import stat
import subprocess
import uuid
from pathlib import Path

SKILL_NAME = "bizdrive-strategic-marketing-plan"
EXCLUDES = {"release", ".git", "__pycache__", ".pytest_cache"}


def ignore(_directory: str, names: list[str]) -> set[str]:
    return {name for name in names if name in EXCLUDES or name == ".DS_Store" or name.endswith(".pyc")}


def logical_absolute(value: str | Path) -> Path:
    return Path(os.path.abspath(os.path.expanduser(str(value))))


def target_dir(runtime: str, scope: str, home: Path, project: Path | None, hermes_home: Path) -> Path:
    if scope == "project":
        if project is None:
            raise SystemExit("--project-dir is required for project scope")
        roots = {
            "codex": project / ".agents" / "skills",
            "claude": project / ".claude" / "skills",
            "generic": project / ".agents" / "skills",
            "hermes": project / ".agents" / "skills",
        }
    else:
        roots = {
            "codex": home / ".agents" / "skills",
            "claude": home / ".claude" / "skills",
            "hermes": hermes_home / "skills",
            "generic": home / ".agents" / "skills",
        }
    return roots[runtime] / SKILL_NAME


def assert_no_symlink_segments(anchor: Path, destination: Path) -> None:
    try:
        relative = destination.relative_to(anchor)
    except ValueError as exc:
        raise SystemExit(f"install target escapes requested root: {destination}") from exc
    current = anchor
    if current.is_symlink():
        raise SystemExit(f"refusing symlinked install root: {current}")
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise SystemExit(f"refusing symlinked install path segment: {current}")


def run_hermes(hermes_cli: str, hermes_home: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ, HERMES_HOME=str(hermes_home))
    try:
        return subprocess.run([hermes_cli, *arguments], text=True, capture_output=True, env=env)
    except FileNotFoundError as exc:
        raise RuntimeError("Hermes installation requires the `hermes` CLI for config/discovery verification") from exc


def get_external_dirs(hermes_cli: str, hermes_home: Path) -> list[str]:
    result = run_hermes(hermes_cli, hermes_home, "config", "get", "--json", "skills.external_dirs")
    if result.returncode:
        raise RuntimeError(f"cannot read Hermes skills.external_dirs: {result.stderr.strip()}")
    try:
        value = json.loads(result.stdout.strip() or "[]")
    except json.JSONDecodeError as exc:
        raise RuntimeError("Hermes skills.external_dirs --json returned invalid JSON") from exc
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise RuntimeError("Hermes skills.external_dirs must resolve to a list of paths")
    return value


def get_config_path(hermes_cli: str, hermes_home: Path) -> Path:
    result = run_hermes(hermes_cli, hermes_home, "config", "path")
    if result.returncode or not result.stdout.strip():
        raise RuntimeError(f"cannot resolve Hermes config path: {result.stderr.strip()}")
    return logical_absolute(result.stdout.strip())


def yaml_external_dirs_block(indent: int, paths: list[str]) -> list[str]:
    prefix = " " * indent
    child = " " * (indent + 2)
    lines = [f"{prefix}external_dirs:\n"]
    lines.extend(f"{child}- {json.dumps(path, ensure_ascii=False)}\n" for path in paths)
    return lines


def replace_external_dirs_yaml(text: str, paths: list[str]) -> str:
    lines = text.splitlines(keepends=True)
    skills_matches = [
        index for index, line in enumerate(lines)
        if re.match(r"^skills:\s*(?:#.*)?(?:\r?\n)?$", line)
    ]
    any_skills_keys = [index for index, line in enumerate(lines) if re.match(r"^skills\s*:", line)]
    if any_skills_keys and not skills_matches:
        raise RuntimeError("config.yaml uses an inline/nonstandard top-level skills value; edit it to block YAML first")
    if len(skills_matches) > 1:
        raise RuntimeError("config.yaml contains multiple top-level skills mappings")
    if not skills_matches:
        prefix = text
        if prefix and not prefix.endswith(("\n", "\r")):
            prefix += "\n"
        if prefix and not prefix.endswith("\n\n"):
            prefix += "\n"
        return prefix + "skills:\n" + "".join(yaml_external_dirs_block(2, paths))

    start = skills_matches[0]
    end = len(lines)
    for index in range(start + 1, len(lines)):
        stripped = lines[index].strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(lines[index]) - len(lines[index].lstrip(" "))
        if indent == 0:
            end = index
            break

    external_index = None
    external_indent = None
    for index in range(start + 1, end):
        match = re.match(r"^(\s+)external_dirs:\s*(?:[^#\s].*)?(?:\r?\n)?$", lines[index])
        if match:
            if external_index is not None:
                raise RuntimeError("config.yaml contains duplicate skills.external_dirs keys")
            external_index = index
            external_indent = len(match.group(1))

    if external_index is None:
        child_indents = []
        for index in range(start + 1, end):
            stripped = lines[index].strip()
            if not stripped or stripped.startswith("#"):
                continue
            child_indents.append(len(lines[index]) - len(lines[index].lstrip(" ")))
        indent = min(child_indents) if child_indents else 2
        lines[end:end] = yaml_external_dirs_block(indent, paths)
        return "".join(lines)

    block_end = end
    assert external_indent is not None
    for index in range(external_index + 1, end):
        stripped = lines[index].strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(lines[index]) - len(lines[index].lstrip(" "))
        if indent <= external_indent:
            block_end = index
            break
    lines[external_index:block_end] = yaml_external_dirs_block(external_indent, paths)
    return "".join(lines)


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.parent / f".{path.name}.tmp-{uuid.uuid4().hex}"
    try:
        temporary.write_bytes(data)
        temporary.chmod(mode)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def configure_hermes_external_dir(
    hermes_cli: str, hermes_home: Path, external_root: Path,
) -> tuple[Path, bool, bytes, int, list[str], bool]:
    current = get_external_dirs(hermes_cli, hermes_home)
    normalized = str(external_root.resolve())
    if normalized in current:
        config_path = get_config_path(hermes_cli, hermes_home)
        existed = config_path.exists()
        original = config_path.read_bytes() if existed else b""
        mode = stat.S_IMODE(config_path.stat().st_mode) if existed else 0o600
        return config_path, existed, original, mode, current, False

    config_path = get_config_path(hermes_cli, hermes_home)
    if config_path.is_symlink():
        raise RuntimeError(f"refusing to edit symlinked Hermes config: {config_path}")
    existed = config_path.exists()
    original = config_path.read_bytes() if existed else b""
    mode = stat.S_IMODE(config_path.stat().st_mode) if existed else 0o600
    text = original.decode("utf-8") if existed else ""
    updated = current + [normalized]
    rendered = replace_external_dirs_yaml(text, updated).encode("utf-8")
    atomic_write(config_path, rendered, mode)
    verified = get_external_dirs(hermes_cli, hermes_home)
    if verified != updated:
        if existed:
            atomic_write(config_path, original, mode)
        elif config_path.exists():
            config_path.unlink()
        raise RuntimeError("Hermes config round-trip did not preserve skills.external_dirs as a list")
    return config_path, existed, original, mode, current, True


def restore_config(snapshot: tuple[Path, bool, bytes, int, list[str], bool]) -> None:
    config_path, existed, original, mode, _current, changed = snapshot
    if not changed:
        return
    if existed:
        atomic_write(config_path, original, mode)
    elif config_path.exists():
        config_path.unlink()


def verify_hermes_discovery(hermes_cli: str, hermes_home: Path) -> None:
    result = run_hermes(hermes_cli, hermes_home, "skills", "list")
    if result.returncode:
        raise RuntimeError(f"Hermes skill discovery check failed: {result.stderr.strip()}")
    if SKILL_NAME not in result.stdout:
        raise RuntimeError(f"Hermes did not discover installed skill {SKILL_NAME}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", choices=("codex", "claude", "hermes", "generic"), required=True)
    parser.add_argument("--scope", choices=("user", "project"), default="user")
    parser.add_argument("--project-dir")
    parser.add_argument("--home", help="Override user home (primarily for testing)")
    parser.add_argument("--hermes-home", help="Override HERMES_HOME for a Hermes profile")
    parser.add_argument("--hermes-cli", default=os.environ.get("HERMES_CLI", "hermes"))
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    source = Path(__file__).resolve().parents[1]
    home = logical_absolute(args.home) if args.home else logical_absolute(Path.home())
    project = logical_absolute(args.project_dir) if args.project_dir else None
    hermes_home = logical_absolute(args.hermes_home or os.environ.get("HERMES_HOME") or (home / ".hermes"))
    raw_target = target_dir(args.runtime, args.scope, home, project, hermes_home)
    anchor = project if args.scope == "project" else (hermes_home if args.runtime == "hermes" else home)
    assert anchor is not None
    assert_no_symlink_segments(anchor, raw_target)
    target = raw_target

    if target.resolve() == source or source in target.resolve().parents:
        raise SystemExit("refusing to install the skill inside its source package")
    if target.exists() and not args.force:
        raise SystemExit(f"target exists: {target}; use --force to replace")

    hermes_external_root = None
    if args.runtime == "hermes" and args.scope == "project":
        assert project is not None
        hermes_external_root = project / ".agents" / "skills"

    report = {
        "status": "dry-run" if args.dry_run else "installed",
        "runtime": args.runtime,
        "scope": args.scope,
        "source": str(source),
        "target": str(target),
        "hermes_home": str(hermes_home) if args.runtime == "hermes" else None,
        "hermes_external_dir": str(hermes_external_root) if hermes_external_root else None,
        "hermes_config_updated": False,
        "hermes_discovery_verified": False,
    }
    if args.dry_run:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    target.parent.mkdir(parents=True, exist_ok=True)
    assert_no_symlink_segments(anchor, target)
    staging = target.parent / f".{SKILL_NAME}.installing-{uuid.uuid4().hex}"
    backup = target.parent / f".{SKILL_NAME}.backup-{uuid.uuid4().hex}"
    config_snapshot = None
    try:
        shutil.copytree(source, staging, ignore=ignore)
        if hermes_external_root is not None:
            config_snapshot = configure_hermes_external_dir(
                args.hermes_cli, hermes_home, hermes_external_root,
            )
            report["hermes_config_updated"] = config_snapshot[-1]
        if target.exists():
            target.replace(backup)
        staging.replace(target)
        if args.runtime == "hermes":
            verify_hermes_discovery(args.hermes_cli, hermes_home)
            report["hermes_discovery_verified"] = True
        if backup.exists():
            shutil.rmtree(backup)
    except Exception as exc:
        if staging.exists():
            shutil.rmtree(staging)
        if target.exists() and backup.exists():
            shutil.rmtree(target)
        if backup.exists() and not target.exists():
            backup.replace(target)
        if config_snapshot is not None:
            restore_config(config_snapshot)
        raise SystemExit(str(exc)) from exc

    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
