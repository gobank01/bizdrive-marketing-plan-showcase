#!/usr/bin/env python3
"""Shared fail-closed inventory policy for student release files."""
from __future__ import annotations

import re
import stat
from pathlib import Path

EXPECTED_DISTRIBUTION_PATHS = frozenset({
    "CHANGELOG.md",
    "INSTALL.md",
    "LICENSE.md",
    "README.md",
    "RELEASE_STATUS.md",
    "SKILL.md",
    "examples/premium-toothpaste-thailand/00_brief.md",
    "examples/premium-toothpaste-thailand/README_FIRST.md",
    "examples/premium-toothpaste-thailand/assumptions_register.csv",
    "examples/premium-toothpaste-thailand/budget_allocation.json",
    "examples/premium-toothpaste-thailand/category_landscape.md",
    "examples/premium-toothpaste-thailand/competitor_matrix.csv",
    "examples/premium-toothpaste-thailand/competitor_universe.csv",
    "examples/premium-toothpaste-thailand/customer_voice.json",
    "examples/premium-toothpaste-thailand/decision_register.json",
    "examples/premium-toothpaste-thailand/evidence_ledger.json",
    "examples/premium-toothpaste-thailand/meta.json",
    "examples/premium-toothpaste-thailand/positioning_map.csv",
    "examples/premium-toothpaste-thailand/positioning_maps.svg",
    "examples/premium-toothpaste-thailand/step10_kpis_measurement.md",
    "examples/premium-toothpaste-thailand/step11_execution_timeline.md",
    "examples/premium-toothpaste-thailand/step12_executive_report.md",
    "examples/premium-toothpaste-thailand/step1_market_analysis.md",
    "examples/premium-toothpaste-thailand/step2_competitor_analysis.md",
    "examples/premium-toothpaste-thailand/step3_swot_analysis.md",
    "examples/premium-toothpaste-thailand/step4_customer_persona.md",
    "examples/premium-toothpaste-thailand/step5_positioning_key_message.md",
    "examples/premium-toothpaste-thailand/step6_online_strategy.md",
    "examples/premium-toothpaste-thailand/step7_offline_strategy.md",
    "examples/premium-toothpaste-thailand/step8_content_plan.md",
    "examples/premium-toothpaste-thailand/step8b_30_clip_scripts.md",
    "examples/premium-toothpaste-thailand/step9_budget_allocation.md",
    "examples/premium-toothpaste-thailand/strategic_plan.md",
    "examples/premium-toothpaste-thailand/strategy_choice.md",
    "examples/premium-toothpaste-thailand/voice_analysis.json",
    "references/12_step_workflow.md",
    "references/30_clips_framework.md",
    "references/case_simulation.md",
    "references/provenance.md",
    "references/research_query_bank.md",
    "references/strategic_plan_framework.md",
    "references/strategy_choice_framework.md",
    "references/web_dashboard_blueprint.md",
    "scripts/budget_allocator.py",
    "scripts/build_release.py",
    "scripts/distribution_policy.py",
    "scripts/init_plan.py",
    "scripts/install_skill.py",
    "scripts/validate_distribution.py",
    "scripts/validate_plan.py",
    "templates/clip_script_template.md",
    "templates/executive_report_template.md",
    "templates/readme_first_template.md",
    "templates/step_template.md",
    "templates/strategic_plan_template.md",
    "templates/strategy_choice_template.md",
    "tests/test_package.py",
})


def _expected_directories() -> frozenset[str]:
    directories: set[str] = set()
    for name in EXPECTED_DISTRIBUTION_PATHS:
        parent = Path(name).parent
        while parent != Path("."):
            directories.add(parent.as_posix())
            parent = parent.parent
    return frozenset(directories)


EXPECTED_DISTRIBUTION_DIRS = _expected_directories()
ALLOWED_SUFFIXES = {".md", ".py", ".json", ".csv", ".svg"}
EXCLUDED_PARTS = {".git", "release", "__pycache__", ".pytest_cache"}
FORBIDDEN_DIR_NAMES = {"private", "raw", "raw_data", "research_private"}
FORBIDDEN_FILE_NAMES = {
    ".netrc", ".npmrc", ".pypirc", "credentials", "credentials.json",
    "id_dsa", "id_ed25519", "id_rsa", "secret", "secret.md", "secrets", "secrets.md",
}
FORBIDDEN_FILE_SUFFIXES = {".key", ".p12", ".pem", ".pfx"}
SECRET_PATTERNS = {
    "private key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "AWS access key": re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
    "GitHub token": re.compile(rb"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    "OpenAI-style secret": re.compile(rb"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "credential assignment": re.compile(
        rb"(?im)^[ \t]*(?:api[_-]?key|secret|password|passwd|token|access[_-]?token|"
        rb"client[_-]?secret)[ \t]*[:=][ \t]*[\"']?[^\s\"'#]{6,}"
    ),
    "direct customer statement": re.compile(
        rb"(?im)^[ \t]*(?:customer(?:[ \t]+voice)?|reviewer|user)[ \t]*:[ \t]*"
        rb"[\"']?[ \t]*(?:I|We)\b"
    ),
}


class DistributionPolicyError(ValueError):
    """Raised when any source-tree entry is unsafe to distribute."""

    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


def inspect_distribution_tree(root: Path) -> tuple[list[tuple[Path, Path]], list[str]]:
    root = root.resolve()
    files: list[tuple[Path, Path]] = []
    errors: list[str] = []

    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if rel == Path("MANIFEST-SHA256.txt"):
            continue
        if any(part in EXCLUDED_PARTS for part in rel.parts):
            continue
        display = rel.as_posix()
        try:
            mode = path.lstat().st_mode
        except OSError as exc:
            errors.append(f"cannot inspect distribution entry {display}: {exc}")
            continue

        if stat.S_ISLNK(mode):
            errors.append(f"symlink must not ship: {display}")
            continue
        if any(part.startswith(".") for part in rel.parts):
            errors.append(f"hidden distribution entry is not allowed: {display}")
            continue

        private_parts = rel.parts if stat.S_ISDIR(mode) else rel.parts[:-1]
        if any(part.casefold() in FORBIDDEN_DIR_NAMES for part in private_parts):
            errors.append(f"private/raw directory must not ship: {display}")
            continue

        if stat.S_ISDIR(mode):
            if display not in EXPECTED_DISTRIBUTION_DIRS:
                errors.append(f"unreviewed distribution directory is not allowed: {display}")
            continue
        if not stat.S_ISREG(mode):
            errors.append(f"non-regular file must not ship: {display}")
            continue
        if display not in EXPECTED_DISTRIBUTION_PATHS:
            errors.append(f"unreviewed distribution file is not allowed: {display}")
            continue

        name = path.name.casefold()
        if (
            name.startswith(".env")
            or name in FORBIDDEN_FILE_NAMES
            or path.suffix.casefold() in FORBIDDEN_FILE_SUFFIXES
        ):
            errors.append(f"sensitive filename must not ship: {display}")
            continue
        if path.suffix.casefold() not in ALLOWED_SUFFIXES:
            errors.append(f"unsupported distribution file type: {display}")
            continue

        try:
            data = path.read_bytes()
        except OSError as exc:
            errors.append(f"cannot read distribution file {display}: {exc}")
            continue
        if b"\x00" in data:
            errors.append(f"binary/NUL file must not ship: {display}")
            continue
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            errors.append(f"non-UTF-8 file must not ship: {display}")
            continue
        for label, pattern in SECRET_PATTERNS.items():
            if pattern.search(data):
                errors.append(f"{label} found in {display}")
        files.append((path, rel))

    missing = sorted(EXPECTED_DISTRIBUTION_PATHS - {rel.as_posix() for _, rel in files})
    for name in missing:
        errors.append(f"expected distribution file is missing or unsafe: {name}")
    return files, errors


def collect_distribution_files(root: Path) -> list[tuple[Path, Path]]:
    files, errors = inspect_distribution_tree(root)
    if errors:
        raise DistributionPolicyError(errors)
    return files
