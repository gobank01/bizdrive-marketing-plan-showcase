#!/usr/bin/env python3
"""Allocate a fixed marketing budget with exact integer arithmetic."""
from __future__ import annotations

import argparse
import json
import os
import tempfile
from pathlib import Path

ONLINE_SUB = {
    "general": {"meta": 45, "tiktok": 25, "google_youtube": 15, "line": 8, "other": 7},
    "fmcg": {"meta": 50, "tiktok": 30, "google_youtube": 8, "line": 7, "other": 5},
    "high_ticket": {"meta": 35, "tiktok": 20, "google_youtube": 25, "line": 10, "other": 10},
    "education": {"meta": 40, "tiktok": 20, "google_youtube": 25, "line": 10, "other": 5},
}


def atomic_write_text(directory: Path, filename: str, text: str) -> None:
    target = directory / filename
    if directory.is_symlink():
        raise SystemExit(f"refusing symlinked project directory: {directory}")
    if target.is_symlink():
        raise SystemExit(f"refusing symlinked output: {target}")
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=directory,
            prefix=f".{filename}.", suffix=".tmp", delete=False,
        ) as temporary:
            temporary.write(text)
            temporary.flush()
            os.fsync(temporary.fileno())
            temporary_name = temporary.name
        os.replace(temporary_name, target)
    finally:
        if temporary_name:
            Path(temporary_name).unlink(missing_ok=True)


def mix_for_budget(monthly_budget: int) -> dict[str, int]:
    if monthly_budget <= 100_000:
        return {"online": 80, "offline": 5, "kol": 10, "reserve": 5}
    if monthly_budget <= 500_000:
        return {"online": 70, "offline": 8, "kol": 17, "reserve": 5}
    if monthly_budget <= 1_000_000:
        return {"online": 60, "offline": 12, "kol": 23, "reserve": 5}
    if monthly_budget <= 5_000_000:
        return {"online": 55, "offline": 18, "kol": 22, "reserve": 5}
    return {"online": 50, "offline": 22, "kol": 23, "reserve": 5}


def allocate_exact(total: int, percentages: dict[str, int]) -> dict[str, int]:
    if sum(percentages.values()) != 100:
        raise ValueError("percentages must sum to 100")
    raw = {key: total * pct / 100 for key, pct in percentages.items()}
    allocated = {key: int(value) for key, value in raw.items()}
    remainder = total - sum(allocated.values())
    order = sorted(raw, key=lambda key: (raw[key] - allocated[key], key), reverse=True)
    for key in order[:remainder]:
        allocated[key] += 1
    assert sum(allocated.values()) == total
    return allocated


def build(monthly_budget: int, duration: int, product_type: str) -> dict:
    if monthly_budget <= 0 or duration <= 0:
        raise ValueError("budget and duration must be positive")
    total = monthly_budget * duration
    mix = mix_for_budget(monthly_budget)
    allocation = allocate_exact(total, mix)
    online_sub = allocate_exact(allocation["online"], ONLINE_SUB[product_type])
    return {
        "summary": {
            "monthly_budget_thb": monthly_budget,
            "duration_months": duration,
            "total_budget_thb": total,
            "product_type": product_type,
            "channel_mix_pct": mix,
            "status": "heuristic_pending_research_validation",
        },
        "allocation_thb": {**allocation, "online_sub": online_sub},
        "scenario_status": "not_generated_without_sourced_or_owner_approved_inputs",
        "scenario_required_inputs": [
            "channel cost metric and scope",
            "conversion path and rate",
            "net revenue per order or sale",
            "COGS and variable costs",
            "returns/refunds and target contribution",
        ],
        "warning": (
            "Channel allocations are illustrative arithmetic heuristics based only on budget size "
            "and product-type label; they are not benchmarks, forecasts, recommendations, or spend approval."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir")
    parser.add_argument("--monthly-budget", type=int)
    parser.add_argument("--duration", type=int)
    parser.add_argument("--product-type", choices=sorted(ONLINE_SUB), default="general")
    args = parser.parse_args()

    project = None
    if args.project_dir:
        project_input = Path(args.project_dir).expanduser()
        if project_input.is_symlink():
            raise SystemExit(f"refusing symlinked project directory: {project_input}")
        project = project_input.resolve()
        if not project.is_dir():
            raise SystemExit(f"project directory does not exist: {project}")
        output = project / "budget_allocation.json"
        if output.is_symlink():
            raise SystemExit(f"refusing symlinked output: {output}")
        if output.resolve(strict=False).parent != project:
            raise SystemExit(f"budget output escapes project directory: {output}")
    if project:
        meta = json.loads((project / "meta.json").read_text(encoding="utf-8"))
        monthly_budget = meta["monthly_budget_thb"]
        duration = meta["duration_months"]
    else:
        if args.monthly_budget is None or args.duration is None:
            raise SystemExit("provide --project-dir or --monthly-budget and --duration")
        monthly_budget, duration = args.monthly_budget, args.duration

    result = build(monthly_budget, duration, args.product_type)
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if project:
        atomic_write_text(project, "budget_allocation.json", payload + "\n")
    print(payload)


if __name__ == "__main__":
    main()
