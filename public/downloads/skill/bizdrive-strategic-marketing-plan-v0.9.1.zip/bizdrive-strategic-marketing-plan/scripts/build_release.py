#!/usr/bin/env python3
"""Build a deterministic, release-gated ZIP and SHA-256 file."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

from distribution_policy import DistributionPolicyError, collect_distribution_files

PREFIX = "bizdrive-strategic-marketing-plan"
def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def package_version(root: Path) -> str:
    text = (root / "SKILL.md").read_text(encoding="utf-8")
    match = re.search(r"(?m)^metadata:\s*$[\s\S]*?^  version:\s*[\"']?([^\"'\s]+)", text)
    if not match:
        raise SystemExit("cannot derive metadata.version from SKILL.md")
    return match.group(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-dir", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--output-dir")
    args = parser.parse_args()
    root = Path(args.package_dir).expanduser().resolve()
    output = Path(args.output_dir).expanduser().resolve() if args.output_dir else root / "release"

    check = subprocess.run(
        [sys.executable, str(root / "scripts" / "validate_distribution.py"), str(root), "--release"],
        text=True, capture_output=True,
    )
    if check.returncode:
        print(check.stdout, end="")
        print(check.stderr, end="", file=sys.stderr)
        raise SystemExit("distribution validation failed")

    version = package_version(root)
    try:
        files = collect_distribution_files(root)
    except DistributionPolicyError as exc:
        raise SystemExit("unsafe distribution tree: " + "; ".join(exc.errors)) from exc
    manifest_lines = [f"{digest(path.read_bytes())}  {rel.as_posix()}" for path, rel in files]
    manifest = ("\n".join(manifest_lines) + "\n").encode("utf-8")

    payload_names = [f"{PREFIX}/{rel.as_posix()}" for _, rel in files]
    manifest_name = f"{PREFIX}/MANIFEST-SHA256.txt"
    member_names = payload_names + [manifest_name]
    if len(member_names) != len(set(member_names)):
        duplicates = sorted({name for name in member_names if member_names.count(name) > 1})
        raise SystemExit(f"duplicate archive member names: {duplicates}")

    output.mkdir(parents=True, exist_ok=True)
    zip_path = output / f"{PREFIX}-v{version}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        if len(files) != len(payload_names):
            raise SystemExit("payload-name count mismatch")
        for (path, _), member_name in zip(files, payload_names):
            info = zipfile.ZipInfo(member_name, date_time=(2020, 1, 1, 0, 0, 0))
            mode = 0o755 if path.suffix == ".py" else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
        info = zipfile.ZipInfo(manifest_name, date_time=(2020, 1, 1, 0, 0, 0))
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, manifest)

    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or names.count(manifest_name) != 1:
            raise SystemExit("archive duplicate-member verification failed")
        if archive.testzip() is not None:
            raise SystemExit("archive CRC verification failed")
        for info in archive.infolist():
            if (
                info.is_dir()
                or not stat.S_ISREG(info.external_attr >> 16)
                or info.filename.startswith("/")
                or "\\" in info.filename
                or ".." in Path(info.filename).parts
            ):
                raise SystemExit(f"unsafe archive member: {info.filename}")
        if archive.read(manifest_name) != manifest:
            raise SystemExit("archive manifest bytes differ from generated manifest")
        for path, rel in files:
            member = f"{PREFIX}/{rel.as_posix()}"
            if digest(archive.read(member)) != digest(path.read_bytes()):
                raise SystemExit(f"archive payload hash mismatch: {member}")

    zip_digest = digest(zip_path.read_bytes())
    checksum_path = zip_path.with_suffix(zip_path.suffix + ".sha256")
    checksum_path.write_text(f"{zip_digest}  {zip_path.name}\n", encoding="utf-8")
    print(json.dumps({
        "status": "release",
        "version": version,
        "zip": str(zip_path),
        "sha256": zip_digest,
        "checksum_file": str(checksum_path),
        "files": len(files) + 1,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
