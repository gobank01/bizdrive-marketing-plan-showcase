#!/usr/bin/env python3
"""Validate a portable student-distribution package offline."""
from __future__ import annotations

import argparse
import hashlib
import json
import py_compile
import re
import subprocess
import sys
from pathlib import Path

from distribution_policy import inspect_distribution_tree

FORBIDDEN = {
    "macOS user path": re.compile(r"/Users/[^/\s]+/"),
    "Linux user path": re.compile(r"/home/[^/\s]+/"),
    "Windows user path": re.compile(r"[A-Za-z]:\\\\Users\\\\[^\\\s]+\\"),
    "private host identity": re.compile(r"\b(?:macminibot|gobank01)\b", re.I),
    "Hermes cache path": re.compile(r"\.hermes/cache/"),
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "record-level source URL": re.compile(r"#review-|[?&](?:lc|comment_id|review_id)=", re.I),
}
EXAMPLE_PRIVACY_MARKERS = {
    "exact Customer Voice example heading": re.compile(r"Voice examples\s*\(exact", re.I),
    "exact Customer Voice excerpt section": re.compile(r"Exact excerpts?\s*\(", re.I),
    "raw excerpt location claim": re.compile(r"(?:full short excerpts?|source-level exact text).*customer_voice\.json", re.I),
    "shareable Voice contract exposes excerpt": re.compile(r"source URL/date/excerpt/themes", re.I),
    "shareable content requests exact excerpt": re.compile(r"(?:Customer words|source type[^\n]{0,80}).{0,80}exact excerpt", re.I),
    "private Voice field in structured artifact": re.compile(
        r"[\"'](?:quote|excerpt|author|author_name|username|profile|profile_url|comment_id|review_id|email|phone)[\"']\s*:",
        re.I,
    ),
}
REQUIRED = {
    "SKILL.md", "README.md", "INSTALL.md", "LICENSE.md", "CHANGELOG.md", "RELEASE_STATUS.md",
    "scripts/init_plan.py", "scripts/budget_allocator.py", "scripts/validate_plan.py",
    "scripts/install_skill.py", "scripts/validate_distribution.py", "scripts/build_release.py",
    "scripts/distribution_policy.py",
    "templates/strategic_plan_template.md", "references/strategic_plan_framework.md",
    "references/provenance.md", "examples/premium-toothpaste-thailand/README_FIRST.md",
}
ALLOWED_FRONTMATTER = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
APPROVED_LICENSE = "CC-BY-NC-4.0 AND MIT"
APPROVED_VERSION = "0.9.1"


def parse_frontmatter(text: str) -> tuple[dict[str, str], dict[str, str]]:
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md must start with YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("SKILL.md frontmatter is not closed")
    fields: dict[str, str] = {}
    metadata: dict[str, str] = {}
    section = ""
    for line in text[4:end].splitlines():
        if ":" in line and not line.startswith(" "):
            key, value = line.split(":", 1)
            section = key.strip()
            fields[section] = value.strip().strip('"')
        elif section == "metadata" and line.startswith("  ") and ":" in line:
            key, value = line.strip().split(":", 1)
            metadata[key.strip()] = value.strip().strip('"')
    return fields, metadata


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("package_dir", nargs="?", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--release", action="store_true", help="Apply final distribution-status checks")
    args = parser.parse_args()
    root = Path(args.package_dir).expanduser().resolve()
    errors: list[str] = []
    warnings: list[str] = []

    for name in sorted(REQUIRED):
        if not (root / name).is_file():
            errors.append(f"missing required file: {name}")

    distribution_files, policy_errors = inspect_distribution_tree(root)
    errors.extend(policy_errors)

    skill_path = root / "SKILL.md"
    if skill_path.is_file():
        try:
            fields, metadata = parse_frontmatter(skill_path.read_text(encoding="utf-8"))
            unexpected = sorted(set(fields) - ALLOWED_FRONTMATTER)
            if unexpected:
                errors.append(f"SKILL.md has non-portable frontmatter fields: {unexpected}")
            for key in ("name", "description", "license", "compatibility", "metadata"):
                if key not in fields:
                    errors.append(f"SKILL.md missing frontmatter field: {key}")
            for key in ("version", "author"):
                if not metadata.get(key):
                    errors.append(f"SKILL.md metadata missing field: {key}")
            if fields.get("name") != "bizdrive-strategic-marketing-plan":
                errors.append("SKILL.md name mismatch")
            description = fields.get("description", "")
            # Agent Skills runtimes match on the description, so it must carry the
            # trigger wording students actually type. 1024 is the portable ceiling.
            if len(description) > 1024 or not description.endswith("."):
                errors.append("SKILL.md description must be <=1024 chars and end with a period")
            if fields.get("license") != APPROVED_LICENSE:
                errors.append(f"SKILL.md license must be exactly {APPROVED_LICENSE!r}")
            if metadata.get("version") != APPROVED_VERSION:
                errors.append(f"SKILL.md metadata.version must be {APPROVED_VERSION}")
        except Exception as exc:
            errors.append(str(exc))

    license_path = root / "LICENSE.md"
    if license_path.is_file():
        license_text = license_path.read_text(encoding="utf-8")
        required_license_terms = (
            "Creative Commons Attribution-NonCommercial 4.0 International",
            "https://creativecommons.org/licenses/by-nc/4.0/legalcode",
            "MIT License",
            "Permission is hereby granted, free of charge",
            "scripts/",
        )
        for term in required_license_terms:
            if term not in license_text:
                errors.append(f"LICENSE.md missing approved term: {term}")
        if re.search(r"pending|not yet approved|no license .* granted", license_text, re.I):
            errors.append("LICENSE.md still contains a pending/no-distribution marker")

    provenance_path = root / "references" / "provenance.md"
    if provenance_path.is_file():
        provenance_text = provenance_path.read_text(encoding="utf-8")
        if "rights_status: owner-authorized" not in provenance_text:
            errors.append("provenance.md lacks owner-authorized upstream rights status")
        if "authorization_date: 2026-08-28" not in provenance_text:
            errors.append("provenance.md lacks authorization date")

    if args.release:
        status_path = root / "RELEASE_STATUS.md"
        status_text = status_path.read_text(encoding="utf-8") if status_path.is_file() else ""
        if "APPROVED FOR DISTRIBUTION" not in status_text:
            errors.append("RELEASE_STATUS.md does not approve distribution")

    validator_sources = {
        Path("scripts/distribution_policy.py"),
        Path("scripts/validate_distribution.py"),
        Path("scripts/validate_plan.py"),
    }
    example_root = root / "examples" / "premium-toothpaste-thailand"
    for path, rel in distribution_files:
        text = path.read_text(encoding="utf-8", errors="replace")
        if rel not in validator_sources:
            for label, pattern in FORBIDDEN.items():
                if pattern.search(text):
                    errors.append(f"{label} found in {rel}")
        if example_root in path.parents:
            for label, pattern in EXAMPLE_PRIVACY_MARKERS.items():
                if pattern.search(text):
                    errors.append(f"{label} found in {rel}")


    for path in sorted((root / "scripts").glob("*.py")) if (root / "scripts").is_dir() else []:
        try:
            py_compile.compile(str(path), doraise=True)
        except Exception as exc:
            errors.append(f"Python compile failed for {path.name}: {exc}")

    example = root / "examples" / "premium-toothpaste-thailand"
    validator = root / "scripts" / "validate_plan.py"
    if example.is_dir() and validator.is_file():
        run = subprocess.run(
            [
                sys.executable, str(validator), str(example), "--min-competitors", "10",
                "--require-customer-voice", "--strategic-handoff", "--publication-mode", "shareable",
            ],
            text=True, capture_output=True,
        )
        if run.returncode:
            errors.append(f"worked example validation failed: {run.stdout.strip()} {run.stderr.strip()}")

    report = {
        "status": "pass" if not errors else "fail",
        "release_ready": not errors,
        "package_dir": str(root),
        "skill_sha256": sha256(skill_path) if skill_path.is_file() else None,
        "errors": errors,
        "warnings": warnings,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(1 if errors else 0)


if __name__ == "__main__":
    main()
