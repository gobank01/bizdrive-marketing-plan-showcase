---
name: bizdrive-strategic-marketing-plan
description: วางแผนกลยุทธ์และแผนการตลาดแบบอ้างอิงหลักฐาน (evidence-led) ครบตั้งแต่ category landscape, คู่แข่ง, Strategy Choice, Strategic Plan ไปจนถึง Marketing Plan 12 ขั้น พร้อมงบ KPI timeline และสคริปต์คลิปสั้น 30 ชิ้น. ใช้เมื่อผู้ใช้พิมพ์ "วางแผนการตลาด", "ทำแผนการตลาด", "แผนกลยุทธ์", "marketing plan", "strategic plan", "วิเคราะห์คู่แข่ง", "ขอแผนยิงแอด" หรือบอกชื่อสินค้า/แบรนด์ + งบต่อเดือน + ระยะเวลา. Build evidence-led strategic and marketing plans.
license: CC-BY-NC-4.0 AND MIT
compatibility: Python 3.10+; web, file, and shell tools recommended.
metadata:
  version: "0.9.2"
  author: "Prachaya Piyasirisilp (BizDrive), AI-assisted"
---

# BizDrive Strategic + Marketing Plan

Build a category landscape, material competitor universe, explicit strategic
choices, a brand or organization Strategic Plan, and an actionable Marketing
Plan. The skill is runtime-agnostic: use the host AI agent's native web, file,
browser and shell tools. It does not authorize spending, publishing, outreach,
product claims or launch activity.

## When to Use

Use when the user asks for one or more of:

- category or market landscape analysis
- a material competitor universe and exact-SKU deep dive
- a brand, business-unit or organization Strategic Plan
- a complete evidence-led Marketing Plan
- a reusable plan handoff another person can understand without prior context

Do not use for a single caption, isolated persona, one ad, narrow fact lookup,
or an execution request that lacks planning scope.

## Required Inputs

Ask once for missing required inputs:

1. product, service, brand, business unit or organization
2. geography
3. monthly Marketing Plan budget and duration
4. planning entity and Strategic Plan horizon

High-value owner inputs:

- ambition and explicit business outcomes
- current portfolio, offer, price, margin and unit economics
- capabilities, operating model, talent and decision rights
- capacity, inventory, service level and channel access
- known competitors, regulatory constraints and existing evidence

If only product, budget and duration are supplied, continue as a **provisional
brand Strategic Plan**. Never infer an enterprise strategy from campaign inputs.

## Portability and Tool Contract

- Resolve all references, templates and scripts relative to this `SKILL.md`.
- Write outputs under a user-approved workspace; the default initializer uses
  `./marketing-plans/<slug>/` from the current directory.
- Use the host agent's native web search/browser for current evidence, native
  read/write tools for files, and a shell/terminal only for the included Python
  scripts and validation.
- Use the strongest reasoning model available for integrated synthesis. If the
  runtime cannot browse, cite, read files or execute validators, disclose the
  limitation and do not call the run fully verified.
- Scripts use Python 3.10+ standard library only; no API key is required by the
  skill itself.

## Output Contract

### Core Marketing Plan

Create exactly these 14 Markdown files:

1. `00_brief.md`
2. `step1_market_analysis.md`
3. `step2_competitor_analysis.md`
4. `step3_swot_analysis.md`
5. `step4_customer_persona.md`
6. `step5_positioning_key_message.md`
7. `step6_online_strategy.md`
8. `step7_offline_strategy.md`
9. `step8_content_plan.md`
10. `step8b_30_clip_scripts.md`
11. `step9_budget_allocation.md`
12. `step10_kpis_measurement.md`
13. `step11_execution_timeline.md`
14. `step12_executive_report.md`

### Strategic handoff

Also create:

- `README_FIRST.md`
- `category_landscape.md`
- `competitor_universe.csv`
- `competitor_matrix.csv`
- `strategy_choice.md`
- `strategic_plan.md`
- `assumptions_register.csv`
- `decision_register.json`
- `meta.json`
- `evidence_ledger.json`
- `budget_allocation.json`

Expanded Customer Voice adds a shareable `customer_voice.json`. Keep any raw
excerpts or record-level source identifiers outside the shareable project in a
restricted private research location.

## Evidence Classes

Keep these classes separate in prose and structured artifacts:

1. owner-approved facts
2. verified facts from retrievable sources
3. dated observations
4. calculations with visible formulas
5. assumptions
6. strategic inference
7. unknowns and coverage gaps

Never fabricate TAM, market share, prices, competitor spend, reviews, claims,
certifications, test results, conversion rates or legal conclusions.

## Procedure

1. **Initialize.** Run `scripts/init_plan.py` with an explicit product/entity,
   budget, duration, strategic entity, horizon and output directory.
   Completion: `meta.json`, registers and `00_brief.md` exist; total budget is
   monthly budget × duration.
2. **Declare the category contract.** Define geography, evidence date,
   category/JTBD, SKU/pack rule, price and channel boundaries, time boundary,
   in-scope/out-of-scope rules, required fields and unknown marker.
   Completion: `category_landscape.md` states the boundary before brand search.
3. **Research the landscape.** Cover need states, category architecture,
   price-pack ladder, routes to market, economics, regulation and trends. Put
   every load-bearing claim in `evidence_ledger.json` with source URL, title,
   publication date, retrieval date, supported claim and evidence grade.
4. **Build the universe before the shortlist.** Discover direct, indirect,
   substitute, emerging and adjacent competitors. Record inclusion/exclusion
   rationale and exact source. Stop only when requested coverage is met and
   three consecutive discovery lanes add no material class; state gaps.
5. **Freeze the deep-dive set.** Select 10–20 exact SKU/offer records, or the
   owner-requested count, spanning relevant classes. Use the same frozen set
   across price, claim, channel, Customer Voice and positioning analysis.
6. **Apply the evidence gate.** Prefer official/primary sources for claims,
   rules and product facts. Label retailer, marketplace, review and analyst
   sources appropriately. Treat internal benchmark tables as heuristics until
   corroborated for the category.
7. **Apply the Customer Voice privacy gate.** Code needs, triggers,
   objections, sentiment, product, date, language, source type and sampling
   concentration. The shareable dataset is privacy-reduced/pseudonymized, not
   fully anonymous: remove verbatim excerpts, authors, profiles, review/comment
   IDs and record-level links. A local sequential `record_key` may preserve the
   denominator but must not encode a source identifier. Never create synthetic
   or composite quotes.
8. **Map the category.** Build at least three positioning maps from the frozen
   set. Save coordinates/rationale plus SVG. Label analyst scores as rubrics,
   not measured perception. Inspect axes, legend, clipping, overlap and text
   contrast.
9. **Make explicit strategic choices.** Read
   `references/strategy_choice_framework.md` and compare at least three real
   options. Select one primary choice, one secondary experiment and no-go
   zones. Write Winning Aspiration, Where to Play, How to Win, capabilities,
   management systems and learning agenda in `strategy_choice.md`.
10. **Build the Strategic Plan.** Read
    `references/strategic_plan_framework.md` and use
    `templates/strategic_plan_template.md`. Declare entity, horizon and status;
    then write diagnosis, ambition, portfolio choices, capabilities, operating
    model, resource allocation, initiatives, scorecard, multi-horizon roadmap,
    scenarios, governance and decision gates. If enterprise inputs are absent,
    keep it provisional and list owner decisions required.
11. **Synthesize the Marketing Plan.** Follow
    `references/12_step_workflow.md` sequentially. Every target, workstream and
    budget line must trace to a strategic objective or be labeled exploratory.
12. **Allocate budget.** Run `scripts/budget_allocator.py`. Allocation and
    reserve must sum exactly to total budget. Missing contribution economics
    means allowable CAC and commercial break-even remain unknown.
13. **Build scenarios and content.** Best/Base/Worst cases use explicit inputs
    and formulas and are not forecasts. Create exactly 30 distinct short-video
    scripts with hook, spoken body, CTA, caption, production note, KPI
    hypothesis and claim/compliance note.
14. **Write the handoff.** Use the README, strategy and executive templates.
    Expose coverage gaps, assumptions, decisions, owners, reversal triggers,
    approval boundaries and a 30/60/90 proposed action plan.
15. **Validate.** Run:

    `python scripts/validate_plan.py <project-dir> --strategic-handoff`

    Add `--min-competitors N` and `--require-customer-voice` in expanded mode.
    Completion: exit code 0 with no errors.
16. **Review independently.** Have a second agent or human inspect security,
    evidence traceability, strategic coherence, privacy, arithmetic,
    accessibility and usability. Fix blockers and rerun validation.
17. **Deliver without executing.** Start with `README_FIRST.md`, artifact path,
    universe/deep-dive/Voice counts, primary choice, critical unknowns and
    validation result. External action remains a separate approval boundary.

## Approval Boundaries

Research and local planning do not authorize:

- product formulation, regulated claims or label approval
- spending, purchasing, contracts or hiring
- publishing, uploading, deployment or account changes
- contacting customers, competitors, creators, clinics, retailers or partners
- campaign launch or reserve release

Record specific owner approvals in `decision_register.json`; never infer them
from the existence of a plan.

## Pitfalls

- “All competitors” is meaningless without geography, JTBD/category, SKU,
  price/channel and time boundaries. Report a material universe and its gaps.
- A positioning statement or campaign calendar is not strategy. Strategy makes
  trade-offs, exclusions and capability/resource choices.
- A category/brand choice is not a Strategic Plan. The Strategic Plan must add
  horizon, portfolio, operating model, resources, initiatives and governance.
- A public repository does not make raw Customer Voice safe. Separate private
  evidence from shareable outputs and scan every publication surface.
- Three planning inputs can start a run but cannot justify precise revenue,
  ROAS, break-even or organization-level commitments.
- A valid plan is not permission to execute it.

## Verification

A valid expanded run proves:

- all 14 core files and every strategic-handoff artifact exist
- category boundary, universe classes, selection logic, saturation result and
  coverage gaps are explicit
- exact-SKU deep-dive count meets scope and every row has provenance
- Steps 1, 2 and 4 each include at least five retrievable evidence URLs
- exactly 30 scripts exist
- budget and sub-allocation arithmetic are exact
- `strategy_choice.md` compares at least three options and contains primary,
  secondary, Where to Play, How to Win, capabilities, systems and no-go zones
- `strategic_plan.md` contains every required strategic section and owner gate
- estimates are labeled and facts are sourced
- shareable Customer Voice contains no verbatim quote, author, profile,
  comment/review ID or record-level URL
- no placeholders remain
- the validator exits 0 and independent review reports no blockers

## Included Resources

- `references/` — workflow, evidence queries and strategic frameworks
- `templates/` — README, strategy, executive and script templates
- `scripts/` — initializer, budget allocator, validator, installer and release
  validation/build helpers
- `examples/premium-toothpaste-thailand/` — privacy-reduced worked example
- `INSTALL.md` — Codex, Claude Code, Hermes and generic installation
