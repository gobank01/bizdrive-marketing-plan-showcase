# BizDrive Strategic + Marketing Plan — Student Edition

สกิลแบบ portable สำหรับใช้กับ Codex, Claude Code, Hermes หรือ AI agent ที่รองรับ
Agent Skills / `SKILL.md` และมีเครื่องมือค้นเว็บ อ่าน–เขียนไฟล์ และรัน Python

## สิ่งที่นักเรียนจะได้

- Category landscape ที่ประกาศ boundary และข้อจำกัดชัดเจน
- Material competitor universe ก่อนเลือก deep-dive set
- Evidence ledger และการแยก facts / observations / calculations / assumptions / inference / unknowns
- Strategy Choice: options, Where to Play, How to Win, capabilities และ no-go zones
- Strategic Plan: horizon, portfolio choices, operating model, resources, initiatives, scorecard, roadmap และ governance
- Marketing Plan 12 ขั้น พร้อม budget, KPI, execution และ short-video scripts 30 ชิ้น
- README-first handoff, assumptions/decision registers และ deterministic validation
- Privacy gate สำหรับ Customer Voice และ shareable/public artifacts

## Requirements

- Python 3.10+ (stdlib only)
- AI agent ที่อ่าน `SKILL.md` และ supporting files ได้
- สำหรับงานวิจัยจริง: web search/browser และ file tools
- ไม่ต้องใช้ API key ของสกิล; authentication ของ AI runtime เป็นของผู้ใช้เอง

## Quick Start

### Claude Code — ติดตั้งบรรทัดเดียว (ไม่ต้องใช้ Python)

วิธีที่สั้นที่สุด clone จาก repo ตรงเข้าโฟลเดอร์สกิล แล้วเปิด Claude Code ใหม่:

```bash
git clone --depth 1 https://github.com/gobank01/bizdrive-strategic-marketing-plan.git ~/.claude/skills/bizdrive-strategic-marketing-plan
```

อัปเดตรุ่นใหม่ทีหลังด้วย `git -C ~/.claude/skills/bizdrive-strategic-marketing-plan pull`

ถ้าเครื่องไม่มี git ใช้ ZIP แทน:

```bash
curl -sL https://bizdrive-marketing-plan.vercel.app/downloads/skill/bizdrive-strategic-marketing-plan-v0.9.2.zip -o /tmp/bizdrive-skill.zip && mkdir -p ~/.claude/skills && unzip -oq /tmp/bizdrive-skill.zip -d ~/.claude/skills && echo "ติดตั้งแล้ว: ~/.claude/skills/bizdrive-strategic-marketing-plan"
```

จากนั้นพิมพ์ `/bizdrive-strategic-marketing-plan` หรือพิมพ์ว่า "วางแผนการตลาดให้หน่อย" ได้เลย

### ทุก runtime — ติดตั้งด้วย installer

1. แตก ZIP แล้วเข้าโฟลเดอร์ `bizdrive-strategic-marketing-plan/`
2. ติดตั้งตาม runtime:

```text
python scripts/install_skill.py --runtime codex --scope user
python scripts/install_skill.py --runtime claude --scope user
python scripts/install_skill.py --runtime hermes --scope user
```

หรือติดตั้งเฉพาะโปรเจกต์:

```text
python scripts/install_skill.py --runtime codex --scope project --project-dir <project>
python scripts/install_skill.py --runtime claude --scope project --project-dir <project>
```

3. เปิด session ใหม่ถ้า runtime ยังไม่เห็นสกิล
4. เรียกด้วยภาษาธรรมชาติ หรือ:
   - Codex: `$bizdrive-strategic-marketing-plan`
   - Claude Code: `/bizdrive-strategic-marketing-plan`
5. ให้ข้อมูล product/entity, geography, budget, duration, Strategic Plan entity และ horizon

อ่านรายละเอียด runtime/path ใน `INSTALL.md`

## Validate the Package

```text
python scripts/validate_distribution.py .
python -m unittest discover -s tests -p "test_*.py" -v
```

Validate worked example:

```text
python scripts/validate_plan.py examples/premium-toothpaste-thailand \
  --min-competitors 10 --require-customer-voice --strategic-handoff
```

## Build a Deterministic ZIP

```text
python scripts/build_release.py
```

Builder สร้าง ZIP, internal `MANIFEST-SHA256.txt` และไฟล์ `.sha256`

## Worked Example

`examples/premium-toothpaste-thailand/` เป็นตัวอย่าง privacy-reduced จาก trial:

- 14 core Marketing Plan files
- 41 evidence records
- 10-brand universe/deep dive
- 100 privacy-reduced Customer Voice records
- Strategy Choice + provisional brand Strategic Plan
- assumptions/decision registers

ตัวอย่างไม่รวม raw excerpts, author/profile/comment IDs, private research directory,
credential, personal path หรือ external-action authorization

## Safety and Approval Boundary

สกิลสร้างและตรวจแผน ไม่ได้อนุมัติ product claims, spend, publish, upload,
deploy, hiring, contracts, outreach หรือ launch ทุก external action ต้องได้รับ
owner approval แยกตาม scope

## Release Status

รุ่น `0.9.0` เป็น student beta ที่ owner อนุญาตให้แจกภายใต้
`CC-BY-NC-4.0` สำหรับ content/examples และ `MIT` สำหรับ scripts/tests ดู
`RELEASE_STATUS.md`, `LICENSE.md` และ `references/provenance.md`
