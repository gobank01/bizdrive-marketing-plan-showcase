from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "examples" / "premium-toothpaste-thailand"


class DistributionPackageTests(unittest.TestCase):
    def test_distribution_validation_passes(self):
        run = subprocess.run(
            [sys.executable, str(ROOT / "scripts/validate_distribution.py"), str(ROOT)],
            text=True, capture_output=True,
        )
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        report = json.loads(run.stdout)
        self.assertEqual(report["status"], "pass")
        self.assertTrue(report["release_ready"])
        self.assertEqual(report["errors"], [])

    def test_initializer_is_portable_and_exact(self):
        with tempfile.TemporaryDirectory() as directory:
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/init_plan.py"),
                "--product", "Student Test",
                "--monthly-budget", "123456",
                "--duration", "7",
                "--price", "789",
                "--strategic-entity", "brand",
                "--strategic-horizon", "3 years",
                "--base-dir", directory,
                "--slug", "student-test",
            ], text=True, capture_output=True)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            project = Path(directory) / "student-test"
            meta = json.loads((project / "meta.json").read_text(encoding="utf-8"))
            self.assertEqual(meta["total_budget_thb"], 864192)
            self.assertEqual(meta["skill"], "bizdrive-strategic-marketing-plan")
            self.assertEqual(meta["skill_version"], "0.9.2")
            self.assertIn("strategic_plan.md", meta["strategic_handoff"])

    def test_initializer_rejects_slug_path_escape(self):
        malicious = ("../escape", "/tmp/absolute-escape", "nested/child", ".", "..")
        for slug in malicious:
            with self.subTest(slug=slug), tempfile.TemporaryDirectory() as directory:
                base = Path(directory) / "approved"
                base.mkdir()
                run = subprocess.run([
                    sys.executable, str(ROOT / "scripts/init_plan.py"),
                    "--product", "Student Test", "--monthly-budget", "100000",
                    "--duration", "3", "--base-dir", str(base), "--slug", slug,
                    "--force",
                ], text=True, capture_output=True)
                self.assertNotEqual(run.returncode, 0)
                self.assertIn("single safe path component", run.stderr)
                self.assertEqual(list(base.iterdir()), [])

    def test_initializer_rejects_symlinked_project_and_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "approved"
            outside = root / "outside"
            base.mkdir()
            outside.mkdir()
            (base / "student-test").symlink_to(outside, target_is_directory=True)
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/init_plan.py"),
                "--product", "Student Test", "--monthly-budget", "100000",
                "--duration", "3", "--base-dir", str(base), "--slug", "student-test",
                "--force",
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked project", run.stderr)
            self.assertEqual(list(outside.iterdir()), [])

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base = root / "approved"
            project = base / "student-test"
            outside = root / "outside-meta.json"
            project.mkdir(parents=True)
            outside.write_text("sentinel", encoding="utf-8")
            (project / "meta.json").symlink_to(outside)
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/init_plan.py"),
                "--product", "Student Test", "--monthly-budget", "100000",
                "--duration", "3", "--base-dir", str(base), "--slug", "student-test",
                "--force",
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked output", run.stderr)
            self.assertEqual(outside.read_text(encoding="utf-8"), "sentinel")

    def test_initializer_rejects_symlinked_base_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outside = root / "outside"
            outside.mkdir()
            linked_base = root / "approved-link"
            linked_base.symlink_to(outside, target_is_directory=True)
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/init_plan.py"),
                "--product", "Student Test", "--monthly-budget", "100000",
                "--duration", "3", "--base-dir", str(linked_base),
                "--slug", "student-test", "--force",
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked base directory", run.stderr)
            self.assertEqual(list(outside.iterdir()), [])

    def test_budget_allocator_rejects_symlinked_project(self):
        meta = {"monthly_budget_thb": 100000, "duration_months": 3}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            outside = root / "outside"
            outside.mkdir()
            (outside / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
            sentinel = outside / "budget_allocation.json"
            sentinel.write_text("sentinel", encoding="utf-8")
            linked_project = root / "project-link"
            linked_project.symlink_to(outside, target_is_directory=True)
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/budget_allocator.py"),
                "--project-dir", str(linked_project),
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked project", run.stderr)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "sentinel")

    def test_budget_allocator_rejects_symlinked_output(self):
        meta = {"monthly_budget_thb": 100000, "duration_months": 3}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = root / "project"
            project.mkdir()
            (project / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
            outside = root / "outside-budget.json"
            outside.write_text("sentinel", encoding="utf-8")
            (project / "budget_allocation.json").symlink_to(outside)
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/budget_allocator.py"),
                "--project-dir", str(project),
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked output", run.stderr)
            self.assertEqual(outside.read_text(encoding="utf-8"), "sentinel")

    def test_install_targets_codex_and_claude_project_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            cases = (
                ("codex", base / "codex", Path(".agents/skills/bizdrive-strategic-marketing-plan/SKILL.md")),
                ("claude", base / "claude", Path(".claude/skills/bizdrive-strategic-marketing-plan/SKILL.md")),
            )
            for runtime, project, relative in cases:
                project.mkdir()
                run = subprocess.run([
                    sys.executable, str(ROOT / "scripts/install_skill.py"),
                    "--runtime", runtime,
                    "--scope", "project",
                    "--project-dir", str(project),
                ], text=True, capture_output=True)
                self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
                self.assertTrue((project / relative).is_file())

    def test_hermes_project_install_configures_external_dirs(self):
        if not shutil.which("hermes"):
            self.skipTest("Hermes CLI not installed; installer fails closed without it")
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            project = base / "project"
            profile_home = base / "profile-home"
            project.mkdir()
            env = dict(os.environ, HERMES_HOME=str(profile_home))
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/install_skill.py"),
                "--runtime", "hermes", "--scope", "project",
                "--project-dir", str(project),
            ], text=True, capture_output=True, env=env)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            target = project / ".agents/skills/bizdrive-strategic-marketing-plan/SKILL.md"
            self.assertTrue(target.is_file())
            configured = subprocess.run(
                ["hermes", "config", "get", "--json", "skills.external_dirs"],
                text=True, capture_output=True, env=env,
            )
            self.assertEqual(configured.returncode, 0, configured.stdout + configured.stderr)
            external_dirs = json.loads(configured.stdout)
            self.assertIn(str((project / ".agents/skills").resolve()), external_dirs)
            listed = subprocess.run(
                ["hermes", "skills", "list"], text=True, capture_output=True, env=env,
            )
            self.assertEqual(listed.returncode, 0, listed.stdout + listed.stderr)
            self.assertIn("bizdrive-strategic-marketing-plan", listed.stdout)

    def test_hermes_project_install_preserves_existing_yaml_list(self):
        if not shutil.which("hermes"):
            self.skipTest("Hermes CLI not installed")
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            project = base / "project"
            profile_home = base / "profile-home"
            existing = base / "existing-skills"
            project.mkdir()
            existing.mkdir()
            profile_home.mkdir()
            (profile_home / "config.yaml").write_text(
                "skills:\n  external_dirs:\n    - " + json.dumps(str(existing.resolve())) + "\n",
                encoding="utf-8",
            )
            env = dict(os.environ, HERMES_HOME=str(profile_home))
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/install_skill.py"),
                "--runtime", "hermes", "--scope", "project",
                "--project-dir", str(project),
            ], text=True, capture_output=True, env=env)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            configured = subprocess.run(
                ["hermes", "config", "get", "--json", "skills.external_dirs"],
                text=True, capture_output=True, env=env,
            )
            self.assertEqual(configured.returncode, 0, configured.stdout + configured.stderr)
            external_dirs = json.loads(configured.stdout)
            self.assertEqual(external_dirs, [
                str(existing.resolve()), str((project / ".agents/skills").resolve()),
            ])

    def test_hermes_config_snapshot_restores_exact_bytes(self):
        if not shutil.which("hermes"):
            self.skipTest("Hermes CLI not installed")
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            profile_home = base / "profile-home"
            existing = base / "existing-skills"
            added = base / "project/.agents/skills"
            profile_home.mkdir()
            existing.mkdir()
            added.mkdir(parents=True)
            original = (
                "# keep this comment\n"
                "skills:\n"
                "  external_dirs:\n"
                "    - " + json.dumps(str(existing.resolve())) + "\n"
                "terminal:\n  timeout: 180\n"
            ).encode("utf-8")
            config = profile_home / "config.yaml"
            config.write_bytes(original)
            spec = importlib.util.spec_from_file_location(
                "portable_installer", ROOT / "scripts/install_skill.py",
            )
            self.assertIsNotNone(spec)
            module = importlib.util.module_from_spec(spec)
            assert spec and spec.loader
            spec.loader.exec_module(module)
            snapshot = module.configure_hermes_external_dir("hermes", profile_home, added)
            self.assertIn(str(added.resolve()), module.get_external_dirs("hermes", profile_home))
            module.restore_config(snapshot)
            self.assertEqual(config.read_bytes(), original)
            self.assertEqual(module.get_external_dirs("hermes", profile_home), [str(existing.resolve())])

    def test_hermes_user_install_respects_hermes_home(self):
        if not shutil.which("hermes"):
            self.skipTest("Hermes CLI not installed")
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            profile_home = base / "profile-home"
            fallback_home = base / "fallback-home"
            env = dict(os.environ, HERMES_HOME=str(profile_home))
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/install_skill.py"),
                "--runtime", "hermes",
                "--scope", "user",
                "--home", str(fallback_home),
            ], text=True, capture_output=True, env=env)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            target = profile_home / "skills/bizdrive-strategic-marketing-plan/SKILL.md"
            self.assertTrue(target.is_file())
            self.assertFalse((fallback_home / ".hermes/skills/bizdrive-strategic-marketing-plan").exists())

    def test_hermes_project_install_fails_closed_without_cli(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            project = base / "project"
            project.mkdir()
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/install_skill.py"),
                "--runtime", "hermes", "--scope", "project",
                "--project-dir", str(project),
                "--hermes-home", str(base / "profile"),
                "--hermes-cli", str(base / "missing-hermes"),
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("requires the `hermes` CLI", run.stderr)
            skill_root = project / ".agents/skills"
            self.assertFalse((skill_root / "bizdrive-strategic-marketing-plan").exists())
            self.assertFalse(any(skill_root.glob(".*.installing-*") if skill_root.exists() else []))

    def test_project_install_rejects_symlinked_agents_ancestor(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            project = base / "project"
            outside = base / "outside"
            project.mkdir()
            outside.mkdir()
            (project / ".agents").symlink_to(outside, target_is_directory=True)
            target = outside / "skills/bizdrive-strategic-marketing-plan"
            target.mkdir(parents=True)
            sentinel = target / "SENTINEL"
            sentinel.write_text("do-not-delete", encoding="utf-8")
            run = subprocess.run([
                sys.executable, str(ROOT / "scripts/install_skill.py"),
                "--runtime", "generic", "--scope", "project",
                "--project-dir", str(project), "--force",
            ], text=True, capture_output=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("symlinked install path segment", run.stderr)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "do-not-delete")

    def test_shareable_validator_rejects_verbatim_voice_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            path = project / "step4_customer_persona.md"
            path.write_text(path.read_text(encoding="utf-8") + "\n## Exact excerpts (not efficacy evidence)\n", encoding="utf-8")
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("exact Customer Voice excerpt section", run.stdout)

    def test_shareable_validator_rejects_private_voice_field(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            path = project / "customer_voice.json"
            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["records"][0]["author_name"] = "must-not-ship"
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("private fields", run.stdout)

    def test_shareable_validator_rejects_direct_customer_statement(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            nested = project / "nested"
            nested.mkdir()
            (nested / "voice.md").write_text(
                '# Customer Voice\n\nCustomer Voice: "I love this toothpaste and use it every day."\n',
                encoding="utf-8",
            )
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("direct Customer Voice speech", run.stdout)

    def test_shareable_validator_rejects_unquoted_voice_statements(self):
        statements = (
            "I love this toothpaste and use it every day.",
            "Customer: I love this toothpaste and use it every day.",
        )
        for statement in statements:
            with self.subTest(statement=statement), tempfile.TemporaryDirectory() as directory:
                project = Path(directory) / "example"
                shutil.copytree(EXAMPLE, project)
                nested = project / "nested"
                nested.mkdir()
                (nested / "voice.md").write_text(
                    "# Customer Voice\n\n" + statement + "\n", encoding="utf-8",
                )
                run = self._validate_example(project)
                self.assertNotEqual(run.returncode, 0)
                self.assertIn("direct or quoted speech", run.stdout)

    def test_shareable_validator_rejects_csv_identity_columns(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            nested = project / "nested"
            nested.mkdir()
            (nested / "voice.csv").write_text(
                "theme,author_name,email,comment_id\nvalue,Person,student@example.com,abc123\n",
                encoding="utf-8",
            )
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("private/identifier CSV columns", run.stdout)
            self.assertIn("email", run.stdout)

    def test_shareable_validator_rejects_svg_email(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            nested = project / "nested"
            nested.mkdir()
            (nested / "voice.svg").write_text(
                '<svg xmlns="http://www.w3.org/2000/svg"><text>student@example.com</text></svg>\n',
                encoding="utf-8",
            )
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("email address remains", run.stdout)

    def test_customer_voice_source_url_requires_http_host(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            path = project / "customer_voice.json"
            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["records"][0]["source_url"] = "not-a-url"
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("source_url must be an HTTP(S) URL with a host", run.stdout)

    def test_scenario_policy_rejects_unsupported_weighted_value(self):
        statements = (
            "20/60/20 weighted revenue illustration = **2,020,620 THB**",
            "The probability-weighted revenue is 2,020,620 THB",
            "20/60/20 weighted revenue: 2,020,620 THB",
        )
        for statement in statements:
            with self.subTest(statement=statement), tempfile.TemporaryDirectory() as directory:
                project = Path(directory) / "example"
                shutil.copytree(EXAMPLE, project)
                path = project / "step9_budget_allocation.md"
                path.write_text(path.read_text(encoding="utf-8") + "\n" + statement + "\n", encoding="utf-8")
                run = self._validate_example(project)
                self.assertNotEqual(run.returncode, 0)
                self.assertIn("unsupported probability-weighted value", run.stdout)

    def test_scenario_policy_rejects_universal_multiplier_aliases(self):
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            path = project / "step9_budget_allocation.md"
            path.write_text(
                path.read_text(encoding="utf-8")
                + "\nUse universal performance multipliers for every case.\n",
                encoding="utf-8",
            )
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("universal/default scenario multiplier statement", run.stdout)

        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "example"
            shutil.copytree(EXAMPLE, project)
            path = project / "budget_allocation.json"
            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["performance_multipliers"] = {"best": 1.5, "base": 1.0, "worst": 0.6}
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            run = self._validate_example(project)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("multiplier key", run.stdout)

    def test_release_gate_rejects_unknown_sensitive_binary_and_symlink_files(self):
        fixtures = ("env", "extensionless", "binary", "symlink", "private_dir")
        for fixture in fixtures:
            with self.subTest(fixture=fixture), tempfile.TemporaryDirectory() as directory:
                package = Path(directory) / "package"
                shutil.copytree(
                    ROOT, package,
                    ignore=shutil.ignore_patterns("release", "__pycache__", ".pytest_cache"),
                )
                if fixture == "env":
                    (package / ".env").write_text("API_TOKEN=must-not-ship\n", encoding="utf-8")
                elif fixture == "extensionless":
                    (package / "credentials").write_text("private material\n", encoding="utf-8")
                elif fixture == "binary":
                    (package / "references/secret.bin").write_bytes(b"\x00secret\xff")
                elif fixture == "symlink":
                    outside = Path(directory) / "outside-secret.md"
                    outside.write_text("private material\n", encoding="utf-8")
                    (package / "references/leak.md").symlink_to(outside)
                else:
                    (package / "references/private").mkdir()

                validate = subprocess.run([
                    sys.executable, str(package / "scripts/validate_distribution.py"),
                    str(package), "--release",
                ], text=True, capture_output=True)
                self.assertNotEqual(validate.returncode, 0, fixture)

                build = subprocess.run([
                    sys.executable, str(package / "scripts/build_release.py"),
                    "--package-dir", str(package), "--output-dir", str(Path(directory) / "out"),
                ], text=True, capture_output=True)
                self.assertNotEqual(build.returncode, 0, fixture)

    def test_release_gate_rejects_hidden_and_unreviewed_inventory_paths(self):
        fixtures = ("hidden", "unreviewed", "sensitive_name", "raw_like")
        for fixture in fixtures:
            with self.subTest(fixture=fixture), tempfile.TemporaryDirectory() as directory:
                package = Path(directory) / "package"
                shutil.copytree(
                    ROOT, package,
                    ignore=shutil.ignore_patterns("release", "__pycache__", ".pytest_cache"),
                )
                (package / ".gitignore").unlink(missing_ok=True)
                if fixture == "hidden":
                    (package / ".gitignore").write_text("release/\n", encoding="utf-8")
                elif fixture == "unreviewed":
                    (package / "references/UNREVIEWED.md").write_text(
                        "# Unreviewed payload\n", encoding="utf-8",
                    )
                elif fixture == "sensitive_name":
                    (package / "references/secrets.md").write_text(
                        "private material\n", encoding="utf-8",
                    )
                elif fixture == "raw_like":
                    raw_dir = package / "references/raw_data"
                    raw_dir.mkdir()
                    (raw_dir / "customer-source.md").write_text(
                        "Customer: I use this product every day.\n", encoding="utf-8",
                    )

                validate = subprocess.run([
                    sys.executable, str(package / "scripts/validate_distribution.py"),
                    str(package), "--release",
                ], text=True, capture_output=True)
                self.assertNotEqual(validate.returncode, 0, fixture)

                build = subprocess.run([
                    sys.executable, str(package / "scripts/build_release.py"),
                    "--package-dir", str(package), "--output-dir", str(Path(directory) / "out"),
                ], text=True, capture_output=True)
                self.assertNotEqual(build.returncode, 0, fixture)

    def test_release_gate_rejects_sensitive_content_in_reviewed_path(self):
        fixtures = ("credential_assignment", "direct_customer_statement")
        for fixture in fixtures:
            with self.subTest(fixture=fixture), tempfile.TemporaryDirectory() as directory:
                package = Path(directory) / "package"
                shutil.copytree(
                    ROOT, package,
                    ignore=shutil.ignore_patterns("release", "__pycache__", ".pytest_cache"),
                )
                target = package / "references/research_query_bank.md"
                addition = (
                    "\npassword = not-a-real-secret-value\n"
                    if fixture == "credential_assignment"
                    else "\nCustomer: I use this product every day.\n"
                )
                target.write_text(target.read_text(encoding="utf-8") + addition, encoding="utf-8")

                validate = subprocess.run([
                    sys.executable, str(package / "scripts/validate_distribution.py"),
                    str(package), "--release",
                ], text=True, capture_output=True)
                self.assertNotEqual(validate.returncode, 0, fixture)

                build = subprocess.run([
                    sys.executable, str(package / "scripts/build_release.py"),
                    "--package-dir", str(package), "--output-dir", str(Path(directory) / "out"),
                ], text=True, capture_output=True)
                self.assertNotEqual(build.returncode, 0, fixture)

    def test_extracted_release_rebuild_has_one_manifest_and_same_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            out1 = base / "release-one"
            first = subprocess.run([
                sys.executable, str(ROOT / "scripts/build_release.py"),
                "--package-dir", str(ROOT),
                "--output-dir", str(out1),
            ], text=True, capture_output=True)
            self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
            first_report = json.loads(first.stdout)
            first_zip = Path(first_report["zip"])

            extracted_parent = base / "extracted"
            with zipfile.ZipFile(first_zip) as archive:
                archive.extractall(extracted_parent)
            extracted = extracted_parent / "bizdrive-strategic-marketing-plan"
            out2 = base / "release-two"
            second = subprocess.run([
                sys.executable, str(extracted / "scripts/build_release.py"),
                "--package-dir", str(extracted),
                "--output-dir", str(out2),
            ], text=True, capture_output=True)
            self.assertEqual(second.returncode, 0, second.stdout + second.stderr)
            second_report = json.loads(second.stdout)
            second_zip = Path(second_report["zip"])

            first_hash = hashlib.sha256(first_zip.read_bytes()).hexdigest()
            second_hash = hashlib.sha256(second_zip.read_bytes()).hexdigest()
            self.assertEqual(first_hash, second_hash)
            with zipfile.ZipFile(second_zip) as archive:
                names = archive.namelist()
                self.assertIsNone(archive.testzip())
                for info in archive.infolist():
                    self.assertFalse(info.is_dir())
                    self.assertNotIn("\\", info.filename)
                    self.assertFalse(info.filename.startswith("/"))
                    self.assertNotIn("..", Path(info.filename).parts)
                    self.assertTrue(stat.S_ISREG(info.external_attr >> 16), info.filename)
                manifest_text = archive.read(
                    "bizdrive-strategic-marketing-plan/MANIFEST-SHA256.txt"
                ).decode("utf-8")
                manifest_entries = [line.split("  ", 1) for line in manifest_text.splitlines()]
                self.assertEqual(len(manifest_entries), len(names) - 1)
                for expected_hash, relative in manifest_entries:
                    member = f"bizdrive-strategic-marketing-plan/{relative}"
                    self.assertEqual(hashlib.sha256(archive.read(member)).hexdigest(), expected_hash)
            manifest = "bizdrive-strategic-marketing-plan/MANIFEST-SHA256.txt"
            self.assertEqual(names.count(manifest), 1)
            self.assertEqual(len(names), len(set(names)))

    def _validate_example(self, project: Path) -> subprocess.CompletedProcess[str]:
        return subprocess.run([
            sys.executable, str(ROOT / "scripts/validate_plan.py"), str(project),
            "--min-competitors", "10", "--require-customer-voice",
            "--strategic-handoff", "--publication-mode", "shareable",
        ], text=True, capture_output=True)


if __name__ == "__main__":
    unittest.main()
